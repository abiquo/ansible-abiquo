SELECT "Creating procedures for the Virtual Machine Usage report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_VMUsage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_VMUsage_v1_0( rls_abiquo_user VARCHAR(128),
                                                    p_idEnterpriseFromList INT(10), p_idVirtualDatacenterList INT(10),
                                                    p_idOwnerList INT(10), p_idVMList INT(10),
                                                    p_startDate TIMESTAMP, p_endDate TIMESTAMP,
                                                    p_idCostCodeList INT(10)
                                                   )
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Virtual Machine Usage Report SP
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  vmd.Datacenter AS 'Datacenter', vmd.Rack AS 'Rack', vmd.Host AS 'Host',
            vmd.Enterprise AS 'Enterprise', vmd.VirtualDatacenter AS 'Virtual Datacenter', vmd.VirtualAppliance AS 'Virtual Appliance',
            vmd.VirtualMachine AS 'VirtualMachine', vmd.VirtualImage AS 'Virtual Image',
            vmd.VirtualMachineState AS 'Virtual Machine State',
            vmDeployInfo.deployTime AS 'Date Deployed',
            vmd.Owner AS 'Owner',
            vmd.CostCode AS 'Cost Code',
            vmd.CPU AS 'CPU', vmd.MemoryMB AS 'Memory (MB)',
            vmd.LocalStorageGB AS 'Local Storage (GB)',
            COALESCE(CAST(externalStorageInfo.extStorageMBAllocated/1024 AS DECIMAL(28,2)),0) AS 'External Storage (GB)'

    FROM

    kinton_reporting.RLS_SUM_VM_DETAILS_V1_0_VW vmd

    LEFT JOIN
    (SELECT COALESCE(vm.idVM,0) AS idVM, MIN(m.timestamp) AS deployTime
        FROM kinton.event m, kinton.virtualmachine vm
        WHERE
             m.entity_type LIKE "VIRTUAL_MACHINE"
             AND (m.action IN ("DEPLOY","DEPLOY_HA") OR m.action LIKE "CAPTURE%")
            AND m.message LIKE CONCAT("%",vm.name,"%")
        GROUP BY vm.idVM
    ) AS vmDeployInfo
        ON (vmd.idVM=vmDeployInfo.idVm)

    # TODO - review use of below, particualrly the references to volume management state
    LEFT JOIN kinton_reporting.RLS_STORAGE_USED_BY_VM_V1_0_VW AS externalStorageInfo
        ON (vmd.idVM=externalStorageInfo.idVM)

    WHERE
        (vmd.idEnterprise = p_idEnterpriseFromList OR (p_idEnterpriseFromList IS NULL)) AND
        (vmd.idVirtualDataCenter = p_idVirtualDatacenterList OR p_idVirtualDatacenterList IS NULL) AND
        (vmd.idUser = p_idOwnerList OR p_idOwnerList IS NULL) AND
        (vmd.idVM = p_idVMList OR p_idVMList IS NULL) AND
        (vmDeployInfo.deployTime >= p_startDate OR p_startDate IS NULL) AND
        (vmDeployInfo.deployTime <= p_endDate OR p_endDate IS NULL) AND
        (vmd.idCostCode = p_idCostCodeList OR p_idCostCodeList IS NULL)

    ORDER BY vmd.Datacenter, vmd.Host, vmd.Enterprise, vmd.VirtualDatacenter, vmd.VirtualAppliance, vmd.VirtualMachine;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
