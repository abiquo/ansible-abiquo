# First create the reporting schema...
SELECT "Creating reporting schema..." AS " ";
CREATE SCHEMA IF NOT EXISTS kinton_reporting;


# Now create the supporting objects which provide 'core' Row Level Security (RLS) support
# Note - it would have been nice to populate up only TMP tables with RLS data and then use a VIEW
# to join to the underlying kinton table....however MySQL will not allow you to 
# create VIEWS on TMP tables :-(   Therefore we create a permananet table and include 
# a connection_id 

#
# RLS support tables
#
SELECT "Creating RLS tables..." AS " ";

# ENTERPRISE support...
DROP TABLE IF EXISTS kinton_reporting.RLS_ENTERPRISE;
CREATE TABLE kinton_reporting.RLS_ENTERPRISE
(
    `idEnterprise` int(10) unsigned NOT NULL,
    `name` varchar(128) NOT NULL,
    `ramSoft` bigint(20) NOT NULL default 0,
    `cpuSoft` bigint(20) NOT NULL default 0,
    `hdSoft` bigint(20)  NOT NULL default 0,
    `storageSoft` bigint(20)  NOT NULL default 0,
    `repositorySoft` bigint(20)  NOT NULL default 0,
    `vlanSoft` bigint(20)  NOT NULL default 0,
    `publicIPSoft` bigint(20)  NOT NULL default 0,
    `ramHard` bigint(20) NOT NULL default 0,
    `cpuHard` bigint(20) NOT NULL default 0,
    `hdHard` bigint(20)  NOT NULL default 0,
    `storageHard` bigint(20)  NOT NULL default 0,
    `repositoryHard` bigint(20)  NOT NULL default 0,
    `vlanHard` bigint(20)  NOT NULL default 0,
    `publicIPHard` bigint(20)  NOT NULL default 0,
    `chef_url` varchar(255) default NULL,
    `chef_client` varchar(50) default NULL,
    `chef_validator` varchar(50) default NULL,
    `chef_client_certificate` text default NULL,
    `chef_validator_certificate` text default NULL,
    `isReservationRestricted` tinyint(1) default '0',
    `idPricingTemplate` int(10) unsigned DEFAULT NULL,
    `connection_id`     int(10),
    PRIMARY KEY  (`idEnterprise`, `connection_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

create unique index idx_rls_enterprise_name on kinton_reporting.RLS_ENTERPRISE(name,identerprise,connection_id);


# VDC support...
DROP TABLE IF EXISTS kinton_reporting.RLS_VDC;
CREATE TABLE kinton_reporting.RLS_VDC
(
    `idVirtualDataCenter` int(10) unsigned NOT NULL,
    `idEnterprise` int(10) unsigned NOT NULL,
    `name` varchar(40) default NULL,
    `idDataCenter` int(10) unsigned NOT NULL,
    `networktypeID` int(11) unsigned,
    `hypervisorType` varchar(255) NOT NULL,
    `ramSoft` bigint(20) NOT NULL default 0,
    `cpuSoft` bigint(20) NOT NULL default 0,
    `hdSoft` bigint(20)  NOT NULL default 0,
    `storageSoft` bigint(20)  NOT NULL default 0,
    `vlanSoft` bigint(20)  NOT NULL default 0,
    `publicIPSoft` bigint(20)  NOT NULL default 0,
    `ramHard` bigint(20) NOT NULL default 0,
    `cpuHard` bigint(20) NOT NULL default 0,
    `hdHard` bigint(20)  NOT NULL default 0,
    `storageHard` bigint(20)  NOT NULL default 0,
    `vlanHard` bigint(20)  NOT NULL default 0,
    `publicIPHard` bigint(20)  NOT NULL default 0,
    `default_vlan_network_id` int(11) unsigned default NULL,
    `connection_id`     int(10),
    PRIMARY KEY  (`idVirtualDataCenter`, `connection_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


# Datacenter support
DROP TABLE IF EXISTS kinton_reporting.RLS_DATACENTER;
CREATE TABLE kinton_reporting.RLS_DATACENTER
(
    `idDataCenter` int(10) unsigned NOT NULL,
    `name` varchar(20) NOT NULL,
    `situation` varchar(100) default NULL,
    `network_id` int(11) unsigned default NULL,
    `connection_id`     int(10),
    PRIMARY KEY  (`idDataCenter`, `connection_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;





#
# Core RLS SPs - Used to mange the RLS Table content
#
SELECT "Creating RLS procedures..." AS " ";

DROP PROCEDURE IF EXISTS kinton_reporting.InitialiseRLS;
DELIMITER |
CREATE PROCEDURE kinton_reporting.InitialiseRLS( rls_abiquo_user VARCHAR(128) )
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
#
# SP used to initialise DBMS-based RLS.   MUST be run before referencing the above views, otherwise the
# views will be empty or will contain 'out of date' information.
# Ideally, this SP should be called as the first operation in any report SP
# Note: The supplied user is the abiquo user name, not the DBMS user name!
#
BEGIN
    DECLARE conn_id int(10);
    SELECT CONNECTION_ID() INTO conn_id;

    # First drop any existing temporary table content...
    CALL kinton_reporting.CleanupRLS();

    # Populate up the temporary Enterprise, VDC, and DataCenter RLS tables using scope information...
    # Populate the TMP table with the Enterprises the user is able to see...
    INSERT INTO RLS_ENTERPRISE( idEnterprise, name,
                                    ramSoft, cpuSoft, hdSoft, storageSoft, repositorySoft, vlanSoft, publicIPSoft,
                                    ramHard, cpuHard, hdHard, storageHard, repositoryHard, vlanHard, publicIPHard,
                                    chef_url, chef_client, chef_validator, chef_client_certificate, chef_validator_certificate, isReservationRestricted,
                                    idPricingTemplate, connection_id
                                  )
    (
        SELECT idEnterprise, name,
               ramSoft, cpuSoft, hdSoft * 1048576, storageSoft * 1048576, repositorySoft * 1048576, vlanSoft, publicIPSoft,
               ramHard, cpuHard, hdHard * 1048576 , storageHard * 1048576, repositoryHard * 1048576, vlanHard, publicIPHard,
               chef_url, chef_client, chef_validator, chef_client_certificate, chef_validator_certificate, isReservationRestricted,
               idPricingTemplate, conn_id
        FROM
        (
            (SELECT DISTINCT scopeEnterprises.*
                FROM    
                        (SELECT e.* FROM kinton.enterprise e, kinton.user u, kinton.scope_resource sr, kinton.role r
                            WHERE   u.user=rls_abiquo_user AND
                                    u.idRole=r.idRole AND
                                    ((u.scope_id=1) OR (u.scope_id=sr.idScope AND sr.resourceType='ENTERPRISE' AND sr.idResource=e.idEnterprise))
                        ) AS scopeEnterprises,
                        (SELECT count(*) as hasPrivs
                        FROM kinton.user u, kinton.role r, kinton.roles_privileges rp, kinton.privilege p
                        WHERE
                            u.user=rls_abiquo_user AND
                            u.idRole=r.idRole AND
                            rp.idRole=r.idRole AND
                            rp.idPrivilege=p.idPrivilege AND
                            p.name='ENTERPRISE_ENUMERATE'
                        ) privsCheck
                WHERE   privsCheck.hasPrivs > 0
            )
            UNION
            (SELECT e.*
                FROM    kinton.enterprise e,
                    kinton.user u
                WHERE
                    u.idEnterprise=e.idEnterprise AND
                    u.user=rls_abiquo_user
            )
        ) ent_rls
    );

    # Populate the TMP table with the Virtual Datacenter the user is able to see...
    INSERT INTO RLS_VDC( idVirtualDataCenter, idEnterprise, name, idDataCenter, networktypeID, hypervisorType,
                                    ramSoft, cpuSoft, hdSoft, storageSoft, vlanSoft, publicIPSoft,
                                    ramHard, cpuHard, hdHard, storageHard, vlanHard, publicIPHard, default_vlan_network_id,
                                    connection_id)
    (
        SELECT  idVirtualDataCenter, idEnterprise, name, idDataCenter, networktypeID, hypervisorType,
                ramSoft, cpuSoft, hdSoft * 1048576, storageSoft * 1048576, vlanSoft, publicIPSoft,
                ramHard, cpuHard, hdHard * 1048576, storageHard * 1048576, vlanHard, publicIPHard, default_vlan_network_id, conn_id
        FROM
        (
            (SELECT vdc.*
            FROM
                kinton.virtualdatacenter vdc, 
                RLS_ENTERPRISE rls_e,
                kinton.user u
            WHERE
                rls_e.idEnterprise=vdc.idEnterprise AND
                u.user=rls_abiquo_user AND
                # NULL/0 length list=access all VDCs. otherwise restrict to supplied list...
                (u.availableVirtualDataCenters IS NULL OR
                 LENGTH(u.availableVirtualDataCenters)=0 OR 
                 FIND_IN_SET(vdc.idVirtualDataCenter, u.availableVirtualDataCenters))
            )
            UNION
            (SELECT vdc.*
            FROM    kinton.virtualdatacenter vdc,
                    RLS_ENTERPRISE rls_e,
                    (SELECT count(*) as hasPrivs
                    FROM kinton.user u, kinton.role r, kinton.roles_privileges rp, kinton.privilege p
                    WHERE
                        u.user=rls_abiquo_user AND
                        u.idRole=r.idRole AND 
                        r.idRole=rp.idRole AND
                        rp.idPrivilege=p.idPrivilege AND
                        p.name='USERS_PROHIBIT_VDC_RESTRICTION'
                    ) privsCheck
            WHERE
                vdc.idEnterprise=rls_e.idEnterprise AND
                rls_e.connection_id=conn_id AND
                privsCheck.hasPrivs > 0
            )
        ) vdc_rls
    );

    # Populate the TMP table with the Datacenters the user is able to see...
    INSERT INTO RLS_DATACENTER( idDataCenter, name, situation, network_id, connection_id)
    (
        SELECT dc_rls.abstract_datacenter_id AS idDataCenter, dc_rls.name, dc.situation, dc_rls.network_id, conn_id
        FROM
        (
            (SELECT DISTINCT scopeDataCenters.*
                FROM    
                        (SELECT adc.* FROM kinton.abstract_datacenter adc, kinton.user u, kinton.scope_resource sr, kinton.role r
                            WHERE   u.user=rls_abiquo_user AND
                                    u.idRole=r.idRole AND
                                    ((u.scope_id=1) OR (u.scope_id=sr.idScope AND sr.resourceType='DATACENTER' AND sr.idResource=adc.abstract_datacenter_id))
                        ) AS scopeDataCenters,
                        (SELECT count(*) as hasPrivs
                        FROM kinton.user u, kinton.role r, kinton.roles_privileges rp, kinton.privilege p
                        WHERE
                            u.user=rls_abiquo_user AND
                            u.idRole=r.idRole AND
                            rp.idRole=r.idRole AND
                            rp.idPrivilege=p.idPrivilege AND
                            p.name='PHYS_DC_RETRIEVE_DETAILS'
                        ) privsCheck
                WHERE   privsCheck.hasPrivs > 0)
        ) dc_rls
        LEFT JOIN kinton.datacenter dc ON (dc.idDataCenter=dc_rls.abstract_datacenter_id)
    );
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reporting.CleanupRLS;
DELIMITER |
CREATE PROCEDURE kinton_reporting.CleanupRLS()
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
# This SP should be a corresponding call to InitialiseRLS(), to be made once all queries
# have been run. It prevents the underlying RLS tables from gathering orphaned data
BEGIN
    DELETE FROM RLS_ENTERPRISE WHERE connection_id=CONNECTION_ID();
    DELETE FROM RLS_VDC WHERE connection_id=CONNECTION_ID();
    DELETE FROM RLS_DATACENTER WHERE connection_id=CONNECTION_ID();
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reporting.TruncateRLSTables;
DELIMITER |
CREATE PROCEDURE kinton_reporting.TruncateRLSTables()
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
# This SP removes *ALL* data from the RLS tables, and should be called no
# more than periodically to clean up any orphaned data.
# This SP should only be called when no RLS users are active on the system
# It can be used to remove all orphaned RLS 
BEGIN
    TRUNCATE TABLE RLS_ENTERPRISE;
    TRUNCATE TABLE RLS_VDC;
    TRUNCATE TABLE RLS_DATACENTER;
END|
DELIMITER ;





#
# 'Core' RLS views which provide RLS against the 'base' kinton schema objects
#
SELECT "Creating 'Core' RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.RLS_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS
#
# Main view that should be used to access Enterprise details.
# Internally, this joins uses the RLS_ENTERPRISE table and the MySQL connection ID to filter
# rows appropriately.
# Note: The 'InitialiseRLS' stored procedure MUST have been called before using this view 
# 
	SELECT * FROM kinton_reporting.RLS_ENTERPRISE rls_e WHERE rls_e.connection_id=CONNECTION_ID();


DROP VIEW IF EXISTS kinton_reporting.RLS_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VDC_V1_0_VW AS 
#
# Main view that should be used to access VDC details.
# Internally, this joins uses the RLS_VDC table and the MySQL connection ID to filter
# rows appropriately.
# Note: The 'InitialiseRLS' stored procedure MUST have been called before using this view 
# 
	SELECT * FROM kinton_reporting.RLS_VDC rls_vdc WHERE rls_vdc.connection_id=CONNECTION_ID();


DROP VIEW IF EXISTS kinton_reporting.RLS_DATACENTER_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_DATACENTER_V1_0_VW AS 
#
# Main view that should be used to access DATACENTER details.
# Internally, this joins uses the RLS_DATACENTER table and the MySQL connection ID to filter
# rows appropriately.
# Note: The 'InitialiseRLS' stored procedure MUST have been called before using this view 
# 
	SELECT * FROM kinton_reporting.RLS_DATACENTER rls_dc WHERE rls_dc.connection_id=CONNECTION_ID();

DROP VIEW IF EXISTS kinton_reporting.RLS_PUBLIC_DATACENTER_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PUBLIC_DATACENTER_V1_0_VW AS
	SELECT * FROM kinton_reporting.RLS_DATACENTER_V1_0_VW d
	WHERE NOT EXISTS (SELECT NULL FROM kinton.public_cloud_region pd 
			  WHERE d.idDataCenter=pd.public_cloud_region_id);

DROP VIEW IF EXISTS kinton_reporting.RLS_PUBLIC_CLOUD_REGION_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PUBLIC_CLOUD_REGION_V1_0_VW AS
	SELECT  datacenter.idDataCenter,
		datacenter.name,
		datacenter.network_id,
		public_datacenter.region,
		public_datacenter.endpoint,
		public_datacenter.provider
	 FROM 	kinton_reporting.RLS_DATACENTER_V1_0_VW datacenter,
		kinton.public_cloud_region public_datacenter 
	WHERE datacenter.idDataCenter=public_datacenter.public_cloud_region_id;
	
DROP VIEW IF EXISTS kinton_reporting.RLS_REMOTE_SERVICE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW  kinton_reporting.RLS_REMOTE_SERVICE_V1_0_VW AS
        SELECT r.*, adrs.abstract_datacenter_id from kinton.remote_service r, kinton.abstract_datacenter_remote_service adrs,
			kinton_reporting.RLS_DATACENTER_V1_0_VW rls_dc
	WHERE r.idRemoteService = adrs.remote_service_id
          AND adrs.abstract_datacenter_id = rls_dc.idDataCenter;


DROP VIEW IF EXISTS kinton_reporting.RLS_PHYSICAL_MACHINE_V1_0_VW;
#
#  idState values are 
#  0 STOPPED,1 PROVISIONED,2 NOT_MANAGED,3 MANAGED,4 HALTED,5 UNLICENSED,6 HA_IN_PROGRESS,7 DISABLED_FOR_HA,8 HALTED_FOR_SAVE
#
CREATE SQL SECURITY DEFINER VIEW  kinton_reporting.RLS_PHYSICAL_MACHINE_V1_0_VW AS
	SELECT 
	CASE idState 
	WHEN 0 THEN 'STOPPED'
	WHEN 1 THEN 'PROVISIONED'
	WHEN 2 THEn 'NOT_MANAGED'
	WHEN 3 THEN 'MANAGED'
	WHEN 4 THEN 'HALTED'
	WHEN 5 THEN 'UNLICENSED'
	WHEN 6 THEN 'HA_IN_PROGRESS'
	WHEN 7 THEN 'DISABLED_FOR_HA'
	WHEN 8 THEN 'HALTED_FOR_SAVE'
	END as StateDescription,
	case when idState in (1,3) then 1 else 0 end as status_category,
	m.*
	from kinton.physicalmachine m,
			kinton_reporting.RLS_DATACENTER_V1_0_VW  rls_dc
	WHERE m.idDataCenter=rls_dc.idDataCenter;

DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW  kinton_reporting.RLS_STORAGE_V1_0_VW AS
 SELECT 
storage_device.name as device_name,
storage_device.management_ip,
storage_device.management_port,
storage_device.service_ip,
storage_device.service_port,
storage_device.storage_technology,
storage_device.username,
storage_device.password,
storage_pool.idStorage,
storage_pool.idStorageDevice,
storage_pool.idTier,
storage_pool.isEnabled,
storage_pool.totalSizeInMb,
storage_pool.usedSizeInMb,
storage_pool.availableSizeInMb,
storage_pool.name as pool_name,
storage_pool.type,
storage_pool.maxVolumes,
storage_pool.usablePercent,
vm.usedSize,
vm.state,
case vm.state when 1 then 'ATTACHED' else 'DETACHED' end as state_description,
-- vm.idImage,
d.template_id,
rls_dc.idDataCenter
 FROM 	kinton.storage_device,
		kinton.storage_pool,
		kinton.volume_management vm,
        kinton.disk d,
		kinton_reporting.RLS_DATACENTER_V1_0_VW  rls_dc
	WHERE	storage_device.id=storage_pool.idStorageDevice
	AND	storage_pool.idStorage=vm.idStorage
	AND	storage_device.idDataCenter=rls_dc.idDataCenter
    AND d.volume_id = vm.idManagement;


DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUALIMAGE_CONVERSIONS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW  kinton_reporting.RLS_VIRTUALIMAGE_CONVERSIONS_V1_0_VW AS
SELECT
repository.idRepository,
repository.idDataCenter,
repository.name as repository_name,
repository.URL,
virtualimage.idImage,
virtualimage.name as virtualimage_name,
virtualimage.description,
d.pathName,
d.hd_required,
virtualimage.ram_required,
virtualimage.cpu_required,
virtualimage.iconUrl,
virtualimage.idCategory,
d.type,
virtualimage.ethDriverType,
virtualimage.idMaster,
virtualimage.idEnterprise,
(
  CASE
    WHEN (Select count(*) from kinton.virtualimage_scope where virtualimage_scope.virtualimage_id = virtualimage.idImage) > 0 THEN 1
    ELSE 0
  END	
) as shared,
virtualimage.ovfid,
d.stateful,
d.diskFileSize,
virtualimage.cost_code,
virtualimage.creation_date,
virtualimage.creation_user,
virtualimage.version_c,
virtualimage.loginUser,
virtualimage.loginPassword,
virtualimage.osType,
virtualimage.osVersion,
d.diskCntrlType,
virtualimage.coresPerSocket,
CASE d.state WHEN 'DONE' THEN true ELSE false END,
virtualimage_conversions.id,
virtualimage_conversions.sourceType,
virtualimage_conversions.targetType,
virtualimage_conversions.sourcePath,
virtualimage_conversions.targetPath,
virtualimage_conversions.state,
virtualimage_conversions.timestamp,
virtualimage_conversions.size
FROM 
	kinton.virtualimage,
	kinton.virtualimage_conversions,
	kinton.repository,
        kinton.disk d,
	kinton_reporting.RLS_DATACENTER_V1_0_VW  rls_dc
WHERE d.disk_id=virtualimage_conversions.disk_id
AND   repository.idRepository=virtualimage.idRepository
AND   repository.idDataCenter=rls_dc.idDataCenter
AND   d.template_id = virtualimage.idImage;

DROP VIEW IF EXISTS kinton_reporting.RLS_NETWORK_INTERFACE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW  kinton_reporting.RLS_NETWORK_INTERFACE_V1_0_VW AS
SELECT
physicalmachine.idPhysicalMachine,
physicalmachine.idRack,
physicalmachine.idDataCenter,
physicalmachine.name as physicalmachine_name,
physicalmachine.description,
physicalmachine.ram,
physicalmachine.cpu,
physicalmachine.idState,
physicalmachine.StateDescription,
physicalmachine.idEnterprise,
physicalmachine.initiatorIQN,
physicalmachine.ipmiIP,
physicalmachine.ipmiPort,
physicalmachine.ipmiUser,
physicalmachine.ipmiPassword,
network_interface.id,
network_interface.name as networkinterface_name,
network_interface.mac,
network_interface.network_service_type_id,
network_interface.physicalmachine_id,
network_service_type.name as networkservicetype_name,
network_service_type.default_nst
FROM 
       kinton_reporting.RLS_PHYSICAL_MACHINE_V1_0_VW physicalmachine
INNER JOIN
       kinton.network_interface
ON (network_interface.physicalmachine_id=physicalmachine.idPhysicalMachine)
LEFT JOIN
       kinton.network_service_type
ON (network_interface.network_service_type_id=network_service_type.id);       

#
# Support RLS Views
# These views are 'helper' views which provide access to other objects defined by the kinton schema
# Often, these objects provide summarised information, removing the need to understand some of the
# more complex joins in the underlying kinton schema tables - thus reducing the complexity and 
# understanding required to write reports and queries.
#

DROP VIEW IF EXISTS kinton_reporting.RLS_ENTERPRISE_LIMITS_BY_DATACENTER_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_ENTERPRISE_LIMITS_BY_DATACENTER_V1_0_VW AS 
#
# View that returns enterprise hard & soft limits that have been explicitly allocated to an individual datacenter
# RLS applied by Enterprise restriction AND the ability to see Physical Datacenter Information
# 
	SELECT eldc.*
    FROM kinton.enterprise_limits_by_datacenter eldc
            INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW rls_e ON (eldc.idEnterprise=rls_e.idEnterprise)
            INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW rls_dc ON (eldc.idDataCenter=rls_dc.idDataCenter);








SELECT "Creating VM-based RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW AS 
#
# View that returns a list of all VMs (and their detailed attributes, including VDC and VApp membership)
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see)
# 
    SELECT vm.*, va.idVirtualApp, va.name AS ApplianceName, rls_vdc.idVirtualDataCenter, rls_vdc.idDataCenter
        FROM kinton.virtualmachine vm
                INNER JOIN kinton.virtualapp va ON (vm.virtual_appliance=va.idVirtualApp)
                INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW rls_vdc ON (va.idVirtualDataCenter=rls_vdc.idVirtualDataCenter);


DROP VIEW IF EXISTS kinton_reporting.RLS_SUM_VM_IN_USE_BY_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_SUM_VM_IN_USE_BY_VDC_V1_0_VW AS
#
# View that returns a sum of all hypervisor-deployed VM resource usage (CPU, Memory, Local Storage), totalled by VDC.
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
# 
    SELECT va.idVirtualDataCenter, vm.idEnterprise, sum(vm.cpu) as cpuused, sum(vm.ram) as ramused, sum(dm.diskFileSize) as hdUsed
        FROM kinton.virtualmachine vm
                INNER JOIN kinton.virtualapp va ON (vm.virtual_appliance=va.idVirtualApp)
                INNER JOIN kinton.rasd_management rm ON rm.idVM=vm.idVM
                INNER JOIN kinton.disk_management dm ON dm.idManagement=rm.idManagement
                INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW rls_vdc ON (va.idVirtualDataCenter=rls_vdc.idVirtualDataCenter)                
        WHERE
            # Exclude VM defintions where the VMs are not in use...
            vm.state <> 'NOT_ALLOCATED' AND vm.state <> 'ALLOCATED' AND vm.state <> 'CONFIGURED' AND vm.state <> 'UNKNOWN'
        GROUP BY va.idVirtualDataCenter;

DROP VIEW IF EXISTS kinton_reporting.RLS_SUM_VM_RESOURCES_BY_STATE_BY_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_SUM_VM_RESOURCES_BY_STATE_BY_VDC_V1_0_VW AS
#
# View that returns a breakdown of VM resources by their state, per VDC
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT  vm.idEnterprise, va.idVirtualDataCenter,
            vm.state AS VMState, COUNT(*) as TotalVMs,
            SUM(vm.cpu) as CPUUsed, SUM(vm.ram) as RAMUsed, SUM(dm.diskFileSize) as HDUsed
            FROM kinton.virtualmachine vm
                INNER JOIN kinton.virtualapp va ON (vm.virtual_appliance=va.idVirtualApp)
                INNER JOIN kinton.rasd_management rm ON rm.idVM=vm.idVM
                INNER JOIN kinton.disk_management dm ON dm.idManagement=rm.idManagement
                INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW rls_vdc ON (va.idVirtualDataCenter=rls_vdc.idVirtualDataCenter)
            GROUP BY va.idVirtualDataCenter, vm.state
            ORDER BY vm.idEnterprise, va.idVirtualDataCenter, vm.state;



DROP VIEW IF EXISTS kinton_reporting.RLS_SUM_VM_DETAILS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_SUM_VM_DETAILS_V1_0_VW AS
#
# View that returns physical & logical VM details, plus numerous other VM details
# (but not including network of VM usage, as we'd need multiple rows for that - we could
# extend the view to count external storage and networks, if required).
# RLS is by ENTERPRISE, VDC and DATACENTER
#
    SELECT  dc.idDataCenter, dc.name AS 'Datacenter',
            r.idRack, r.name AS 'Rack', 
            m.idPhysicalMachine, m.name AS 'Host', h.type AS 'HypervisorType',
            e.idEnterprise, e.name AS 'Enterprise',
            vdc.idVirtualDataCenter, vdc.name AS 'VirtualDatacenter',
            vapp.idVirtualApp, vapp.name AS 'VirtualAppliance',
            vm.idVM, vm.name AS 'VirtualMachine',
            vi.idImage, vi.name AS 'VirtualImage',
            vm.state AS 'VirtualMachineState',
            u.idUser, COALESCE(u.user,'N/A') AS 'Owner',
            cc.idCostCode, cc.name AS 'CostCode',
            vm.cpu AS 'CPU', vm.ram AS 'MemoryMB',
            CAST(dm.diskFileSize/(1048576*1024)AS DECIMAL(28,3)) AS 'LocalStorageGB'

    FROM
        kinton_reporting.RLS_DATACENTER_V1_0_VW AS dc,
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,
        kinton.rack r,
        kinton.physicalmachine m,
        kinton.hypervisor h,
        kinton.virtualapp vapp,
        kinton.virtualmachine vm,
        kinton.user u,
        kinton.rasd_management rm,
        kinton.disk_management dm,
        kinton.disk d,
        kinton.virtualimage vi
        LEFT JOIN kinton.costCode cc ON (vi.cost_code=cc.idCostCode)
    WHERE        
        dc.idDataCenter=r.idDataCenter AND
        r.idRack=m.idRack AND
        e.idEnterprise=vdc.idEnterprise AND
        vdc.idVirtualDataCenter=vapp.idVirtualDataCenter AND
        vapp.idEnterprise=e.idEnterprise AND
	    vm.idUser=u.idUser AND
        vm.idImage=vi.idImage AND
        dm.disk_id = d.disk_id AND 
        rm.idVM = vm.idVM AND
        dm.idManagement = rm.idManagement AND
        h.id=vm.idHypervisor AND
        h.idPhysicalMachine=m.idPhysicalMachine AND
        vm.virtual_appliance=vapp.idVirtualApp AND
        vm.state <> 'NOT_ALLOCATED' AND vm.state <> 'ALLOCATED' AND vm.state <> 'CONFIGURED' AND vm.state <> 'UNKNOWN'
	AND d.state in ('DONE','UNAVAILABLE');

DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW AS 
#
# View that returns a list of all NICs assigned to VMs, including details of the IP, VLAN, and NetworkType
# RLS applied by VDC restriction (i.e. can only see VM data for VMs in VDCs the user is entitled to see) 
# 
    SELECT vm.idVM, vm.virtual_appliance as idVirtualApp, rm.idVirtualDataCenter, vdc.idEnterprise,
           ipm.mac, ipm.ip, vn.vlan_tag, vn.networktype, vn.network_name, vn.vlan_network_id, rm.sequence
    FROM
        kinton.rasd r
        INNER JOIN kinton.rasd_management rm ON rm.idResource=r.instanceID
        INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vdc.idVirtualDataCenter=rm.idVirtualDataCenter
        INNER JOIN kinton.ip_pool_management ipm ON rm.idManagement=ipm.idManagement
        LEFT JOIN kinton.virtualmachine vm ON rm.idVM=vm.idVM
        LEFT JOIN kinton.vlan_network vn ON ipm.vlan_network_id=vn.vlan_network_id
    WHERE
       rm.idResourceType=10;


DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW AS 
#
# View that returns a list of all external volumes assigned to VMs, including details of the 
# associated storage devices, pools and tiers
# RLS applied by VDC restriction (i.e. can only see VM data for VMs in VDCs the user is entitled to see) 
# 
    SELECT vmc.idVM, vmc.virtual_appliance as idVirtualApp, rm.idVirtualDataCenter, vdc.idEnterprise,
           elementName AS VolumeName, CAST(limitResource/1024 AS DECIMAL(28,2)) AS DiskGB, d.sequence,
           t.name AS StorageTier, connectionResource AS Location, sd.name AS StorageDevice, sp.name AS StoragePool,
           d.template_id # Can be used to identify persistent volumes...
    FROM
        kinton.rasd r
        INNER JOIN kinton.rasd_management rm ON rm.idResource=r.instanceID
        INNER JOIN kinton.virtualmachine vmc ON rm.idVM = vmc.idVM
        INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vdc.idVirtualDataCenter=rm.idVirtualDataCenter
        INNER JOIN kinton.volume_management vm ON rm.idManagement=vm.idManagement
        INNER JOIN kinton.disk d ON vm.idManagement=d.volume_id
        INNER JOIN kinton.storage_pool sp ON sp.idStorage=vm.idStorage
        INNER JOIN kinton.storage_device sd ON sd.id=sp.idStorageDevice
        INNER JOIN kinton.tier t ON sp.idTier=t.id
    WHERE
       rm.idResourceType=8;


DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW AS 
#
# View that returns a list of all local volumes assigned to VMs, including details
# RLS applied by VDC restriction (i.e. can only see VM data for VMs in VDCs the user is entitled to see) 
# 
    SELECT vm.idVM, vm.virtual_appliance AS idVirtualApp, rm.idVirtualDataCenter, vdc.idEnterprise,
           elementName, CAST(limitResource/1024 AS DECIMAL(28,2)) AS DiskGB, sequence, 
           IF(dm.idDatastore IS NOT NULL, dm.idDatastore, null) AS idDatastore
    FROM
        kinton.rasd r
        INNER JOIN kinton.rasd_management rm ON rm.idResource=r.instanceID        
        INNER JOIN kinton.virtualmachine vm ON vm.idVM=rm.idVM
        INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vdc.idVirtualDataCenter=rm.idVirtualDataCenter
        INNER JOIN kinton.disk_management dm ON rm.idManagement=dm.idManagement
    WHERE
       rm.idResourceType=17;





SELECT "Creating Network-based RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.INT_VLANS_USED_BY_VDC_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.INT_VLANS_USED_BY_VDC_VW AS
#
# INTERNAL (Non-RLS) View which counts all networks (VLANs) by VDC
#
    SELECT vdc.idVirtualdataCenter, vdc.idEnterprise, COUNT(DISTINCT(vn.vlan_network_id)) AS totalVlansUsed, SUM(IF(rm.idVM IS NOT NULL, 1, 0)) AS totalIPsUsed
        FROM kinton_reporting.RLS_VDC_V1_0_VW vdc, kinton.vlan_network vn, kinton.ip_pool_management ipm, kinton.rasd_management rm
        WHERE
            ipm.vlan_network_id = vn.vlan_network_id AND
            rm.idManagement = ipm.idManagement AND
            rm.idVirtualDataCenter=vdc.idVirtualDataCenter
        GROUP BY vdc.idVirtualDataCenter;

DROP VIEW IF EXISTS kinton_reporting.INT_PUBLIC_IP_USED_BY_VDC_VW;
#
# INTERNAL (Non-RLS) View which counts IP Addresses allocated to VMs by VDC (Note: Does NOT include reserved IPs)
#
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.INT_PUBLIC_IP_USED_BY_VDC_VW AS
    SELECT vdc.idVirtualdataCenter, vdc.idEnterprise, COUNT(DISTINCT(vn.vlan_network_id)) AS publicNetworksUsed, COUNT(*) AS publicIPsReserved, SUM(IF(rm.idVM IS NOT NULL, 1, 0)) AS publicIPsUsed
        FROM kinton_reporting.RLS_VDC_V1_0_VW vdc, kinton.vlan_network vn, kinton.ip_pool_management ipm, kinton.rasd_management rm
        WHERE
            vn.networktype = 'PUBLIC' AND
            ipm.vlan_network_id = vn.vlan_network_id AND
            rm.idManagement = ipm.idManagement AND
            rm.idVirtualDataCenter=vdc.idVirtualDataCenter 
        GROUP BY vdc.idVirtualDataCenter;


DROP VIEW IF EXISTS kinton_reporting.INT_INTERNAL_NETWORKS_USED_BY_VDC_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.INT_INTERNAL_NETWORKS_USED_BY_VDC_VW AS
#
# INTERNAL (Non-RLS) View which counts 'Internal/Private' Networks by VDC
#
    SELECT vdc.idVirtualdataCenter, vdc.idEnterprise, COUNT(DISTINCT(vn.vlan_network_id)) AS internalNetworksUsed, SUM(IF(rm.idVM IS NOT NULL, 1, 0)) AS internalIPsUsed
        FROM kinton_reporting.RLS_VDC_V1_0_VW vdc, kinton.vlan_network vn, kinton.ip_pool_management ipm, kinton.rasd_management rm
        WHERE
            vn.networktype = 'INTERNAL' AND
            ipm.vlan_network_id = vn.vlan_network_id AND
            rm.idManagement = ipm.idManagement AND
            rm.idVirtualDataCenter=vdc.idVirtualDataCenter 
        GROUP BY vdc.idVirtualDataCenter;

DROP VIEW IF EXISTS kinton_reporting.INT_EXTERNAL_NETWORKS_USED_BY_VDC_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.INT_EXTERNAL_NETWORKS_USED_BY_VDC_VW AS
#
# INTERNAL (Non-RLS) View which counts 'External' Networks by VDC
#
SELECT vdc.idVirtualDataCenter, vdc.idEnterprise, COUNT(DISTINCT(vn.vlan_network_id)) AS externalNetworksUsed, SUM(IF(rm.idVM IS NOT NULL, 1, 0)) AS externalIPsUsed
        FROM kinton_reporting.RLS_VDC_V1_0_VW vdc, kinton.vlan_network vn, kinton.ip_pool_management ipm, kinton.rasd_management rm
        WHERE
            vn.networktype = 'EXTERNAL' AND
            ipm.vlan_network_id = vn.vlan_network_id AND
            rm.idManagement = ipm.idManagement AND
            rm.idVirtualDataCenter=vdc.idVirtualDataCenter
        GROUP BY vdc.idVirtualDataCenter;

DROP VIEW IF EXISTS kinton_reporting.RLS_NETWORK_USED_BY_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_NETWORK_USED_BY_VDC_V1_0_VW AS
#
# View that returns a sum of all network resource usage (Total VLANs,Internal,External,Public), totalled by VDC.
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT  vdc.idVirtualDataCenter, vdc.idEnterprise,
            IF(totalVlansUsed IS NULL, 0, totalVlansUsed) AS totalVlansUsed, IF(totalIPsUsed IS NULL, 0, totalIPsUsed) AS totalIPsUsed,
            IF(internalNetworksUsed IS NULL, 0, internalNetworksUsed) AS internalNetworksUsed, IF(internalIPsUsed IS NULL, 0, internalIPsUsed) AS internalIPsUsed,
            IF(externalNetworksUsed IS NULL, 0, externalNetworksUsed) AS externalNetworksUsed, IF(externalIPsUsed IS NULL, 0, externalIPsUsed) AS externalIPsUsed,
            IF(publicNetworksUsed IS NULL, 0, publicNetworksUsed) AS publicNetworksUsed, IF(publicIPsUsed IS NULL, 0, publicIPsUsed) AS publicIPsUsed
    FROM kinton_reporting.RLS_VDC_V1_0_VW vdc

        LEFT JOIN kinton_reporting.INT_VLANS_USED_BY_VDC_VW AS vdcTovlanMapping
            ON (vdc.idVirtualDataCenter=vdcTovlanMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_PUBLIC_IP_USED_BY_VDC_VW AS vdcToPublicIPMapping
            ON (vdc.idVirtualDataCenter=vdcToPublicIPMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_INTERNAL_NETWORKS_USED_BY_VDC_VW AS vdcToInternalMapping
            ON (vdc.idVirtualDataCenter=vdcToInternalMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_EXTERNAL_NETWORKS_USED_BY_VDC_VW AS vdcToExternalMapping
            ON (vdc.idVirtualDataCenter=vdcToExternalMapping.idVirtualDataCenter);



DROP VIEW IF EXISTS kinton_reporting.RLS_NETWORK_USED_BY_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_NETWORK_USED_BY_ENTERPRISE_V1_0_VW AS
#
# View that returns a sum of all network resource usage (Total VLANs, Internal,External,Public), totalled by ENTERPRISE.
# RLS applied by ENTERPRISE restriction (i.e. can only see data for Enterprises the user is entitled to see) 
#
    SELECT  vdc.idEnterprise,
            SUM(COALESCE(totalVlansUsed,0)) AS totalVlansUsed, SUM(COALESCE(totalIPsUsed,0)) AS totalIPsUsed,
            SUM(COALESCE(internalNetworksUsed,0)) AS internalNetworksUsed, SUM(COALESCE(internalIPsUsed,0)) AS internalIPsUsed,
            SUM(COALESCE(externalNetworksUsed,0)) AS externalNetworksUsed, SUM(COALESCE(externalIPsUsed,0)) AS externalIPsUsed,
            SUM(COALESCE(publicNetworksUsed,0)) AS publicNetworksUsed, SUM(COALESCE(publicIPsUsed,0)) AS publicIPsUsed
    FROM kinton_reporting.RLS_VDC_V1_0_VW vdc

        LEFT JOIN kinton_reporting.INT_VLANS_USED_BY_VDC_VW AS vdcTovlanMapping
            ON (vdc.idVirtualDataCenter=vdcTovlanMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_PUBLIC_IP_USED_BY_VDC_VW AS vdcToPublicIPMapping
            ON (vdc.idVirtualDataCenter=vdcToPublicIPMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_INTERNAL_NETWORKS_USED_BY_VDC_VW AS vdcToInternalMapping
            ON (vdc.idVirtualDataCenter=vdcToInternalMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.INT_EXTERNAL_NETWORKS_USED_BY_VDC_VW AS vdcToExternalMapping
            ON (vdc.idVirtualDataCenter=vdcToExternalMapping.idVirtualDataCenter)
    GROUP BY vdc.idEnterprise;









SELECT "Creating Storage-based RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_USED_BY_VM_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_USED_BY_VM_V1_0_VW AS
#
# View that returns details of external storage usage, summed at VM level.
# Note: This view is independent of storage tiers - please use RLS_STORAGE_TIER_USED_BY_VM_V1_0_VW
# for a tier-based breakdown by VDC
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT vm.idVM, vm.idEnterprise, vm.idVirtualDataCenter,
            SUM(limitResource) AS extStorageMBAllocated
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management volMgmt, kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
            WHERE rm.idResource = r.instanceID AND resourcetype=8 AND
                volMgmt.idManagement=rm.idManagement AND
                vm.idVM=rm.idVM AND
                (volMgmt.state=1 OR volMgmt.state=2)
        GROUP BY idVM;


DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_TIER_USED_BY_VM_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_TIER_USED_BY_VM_V1_0_VW AS
#
# View that returns details of external storage usage by storage tier, summed at VM level.
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT vm.idVM, vm.idEnterprise, vm.idVirtualDataCenter, sp.idTier,
            SUM(limitResource) AS extStorageMBAllocated
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management volMgmt, kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm,
                kinton.storage_pool sp
            WHERE rm.idResource = r.instanceID AND resourcetype=8 AND
                volMgmt.idManagement=rm.idManagement AND
                vm.idVM=rm.idVM AND
                (volMgmt.state=1 OR volMgmt.state=2) AND
                volMgmt.idStorage=sp.idStorage
        GROUP BY idVM, sp.idTier;




DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_USED_BY_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_USED_BY_VDC_V1_0_VW AS
#
# View that returns details of external storage usage, summed at VDC level.
# Note: This view is independent of storage tiers - please use RLS_STORAGE_TIER_USED_BY_VDC_V1_0_VW
# for a tier-based breakdown by VDC
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT vdc.idDataCenter, vdc.idEnterprise, vdc.idVirtualDataCenter,
            SUM(limitResource) AS extStorageMBAllocated, SUM(IF(rm.idVM IS NOT NULL AND (vm.state=1 OR vm.state=2), limitResource, 0)) AS extStorageMBAssignedToVMs
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management vm,
                 kinton_reporting.RLS_VDC_V1_0_VW vdc
            WHERE
                rm.idResource = r.instanceID AND
                resourcetype=8 AND
                vm.idManagement=rm.idManagement AND
                vdc.idVirtualDataCenter=rm.idVirtualDataCenter
            GROUP BY vdc.idVirtualDataCenter;


DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_TIER_USED_BY_VDC_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_TIER_USED_BY_VDC_V1_0_VW AS
#
# View that returns details of external storage usage by storage tier, summed at VDC level.
# RLS applied by VDC restriction (i.e. can only see data for VDCs the user is entitled to see) 
#
    SELECT vdc.idDataCenter, vdc.idEnterprise, vdc.idVirtualDataCenter, sp.idTier, 
            SUM(limitResource) as extStorageMBAllocated, SUM(IF(rm.idVM IS NOT NULL AND (vm.state=1 OR vm.state=2), limitResource, 0)) AS extStorageMBAssignedToVMs
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management vm, kinton.storage_pool sp,
                 kinton_reporting.RLS_VDC_V1_0_VW vdc
            WHERE
                rm.idResource = r.instanceID AND
                resourcetype=8 AND
                vm.idManagement=rm.idManagement AND
                vm.idStorage=sp.idStorage AND
                vdc.idVirtualDataCenter=rm.idVirtualDataCenter
            GROUP BY vdc.idVirtualDataCenter, sp.idTier;



DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_USED_BY_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_USED_BY_ENTERPRISE_V1_0_VW AS
#
# View that returns details of external storage usage, summed at ENTERPRISE level.
# Note: This view is independent of storage tiers - please use RLS_STORAGE_TIER_USED_BY_ENTERPRISE_V1_0_VW
# for a tier-based breakdown by ENTERPRISE
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT vdc.idDataCenter, vdc.idEnterprise,
            SUM(limitResource) AS extStorageMBAllocated, SUM(IF(rm.idVM IS NOT NULL AND (vm.state=1 OR vm.state=2), limitResource, 0)) AS extStorageMBAssignedToVMs
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management vm,
                 kinton_reporting.RLS_VDC_V1_0_VW vdc
            WHERE
                rm.idResource = r.instanceID AND
                resourcetype=8 AND
                vm.idManagement=rm.idManagement AND
                vdc.idVirtualDataCenter=rm.idVirtualDataCenter
            GROUP BY vdc.idEnterprise;


DROP VIEW IF EXISTS kinton_reporting.RLS_STORAGE_TIER_USED_BY_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_STORAGE_TIER_USED_BY_ENTERPRISE_V1_0_VW AS
#
# View that returns details of external storage usage by storage tier, summed at ENTERPRISE level.
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT vdc.idDataCenter, vdc.idEnterprise, sp.idTier, 
            SUM(limitResource) as extStorageMBAllocated, SUM(IF(rm.idVM IS NOT NULL AND (vm.state=1 OR vm.state=2), limitResource, 0)) AS extStorageMBAssignedToVMs
            FROM kinton.rasd r, kinton.rasd_management rm, kinton.volume_management vm, kinton.storage_pool sp,
                 kinton_reporting.RLS_VDC_V1_0_VW vdc
            WHERE
                rm.idResource = r.instanceID AND
                resourcetype=8 AND
                vm.idManagement=rm.idManagement AND
                vm.idStorage=sp.idStorage AND
                vdc.idVirtualDataCenter=rm.idVirtualDataCenter
            GROUP BY vdc.idEnterprise, sp.idTier;







SELECT "Creating Repository-based RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.RLS_REPOSITORY_USED_BY_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_REPOSITORY_USED_BY_ENTERPRISE_V1_0_VW AS
#
# View that returns details of repository usage, summed at ENTERPRISE level.
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT e.idEnterprise, SUM(d.diskFileSize)/(1048576*1024) AS repositoryUsageGB
            FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e 
                JOIN kinton.virtualimage vi ON (e.idEnterprise=vi.idEnterprise)
                JOIN kinton.disk d ON (d.template_id=vi.idImage)
            WHERE
                d.stateful=false # Exclude persisent images, they are in external storage, not in the NFS repository!
            AND d.state='DONE'
            GROUP BY e.idEnterprise;

DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW AS
#
# View that returns details of virtual images from the kinton virtualimage table
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT vi.*,
       (
        CASE
          WHEN count(s. virtualImage_id) > 0 THEN 1
          ELSE 0
	END
       ) AS shared
      FROM kinton.virtualimage vi
        LEFT JOIN kinton.virtualimage_scope s ON (s. virtualImage_id = vi.idImage)
        JOIN kinton.disk d ON (d.template_id=vi.idImage)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idEnterprise=vi.idEnterprise)
       WHERE d.state in ('DONE','UNAVAILABLE')
       GROUP BY vi.idImage, d.disk_id;


DROP VIEW IF EXISTS kinton_reporting.RLS_VIRTUAL_IMAGE_USE_BY_ENTERPRISE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VIRTUAL_IMAGE_USE_BY_ENTERPRISE_V1_0_VW AS
#
# View that returns IDs of images (and the enterprises which own them) along with counts of the
# VMs using the image.
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT  e.idEnterprise, vi.idImage,
                    COALESCE(COUNT(*),0) AS vmsUsingImage,
                    COALESCE( SUM(IF(vm.idEnterprise=vi.idEnterprise,0,1)),0) AS vmsInOtherEnterpiseUsingImage
            FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                    JOIN kinton.virtualimage vi ON (vi.idImage=vm.idImage)
                    JOIN kinton.disk d ON (d.template_id=vi.idImage)
                    JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (vi.idEnterprise=e.idEnterprise)
            WHERE d.state='DONE'
            GROUP BY e.idEnterprise, vi.idImage;






SELECT "Creating Pricing-based RLS Views..." AS " ";

DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_TEMPLATE_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_TEMPLATE_V1_0_VW AS
#
# View that returns pricing template and currency details
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT e.idEnterprise, p.idPricingTemplate, p.idCurrency, p.name, p.chargingPeriod, p.minimumCharge, p.showChangesBefore, p.standingChargePeriod, p.minimumChargePeriod, p.defaultTemplate, p.description, pa.*, c.symbol, c.name AS currencyName, c.digits
    FROM kinton.pricingTemplate p
        JOIN kinton.pricing_abstract_datacenter pa ON (pa.pricing_template_id = p.idPricingTemplate)
        JOIN kinton.currency c ON (c.idCurrency=p.idCurrency)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idPricingTemplate=p.idPricingTemplate);



DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_TIERS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_TIERS_V1_0_VW AS
#
# View that returns pricing information for the storage tiers
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT e.idEnterprise, t.id AS idTier, t.name, pt.pricing_abstract_datacenter_id, pt.price, c.symbol, c.name AS currencyName, c.digits 
    FROM kinton.pricingTier pt
        JOIN kinton.tier t ON (t.id=pt.idTier)
        JOIN kinton.pricing_abstract_datacenter p ON (pt.pricing_abstract_datacenter_id=p.id)
        JOIN kinton.pricingTemplate tp ON (p.pricing_template_id = tp.idPricingTemplate)
        JOIN kinton.currency c ON (c.idCurrency=tp.idCurrency)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idPricingTemplate=p.pricing_template_id);

DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW AS


# View that returns pricing information for the storage tiers
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see)
#
    SELECT e.idEnterprise, t.id AS idTier, t.name, pt.pricing_abstract_datacenter_id, pt.price, c.symbol, c.name AS currencyName, c.digits
    FROM kinton.pricing_datastore_tier pt
        JOIN kinton.datastore_tier t ON (t.id=pt.datastore_tier_id)
        JOIN kinton.pricing_abstract_datacenter p ON (pt.pricing_abstract_datacenter_id=p.id)
        JOIN kinton.pricingTemplate tp ON (p.pricing_template_id = tp.idPricingTemplate)
        JOIN kinton.currency c ON (c.idCurrency=tp.idCurrency)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idPricingTemplate=p.pricing_template_id);

DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW AS


# View that returns pricing information for the storage tiers
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see)
#
    SELECT e.idEnterprise, b.id AS idBackup, b.code, b.name, pt.pricing_abstract_datacenter_id, pt.price, c.symbol, c.name AS currencyName, c.digits
    FROM kinton.pricing_backup pt
        JOIN kinton.backup_policy b ON (b.id=pt.backup_id)
        JOIN kinton.pricing_abstract_datacenter p ON (pt.pricing_abstract_datacenter_id=p.id)
        JOIN kinton.pricingTemplate tp ON (p.pricing_template_id = tp.idPricingTemplate)
        JOIN kinton.currency c ON (c.idCurrency=tp.idCurrency)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idPricingTemplate=p.pricing_template_id);


DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW AS
#
# View that returns pricing information for cost codes
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT  e.idEnterprise,
            cc.idCostCode, cc.name AS costCodeName,
            pcc.idPricingTemplate,
            IF(pcc.price IS NOT NULL, pcc.price, ccc.price) as price,
            c.symbol, c.name AS currencyName, c.digits
    FROM kinton.pricingCostCode pcc
        JOIN kinton.pricingTemplate p ON (pcc.idPricingTemplate=p.idPricingTemplate)
        JOIN kinton.costCode cc ON (cc.idCostCode=pcc.idCostCode)
        JOIN kinton.costCodeCurrency ccc ON (cc.idCostCode=ccc.idCostCode AND ccc.idCurrency=p.idCurrency)
        JOIN kinton.currency c ON (c.idCurrency=ccc.idCurrency)
        JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW e ON (e.idPricingTemplate=pcc.idPricingTemplate);


DROP VIEW IF EXISTS kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS
#
# View that returns pricing information 'per hour' (i.e. for a given Enterprise's pricing template, works
# out how one hour's resource usage costs).
# RLS applied by ENTERPRISE restriction (i.e. can only see data for ENTERPRISES the user is entitled to see) 
#
    SELECT      e.idEnterprise,
                    p.vcpu  AS cpu,
		    p.vcpu_on AS cpu_on,
		    p.vcpu_off AS cpu_off,
                    p.memoryGB AS memoryGB,
		    p.memoryGB_on AS memoryGB_on,
		    p.memoryGB_off AS memoryGB_off,
                    p.hdGB AS hdGB,
                    p.publicIp AS ip,
                    p.vlan AS vlan,
                    p.firewall,
                    p.load_balancer,
                    p.repositoryGB,
                    tp.standingChargePeriod AS standingCharge, 
                    tp.minimumChargePeriod AS minimumCharge,
                    tp.chargingPeriod,
                    CASE tp.chargingPeriod
                        #WHEN 0 THEN 'Minute'
                        #WHEN 1 THEN 'Hour'
                        WHEN 2 THEN 'Day'
                        WHEN 3 THEN 'Week'
                        WHEN 4 THEN 'Month'
                        WHEN 5 THEN 'Quarter'
                        WHEN 6 THEN 'Year'
                    END AS chargingPeriodName,
                    CASE tp.chargingPeriod
                        #WHEN 0 THEN 60  #Minute
                        #WHEN 1 THEN 1    #Hour
                        WHEN 2 THEN 1*24 # Day
                        WHEN 3 THEN 7*24     # Week
                        WHEN 4 THEN 30*24    # Month
                        WHEN 5 THEN 91.25*24 # Quarter
                        WHEN 6 THEN 365*24   # Year
                    END AS priceToHourConversion, # used to calculate the price per hourly unit
                    CASE ap.paramValue
                        WHEN 'HOUR' THEN 1
                        WHEN 'DAY' THEN 24
                        WHEN 'WEEK' THEN 7*24
                        WHEN 'MONTH' THEN 30*24
                    END AS usageToHourConversion,
                    c.idCurrency,
                    c.symbol  AS currency,
	            p.abstract_datacenter_id AS id_datacenter	
            FROM
                kinton_reporting.RLS_ENTERPRISE_V1_0_VW e,
                kinton.pricing_abstract_datacenter p,
                kinton.pricingTemplate tp,
                kinton.currency c
                LEFT JOIN kinton_accounting.accounting_parameters ap ON (ap.paramName='AccountPeriodGranularity')
            WHERE
                e.idPricingTemplate=tp.idPricingTemplate AND
                tp.idPricingTemplate = p.pricing_template_id AND
                tp.idCurrency=c.idCurrency;

   
DROP VIEW IF EXISTS kinton_reporting.RLS_VAPP_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_VAPP_V1_0_VW AS
    SELECT v.* 
    FROM 
        kinton.virtualapp v
        INNER JOIN
            kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
            ON (v.idEnterprise=e.idEnterprise)
        INNER JOIN
            kinton_reporting.RLS_VDC_V1_0_VW vdc
            ON (vdc.idVirtualDataCenter=v.idVirtualDataCenter);
   
   
DROP VIEW IF EXISTS kinton_reporting.RLS_EVENTS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_EVENTS_V1_0_VW AS
#
# Basic Query to form the basis of an RLS View over the event table
#
SELECT  timestamp AS EventTime,
        severity AS Severity,
        m.id_enterprise AS idEnterprise, 
        e.name AS Enterprise,
        vdc.idVirtualDataCenter, 
        vdc.name AS VirtualDataCenter,
        vapp.name AS VirtualAppliance, 
        id_user AS idUser,
        user_name AS User, 
        entity_name AS Component, 
        action AS Action, 
        message AS EventMessage
FROM
    kinton.event_tag et,
    kinton.tag t
    LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
    kinton.event m   
    LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_enterprise=e.idEnterprise)
    LEFT JOIN kinton_reporting.RLS_VAPP_V1_0_VW AS vapp ON (m.id_enterprise=vapp.idEnterprise)
WHERE
    m.id = et.id_event AND
    et.id_tag = t.id AND
    ((e.idEnterprise IS NOT NULL) OR m.id_enterprise=e.idEnterprise) AND
    (m.action like "login" OR t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter));


DROP VIEW IF EXISTS kinton_reporting.RLS_USER_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_USER_V1_0_VW AS
    SELECT u.* 
    FROM 
        kinton.user u
        INNER JOIN
            kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
            ON (u.idEnterprise=e.idEnterprise);


DROP VIEW IF EXISTS kinton_reporting.RLS_ADD_REMOVE_EVENTS_V1_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_ADD_REMOVE_EVENTS_V1_0_VW AS
    SElECT
        e.idEnterprise,
        e.name,
        timestamp AS EventTime,
        entity_type AS Component, 
        case when action like 'CREATE' then 1 else 0 end as ADD_EVENT ,
        case when (action like 'DELETE' OR action like 'DESTROYED' or action = 'VSM_VM_MOVED' or action = 'MOVE_BY_HA') then 1 else 0 end as REMOVE_EVENT,
        case when action like 'CREATE' then 1 when (action like 'DELETE' OR action like 'DESTROYED' or action = 'VSM_VM_MOVED' or action = 'MOVE_BY_HA') then -1 else 0 end as ADD_REMOVE_DELTA
    FROM    kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_enterprise=e.idEnterprise)
    WHERE   m.id = et.id_event
        AND et.id_tag = t.id
        AND (m.action like 'CREATE' or m.action like 'DELETE'  or  m.action like 'DESTROYED' or m.action = 'VSM_VM_MOVED' or m.action = 'MOVE_BY_HA')
        AND m.entity_type in ('USER','ENTERPRISE','VIRTUAL_MACHINE','VIRTUAL_APPLIANCE','VIRTUAL_DATACENTER')
        AND ((e.idEnterprise IS NOT NULL) OR m.id_enterprise=e.idEnterprise or m.id_enterprise=0) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter);


DROP FUNCTION IF EXISTS kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0;
DELIMITER $$
CREATE FUNCTION kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(p_stacktrace text,p_tok1 char(64),p_tok2 char(64))
returns char(64) DETERMINISTIC  NO SQL
BEGIN
	if(p_stacktrace NOT LIKE '%Enterprise: ''%')
	then
		return substr(p_stacktrace,locate(p_tok1, p_stacktrace)+length(p_tok1)+1,locate(p_tok2, p_stacktrace)-2-(locate(p_tok1, p_stacktrace)+length(p_tok1)));
	else
		return substr(p_stacktrace,locate(p_tok1, p_stacktrace)+length(p_tok1)+2,locate(p_tok2, p_stacktrace)-2-(locate(p_tok1, p_stacktrace)+length(p_tok1)+2));
	end if;
END$$
DELIMITER ;

DROP VIEW IF EXISTS kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW AS
    SELECT
        1 as dbg,
        m.id,
        e.idEnterprise,
        e.name,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed, 
        case when action like 'CREATE' then 1 else 0 end as ADD_EVENT ,
        case when action like 'DELETE' then 1 else 0 end as REMOVE_EVENT,
        case when action like 'CREATE' then 1 when  action like 'DELETE' then -1 else 0 end as ADD_REMOVE_DELTA
    FROM 
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_enterprise=e.idEnterprise)
    WHERE 
        m.id = et.id_event
        AND et.id_tag = t.id
        AND (action like 'CREATE' or action like 'DELETE')
        AND entity_type in ('USER','ENTERPRISE','VIRTUAL_MACHINE','VIRTUAL_APPLIANCE','VIRTUAL_DATACENTER')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_enterprise=e.idEnterprise) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)
	UNION 
	SELECT
        2 as dbg,
        m.id,
        e.idEnterprise,
        e.name,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed,
        0 as ADD_EVENT,
        1 as REMOVE_EVENT,
        -1 as ADD_REMOVE_DELTA
    FROM    
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_enterprise=e.idEnterprise)
    WHERE
        m.id = et.id_event
        AND et.id_tag = t.id
        AND entity_type ='USER'
        AND action = 'MODIFY'
        AND m.enterprise_name != kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_enterprise=e.idEnterprise) 
        AND (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter))
	UNION 
	SELECT 
        3 as dbg,
        m.id,
        m.id_Enterprise,
        kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:') as name,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed,
        1 as ADD_EVENT,
        0 as REMOVE_EVENT,
        1 as ADD_REMOVE_DELTA
    FROM
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m   
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_Enterprise=e.idEnterprise)
    WHERE 
        m.id = et.id_event
        AND et.id_tag = t.id
        AND entity_type ='USER'
        AND action = 'MODIFY'
        AND m.enterprise_name != kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_Enterprise=e.idEnterprise) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter);


DROP VIEW IF EXISTS kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW;
CREATE SQL SECURITY DEFINER VIEW kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW AS
    SELECT
        1 as dbg,
        m.id,
        e.idEnterprise,
        e.name,
        vdc.idVirtualDataCenter,
        vdc.name as VDCName,
        case when entity_type like 'VIRTUAL_MACHINE' then SUBSTRING_INDEX(entity_uri,'/',-1)  else NULL end as idVM,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed,
        case when action like 'CREATE' then 1 else 0 end as ADD_EVENT ,
        case when action like 'DELETE' then 1 else 0 end as REMOVE_EVENT,
        case when action like 'CREATE' then 1 when  action like 'DELETE' then -1 else 0 end as ADD_REMOVE_DELTA
    FROM 
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_Enterprise=e.idEnterprise)
    WHERE
        m.id = et.id_event
        AND et.id_tag = t.id
        AND (action like 'CREATE' or action like 'DELETE')
        AND entity_type in ('USER','ENTERPRISE','VIRTUAL_MACHINE','VIRTUAL_APPLIANCE','VIRTUAL_DATACENTER')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_Enterprise=e.idEnterprise) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)
	UNION 
	SELECT
        2 as dbg,
        m.id,
        e.idEnterprise,
        e.name,
        vdc.idVirtualDataCenter,
        vdc.name as VDCName,
        case when entity_type like 'VIRTUAL_MACHINE' then SUBSTRING_INDEX(entity_uri,'/',-1)  else NULL end as idVM,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed,
        0 as ADD_EVENT,
        1 as REMOVE_EVENT,
        -1 as ADD_REMOVE_DELTA
    FROM 
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_Enterprise=e.idEnterprise)
    WHERE 
        m.id = et.id_event
        AND et.id_tag = t.id
        AND m.entity_type ='USER'
        AND action = 'MODIFY'
        AND m.enterprise_name != kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_Enterprise=e.idEnterprise) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)
	UNION 
	SELECT
        3 as dbg,
        m.id,
        m.id_Enterprise,
        kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:') as name,
        vdc.idVirtualDataCenter,
        vdc.name as VDCName,
        case when entity_type like 'VIRTUAL_MACHINE' then SUBSTRING_INDEX(entity_uri,'/',-1)  else NULL end as idVM,
        timestamp AS EventTime,
        entity_type AS Component,
        CONCAT(entity_type,'_',action) as Actionperformed,
        1 as ADD_EVENT,
        0 as REMOVE_EVENT,
        1 as ADD_REMOVE_DELTA
    FROM  
        kinton.event_tag et,
        kinton.tag t
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter)),
        kinton.event m
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e ON (m.id_Enterprise=e.idEnterprise)
    WHERE    
        m.id = et.id_event
        AND et.id_tag = t.id
        AND entity_type ='USER'
        AND action = 'MODIFY'
        AND m.enterprise_name != kinton_reporting.RPT_Common_Extract_Stack_Trace_v1_0(message,'Enterprise:','Name:')
        AND ((e.idEnterprise IS NOT NULL ) OR m.id_Enterprise=e.idEnterprise) 
        AND t.value LIKE CONCAT('virtualdatacenter:',vdc.idVirtualDataCenter);

#
# TODO - Views for other groups of Abiquo data, as needed
# (e.g. Users, Infrastructure details, conversions, log messages)

SELECT "RLS reporting schema installed successfully!" AS " ";
