SELECT "Creating procedure for the Infrastructure Growth report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_InfrastructureGrowth_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_InfrastructureGrowth_v1_0(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Infrastructure Growth Report
    # Procedure Version : 2.6.0
    #
    ##########################################################################################

    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # TODO - Add RLS Support here!
    SELECT
        StartDate,
        NumRows/AccountedHours AS NumRows,
        vCPU/AccountedHours AS vCPU,
        vRAM/AccountedHours AS vRAM,
        HD/AccountedHours HD,
        ExternalDisk/AccountedHours AS ExternalDisk,
        vLAN/AccountedHours AS vLAN,
        publicIP/AccountedHours AS publicIP,
        ESX_VMs/AccountedHours AS ESX_VMs,
        KVM_VMs/AccountedHours AS KVM_VMs,
        ORACLEVM_VMs/AccountedHours AS ORACLEVM_VMs,
        HYPERV_VMs/AccountedHours AS HYPERV_VMs,
        AMAZON_VMs/AccountedHours AS AMAZON_VMs,
        XENSERVER_VMs/AccountedHours AS XENSERVER_VMs
    FROM
       (SELECT
        CAST(aed.startTime as date) as StartDate,
        COUNT(*) AS NumRows,
        SUM(IF(idAccountingResourceType=1,resourceUnits,0)) AS vCPU,
        SUM(IF(idAccountingResourceType=2,resourceUnits,0))/1024 AS vRAM,
        SUM(IF(idAccountingResourceType=3,resourceUnits,0))/1048576/1024 AS HD,
        SUM(IF(idAccountingResourceType=4,resourceUnits,0))/1048576/1024 AS ExternalDisk,
        SUM(IF(idAccountingResourceType=6,resourceUnits,0)) AS vLAN,
        SUM(IF(idAccountingResourceType=5,resourceUnits,0)) AS publicIP,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='VMX_04',resourceUnits,0)) AS ESX_VMs,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='KVM',resourceUnits,0)) AS KVM_VMs,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='ORACLE_VM',resourceUnits,0)) AS ORACLEVM_VMs,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='HYPERV_301',resourceUnits,0)) AS HYPERV_VMs,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='AMAZON',resourceUnits,0)) AS AMAZON_VMs,
        SUM(IF(idAccountingResourceType=7 AND vmType.objectName='XENSERVER',resourceUnits,0)) AS XENSERVER_VMs,
        COUNT(DISTINCT(HOUR(aed.startTime))) AS AccountedHours
        FROM
            kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent,
            kinton_accounting.accounting_event_detail aed        
            LEFT JOIN kinton_accounting.object_name vmType
                ON aed.resourceName=vmType.idObject
        WHERE
            aed.idEnterprise=ent.idEnterprise AND
            aed.startTime >= p_startDate AND aed.startTime < p_endDate
        GROUP BY CAST(aed.startTime AS date)) t;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
