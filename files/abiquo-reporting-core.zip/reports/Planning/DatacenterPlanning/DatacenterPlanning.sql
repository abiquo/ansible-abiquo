SELECT "Creating procedures for the Datacenter Resource Planning report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_DatacenterPlanning_DC_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_DatacenterPlanning_DC_v1_0(rls_abiquo_user VARCHAR(128) )
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Datacenter Resource Planning Report SP- Datacenter level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  entUsage.name AS 'DataCenter', NULL AS 'Enterprise Name',	NULL AS 'Virtual Data Center',
            (aggregatedLimits.cpuHard) AS 'CPU Reserved',	entUsage.cpuUsed AS 'CPU Used',
            CAST((aggregatedLimits.ramHard)/1024 AS DECIMAL(28,2)) AS 'Memory Reserved (GB)',
            entUsage.ramUsed AS 'Memory Used (GB)',
            CAST((aggregatedLimits.hdHard)/(1048576*1024) AS DECIMAL(28,2)) AS 'Local Hard Disk Reserved (GB)',
            entUsage.hdUsed AS 'Local hard Disk Used (GB)',
            CAST((aggregatedLimits.storageHard)/(1048576*1024) AS DECIMAL(28,2)) AS 'External Storage Reserved (GB)',
            entUsage.extStorageMBAllocated AS 'External Storage Used (GB)',
            aggregatedLimits.publicIPHard AS 'Public IPs Reserved', entUsage.publicIPsUsed AS 'Public IPs Used',
            aggregatedLimits.vlanHard AS 'VLANs Reserved', entUsage.totalVlansUsed AS 'VLANs Used',
            entUsage.idDatacenter 
     FROM
        (SELECT  dc.name,
            COALESCE(SUM(vdcTovmMapping.cpuUsed),0) AS cpuUsed,
            CAST(COALESCE(sum(vdcTovmMapping.ramUsed),0)/1024 AS DECIMAL(28,2)) AS ramUsed,
            CAST(COALESCE(sum(vdcTovmMapping.hdUsed),0)/(1048576*1024) AS DECIMAL(28,2)) AS hdUsed,
            COALESCE(CAST(sum(extStorageInfo.extStorageMBAllocated)/1024 AS DECIMAL(28,2)),0) AS extStorageMBAllocated,
            COALESCE(SUM(entVlanInfo.publicIPsUsed),0) AS publicIPsUsed,
            COALESCE(SUM(entVlanInfo.totalVlansUsed),0) AS totalVlansUsed,
            dc.idDatacenter 

        FROM
        kinton_reporting.RLS_DATACENTER_V1_0_VW AS dc

        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc
                ON (vdc.idDataCenter=dc.idDataCenter)

        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
                ON (e.idEnterprise=vdc.idEnterprise)

        LEFT JOIN kinton_reporting.RLS_SUM_VM_IN_USE_BY_VDC_V1_0_VW AS vdcTovmMapping
                ON (vdc.idVirtualDataCenter=vdcTovmMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.RLS_NETWORK_USED_BY_VDC_V1_0_VW AS entVlanInfo
                ON (vdc.idVirtualDataCenter=entVlanInfo.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.RLS_STORAGE_USED_BY_VDC_V1_0_VW AS extStorageInfo
            ON (vdc.idVirtualDataCenter=extStorageInfo.idVirtualDataCenter)

        GROUP BY dc.name
    ) entUsage

    LEFT JOIN
    (
        SELECT  idDataCenter,
                IF (cpuHard IS NULL, 0, SUM(cpuHard)) AS cpuHard,
                IF (ramHard IS NULL, 0, SUM(ramHard)) AS ramHard,
                IF (hdHard IS NULL, 0, SUM(hdHard)) AS hdHard,
                IF (storageHard IS NULL, 0, SUM(storageHard)) AS storageHard,
                IF (publicIPHard IS NULL, 0, SUM(publicIPHard)) AS publicIPHard,
                IF (vlanHard IS NULL, 0, SUM(vlanHard)) AS vlanHard
        FROM kinton_reporting.RLS_ENTERPRISE_LIMITS_BY_DATACENTER_V1_0_VW
        GROUP BY idDataCenter
    ) AS aggregatedLimits
    ON (entUsage.idDataCenter=aggregatedLimits.idDataCenter)

    ORDER BY entUsage.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_DatacenterPlanning_Ent_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_DatacenterPlanning_Ent_v1_0(rls_abiquo_user VARCHAR(128), p_idDatacenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Datacenter Resource Planning Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  entUsage.name AS 'DataCenter', entUsage.e_name  AS 'Enterprise Name',	NULL AS 'Virtual Data Center',
            COALESCE(eldc.cpuHard,0) AS 'CPU Reserved',
            entUsage.cpuUsed AS 'CPU Used',
            CAST((COALESCE(eldc.ramHard,0))/1024 AS DECIMAL(28,2)) AS 'Memory Reserved (GB)',
            entUsage.ramUsed AS 'Memory Used (GB)',
            CAST((COALESCE(eldc.hdHard,0))/(1048576*1024) AS DECIMAL(28,2)) AS 'Local Hard Disk Reserved (GB)',
            entUsage.hdUsed AS 'Local hard Disk Used (GB)',
            CAST((COALESCE(eldc.storageHard,0))/(1048576*1024) AS DECIMAL(28,2)) AS 'External Storage Reserved (GB)',
            entUsage.extStorageMBAllocated AS 'External Storage Used (GB)',
            COALESCE(eldc.publicIPHard,0) AS 'Public IPs Reserved',
            entUsage.publicIPsUsed AS 'Public IPs Used',
            COALESCE(eldc.vlanHard,0) AS 'VLANs Reserved', 
            entUsage.totalVlansUsed AS 'VLANs Used',
            entUsage.idDatacenter, entUsage.idEnterprise, NULL AS idVirtualDataCenter
    FROM
        (SELECT  dc.name, e.name AS e_name,
            COALESCE(SUM(vdcTovmMapping.cpuUsed),0) AS cpuUsed,
            CAST(COALESCE(sum(vdcTovmMapping.ramUsed),0)/1024 AS DECIMAL(28,2)) AS ramUsed,
            CAST(COALESCE(sum(vdcTovmMapping.hdUsed),0)/(1048576*1024) AS DECIMAL(28,2)) AS hdUsed,
            COALESCE(CAST(sum(extStorageInfo.extStorageMBAllocated)/1024 AS DECIMAL(28,2)),0) AS extStorageMBAllocated,
            COALESCE(SUM(entVlanInfo.publicIPsUsed),0) AS publicIPsUsed,
            COALESCE(SUM(entVlanInfo.totalVlansUsed),0) AS totalVlansUsed,
            dc.idDatacenter, e.idEnterprise

        FROM
        kinton_reporting.RLS_DATACENTER_V1_0_VW AS dc

        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc
                ON (vdc.idDataCenter=dc.idDataCenter)

        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
                ON (e.idEnterprise=vdc.idEnterprise)

        LEFT JOIN kinton_reporting.RLS_SUM_VM_IN_USE_BY_VDC_V1_0_VW AS vdcTovmMapping
                ON (vdc.idVirtualDataCenter=vdcTovmMapping.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.RLS_NETWORK_USED_BY_VDC_V1_0_VW AS entVlanInfo
                ON (vdc.idVirtualDataCenter=entVlanInfo.idVirtualDataCenter)

        LEFT JOIN kinton_reporting.RLS_STORAGE_USED_BY_VDC_V1_0_VW AS extStorageInfo
            ON (vdc.idVirtualDataCenter=extStorageInfo.idVirtualDataCenter)

        WHERE
             e.name IS NOT NULL AND
             dc.idDatacenter=p_idDatacenter

        GROUP BY dc.name, e.name
    ) entUsage

    LEFT JOIN kinton_reporting.RLS_ENTERPRISE_LIMITS_BY_DATACENTER_V1_0_VW eldc ON (entUsage.idDatacenter=eldc.idDatacenter AND entUsage.idEnterprise=eldc.idEnterprise)

    ORDER BY entUsage.name, entUsage.e_name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



DROP PROCEDURE IF EXISTS kinton_reports.RPT_DatacenterPlanning_VDC_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_DatacenterPlanning_VDC_v1_0(rls_abiquo_user VARCHAR(128), p_idDatacenter INT(10), p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Datacenter Resource Planning Report SP- VDC level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  dc.name AS 'DataCenter', e.name AS 'Enterprise Name',	vdc.name AS 'Virtual Data Center',
            COALESCE(vdc.cpuHard,0) AS 'CPU Reserved',	COALESCE(SUM(vdcTovmMapping.cpuUsed),0) AS 'CPU Used',
            CAST((vdc.ramHard)/1024 AS DECIMAL(28,2)) AS 'Memory Reserved (GB)',
            CAST(COALESCE(sum(vdcTovmMapping.ramUsed),0)/1024 AS DECIMAL(28,2)) AS 'Memory Used (GB)',
            CAST((vdc.hdHard)/(1048576*1024) AS DECIMAL(28,2)) AS 'Local Hard Disk Reserved (GB)',
            CAST(COALESCE(sum(vdcTovmMapping.hdUsed),0)/(1048576*1024) AS DECIMAL(28,2)) AS 'Local hard Disk Used (GB)',
            CAST((vdc.storageHard)/(1048576*1024) AS DECIMAL(28,2)) AS 'External Storage Reserved (GB)',
            COALESCE(CAST(sum(extStorageInfo.extStorageMBAllocated)/1024 AS DECIMAL(28,2)),0) AS 'External Storage Used (GB)',
            SUM(vdc.publicIPHard) AS 'Public IPs Reserved',	COALESCE(SUM(vdcVlanInfo.publicIPsUsed),0) AS 'Public IPs Used',
            SUM(vdc.vlanHard) AS 'VLANs Reserved',	COALESCE(SUM(vdcVlanInfo.internalNetworksUsed),0) AS 'VLANs Used',
            dc.idDatacenter, e.idEnterprise, vdc.idVirtualDataCenter # These are unused by the report but useful for drilldown joins
    FROM
    kinton_reporting.RLS_VDC_V1_0_VW AS vdc
    
    LEFT JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW AS dc
        ON (vdc.idDataCenter=dc.idDataCenter)

    LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
    ON (e.idEnterprise=vdc.idEnterprise)

    LEFT JOIN kinton_reporting.RLS_SUM_VM_IN_USE_BY_VDC_V1_0_VW AS vdcTovmMapping
        ON (vdc.idVirtualDataCenter=vdcTovmMapping.idVirtualDataCenter)

    LEFT JOIN kinton_reporting.RLS_NETWORK_USED_BY_VDC_V1_0_VW AS vdcVlanInfo
            ON (vdc.idVirtualDataCenter=vdcVlanInfo.idVirtualDataCenter)

    LEFT JOIN kinton_reporting.RLS_STORAGE_USED_BY_VDC_V1_0_VW AS extStorageInfo
        ON (vdc.idVirtualDataCenter=extStorageInfo.idVirtualDataCenter)

    WHERE
        e.name IS NOT NULL AND
        vdc.idEnterprise=p_idEnterprise AND
        dc.idDatacenter=p_idDatacenter

    GROUP BY dc.name, e.name, vdc.name
    ORDER BY dc.name, e.name, vdc.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
