SELECT "Creating procedures for the Resource Allocation report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_EnterpriseLimits_Ent_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_EnterpriseLimits_Ent_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Allocation Report - ENTERPRISE level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  e.name AS 'Enterprise Name', NULL AS 'Virtual Datacenter',
            e.cpuSoft AS 'CPU Soft', e.cpuHard AS 'CPU Hard',
            CAST(e.ramSoft/1024 AS DECIMAL(28,0)) AS 'Memory Soft (GB)',
            CAST(e.ramHard/1024 AS DECIMAL(28,0)) AS 'Memory Hard (GB)',
            CAST(e.hdSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'Local Storage Soft (GB)',
            CAST(e.hdHard/(1048576*1024) AS DECIMAL(28,0)) AS 'Local Storage Hard (GB)',
            CAST(e.storageSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'External Storage Soft (GB)',
            CAST(e.storageHard/(1048576*1024) AS DECIMAL(28,0)) AS 'External Storage Hard (GB)',
            e.vlanSoft AS 'VLANs Soft', e.vlanHard AS 'VLANs Hard',
            e.publicIPSoft AS 'Public IPs Soft', e.publicIPHard AS 'Public IPs Hard',
            e.idEnterprise,

            # These columns are the VDC totals for each Enterprise, and can be used to flag
            # where VDC limits exceed the Enterprise ones
            vdcLimits.cpuSoft AS 'VDC CPU Soft', vdcLimits.cpuHard AS 'VDC CPU Hard',
            CAST(vdcLimits.ramSoft/1024 AS DECIMAL(28,0)) AS 'VDC Memory Soft (GB)',
            CAST(vdcLimits.ramHard/1024 AS DECIMAL(28,0)) AS 'VDC Memory Hard (GB)',
            CAST(vdcLimits.hdSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'VDC Local Storage Soft (GB)',
            CAST(vdcLimits.hdHard/(1048576*1024) AS DECIMAL(28,0)) AS 'VDC Local Storage Hard (GB)',
            CAST(vdcLimits.storageSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'VDC External Storage Soft (GB)',
            CAST(vdcLimits.storageHard/(1048576*1024) AS DECIMAL(28,0)) AS 'VDC External Storage Hard (GB)',
            vdcLimits.vlanSoft AS 'VDC VLANs Soft', vdcLimits.vlanHard AS 'VDC VLANs Hard',
            vdcLimits.publicIPSoft AS 'VDC Public IPs Soft', vdcLimits.publicIPHard AS 'VDC Public IPs Hard'

    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
    JOIN
    (SELECT  e.idEnterprise,
            COALESCE(SUM(vdc.cpuSoft),0) AS cpuSoft, COALESCE(SUM(vdc.cpuHard),0) AS cpuHard,
            COALESCE(SUM(vdc.ramSoft),0) AS ramSoft, COALESCE(SUM(vdc.ramHard),0) AS ramHard,
            COALESCE(SUM(vdc.hdSoft),0) AS hdSoft, COALESCE(SUM(vdc.hdHard),0) AS hdHard,
            COALESCE(SUM(vdc.storageSoft),0) AS storageSoft, COALESCE(SUM(vdc.storageHard),0) AS storageHard,
            COALESCE(SUM(vdc.vlanSoft),0) AS vlanSoft, COALESCE(SUM(vdc.vlanHard),0) AS vlanHard,
            COALESCE(SUM(vdc.publicIPSoft),0) AS publicIPSoft, COALESCE(SUM(vdc.publicIPHard),0) AS publicIPHard
    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON (e.idEnterprise=vdc.idEnterprise)
    GROUP BY idEnterprise
    ) vdcLimits
    ON (e.idEnterprise=vdcLimits.idEnterprise)

    ORDER BY e.name ASC;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



DROP PROCEDURE IF EXISTS kinton_reports.RPT_EnterpriseLimits_VDC_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_EnterpriseLimits_VDC_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Allocation Report - VDC level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  e.name AS 'Enterprise Name',
            vdc.name AS 'Virtual Datacenter',
            vdc.cpuSoft AS 'CPU Soft', vdc.cpuHard AS 'CPU Hard',
            CAST(vdc.ramSoft/1024 AS DECIMAL(28,0)) AS 'Memory Soft (GB)',
            CAST(vdc.ramHard/1024 AS DECIMAL(28,0)) AS 'Memory Hard (GB)',
            CAST(vdc.hdSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'Local Hard Disk Soft (GB)',
            CAST(vdc.hdHard/(1048576*1024) AS DECIMAL(28,0)) AS 'Local Hard Disk Hard (GB)',
            CAST(vdc.storageSoft/(1048576*1024) AS DECIMAL(28,0)) AS 'External Storage Soft (GB)',
            CAST(vdc.storageHard/(1048576*1024) AS DECIMAL(28,0)) AS 'External Storage Hard (GB)',
            vdc.vlanSoft AS 'VLANs Soft', vdc.vlanHard AS 'VLANs Hard',
            vdc.publicIPSoft AS 'Public IPs Soft', vdc.publicIPHard AS 'Public IPs Hard'
    FROM
                kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
    LEFT JOIN   kinton_reporting.RLS_VDC_V1_0_VW AS vdc
                ON (e.idEnterprise=vdc.idEnterprise)
    # Note: Left Join can be turned into an inner join if empty enterprises
    # are NOT required in the result set

    WHERE
        vdc.name IS NOT NULL AND
        e.idEnterprise=p_idEnterprise
    ORDER BY e.name, vdc.name ASC;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
