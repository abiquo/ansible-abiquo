/*
*************************************************
**  UserAudit
*************************************************
*/

drop procedure   if exists  kinton_reports.RPT_User_Audit_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.RPT_User_Audit_v1_0(IN rls_usr CHAR(64),usr int, ent int)
BEGIN

    	CALL kinton_reporting.InitialiseRLS(rls_usr);

        IF usr is not null THEN

		SELECT u.*,e.name as enterprisename,r.name as rolename
		FROM kinton_reporting.RLS_USER_V1_0_VW u,
			kinton.enterprise e,
			kinton.role r
		WHERE u.idEnterprise=e.idEnterprise
			and u.idRole=r.idRole
			and u.idUser=usr;
        
         ELSEIF usr is null AND ent is null THEN

              SELECT u.*,e.name as enterprisename,r.name as rolename
        	from kinton_reporting.RLS_USER_V1_0_VW u,
        		kinton.enterprise e,
        		kinton.role r
        	where u.idEnterprise=e.idEnterprise
        		and u.idRole=r.idRole;
	ELSEIF ent is not null AND  usr is null THEN
		SELECT u.*,e.name as enterprisename,r.name as rolename
                from kinton_reporting.RLS_USER_V1_0_VW u,
                        kinton.enterprise e,
                        kinton.role r
                where u.idEnterprise=e.idEnterprise
                        and u.idRole=r.idRole
                        and u.idEnterprise=ent;
         END IF;

	CALL kinton_reporting.CleanupRLS();
END$$
delimiter ;

/*
*************************************************
**  UserActivityChart
*************************************************
*/

drop procedure   if exists  kinton_reports.RPT_User_Activity_Chart_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.RPT_User_Activity_Chart_v1_0(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP,
IN count_usr int(10))
BEGIN
    	 CALL kinton_reporting.InitialiseRLS(rls_usr);

	select  cast(date_format(eventtime,'%Y/%m/%d') as date ) as date , concat( upper(substring(severity,1,1)),lower(substring(severity,2)) ) as severity,
count(*) from 	kinton_reporting.RLS_EVENTS_V1_0_VW
	where idUser=count_usr
	and EventTime >= p_startDate AND EventTime <= p_endDate
	group by date_format(eventtime,'%d/%m/%Y'), severity
	order by date_format(eventtime,'%y%m%d'),
 case severity when 'INFO' then 1 when 'WARNING' then 2 when 'MAJOR' then 3 end  asc;
    CALL kinton_reporting.CleanupRLS();
END$$
delimiter ;

/*
*************************************************
**  UserActivityChart_2
*************************************************
*/

drop procedure if exists kinton_reports.RPT_User_Activity_Chart_v2_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_User_Activity_Chart_v2_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP,
IN count_usr int(10)
)
BEGIN
  DECLARE done INT DEFAULT FALSE;
   DECLARE currval INT;
   DECLARE datediff INT;

    DECLARE l_severity varchar(100);


    	DECLARE cur1 CURSOR FOR  select severity from tmp_distinct_severities;
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

   	SET currval = 0;
   	SET datediff = 0;

    	 CALL kinton_reporting.InitialiseRLS(rls_usr);

	DROP TEMPORARY TABLE IF EXISTS    tmp_distinct_severities;

	CREATE TEMPORARY TABLE IF NOT EXISTS tmp_distinct_severities
		SELECT distinct severity from kinton.event where timestamp >= p_startDate AND timestamp <= p_endDate;

	DROP TEMPORARY TABLE IF EXISTS   tmp_severity_empty_dates;
	CREATE TEMPORARY TABLE  		 tmp_severity_empty_dates (nodatadate timestamp, severity varchar(100),  nodatavalue int);


	   	BEGIN

			SET done=false;
			OPEN cur1;
			curstart_loop:  LOOP
				FETCH cur1 INTO l_severity;
				IF done
				THEN
					LEAVE  curstart_loop;
				ELSE
					INSERT INTO tmp_severity_empty_dates (nodatadate,severity, nodatavalue) VALUES (p_startDate, l_severity ,0);
				END iF;
			END LOOP curstart_loop;
			CLOSE cur1;

			SET datediff=DATEDIFF(p_endDate,p_startDate);
			dateloop: LOOP
				SET currval=currval+1;

				SET done=false;
				OPEN cur1;

			       	cur1_loop:  LOOP
					FETCH cur1 INTO l_severity;
					IF done
					THEN
						LEAVE  cur1_loop;
					ELSE
						INSERT INTO tmp_severity_empty_dates (nodatadate,severity, nodatavalue) VALUES (DATE_ADD(p_startDate, INTERVAL  currval DAY), l_severity ,0);
					END iF;
				END LOOP cur1_loop;
				CLOSE cur1;

				IF currval<datediff
				THEN
					ITERATE dateloop;
				END IF;
				LEAVE dateloop;
			END LOOP dateloop;
		END;

	DROP TEMPORARY TABLE IF EXISTS   tmp_severity_empty_dates_out;
	CREATE TEMPORARY TABLE  		 tmp_severity_empty_dates_out
		select
			empty.nodatadate as date,
				case empty.severity
				when 'INFO' then 'INFO'
				when 'NORMAL' then 'INFO'
				when 'WARNING' then 'WARNING'
				when 'MINOR' then 'WARNING'
				when 'MAJOR' then 'MAJOR'
				when 'CRITICAL' then 'MAJOR'
				else  'UNKNOWN'  end AS Severity,
			CASE when data.cnt is null then 0 else data.cnt end as cnt
		FROM
			kinton_reports.tmp_severity_empty_dates empty
		LEFT JOIN
		(
			select  cast(date_format(eventtime,'%Y/%m/%d') as date ) as date ,
			severity,
			count(*) as cnt
		from 	kinton_reporting.RLS_EVENTS_V1_0_VW
		where severity is not null AND idUser=count_usr
		and EventTime >= p_startDate AND EventTime <= p_endDate
		group by date_format(eventtime,'%d/%m/%Y'), severity
		) data
		ON
		(data.date= empty.nodatadate AND data.severity=empty.severity);

		select 	results.date as date,
			concat( upper(substring(results.Severity,1,1)),lower(substring(results.Severity,2)) ) as severity,
			sum(results.cnt) as cnt
		from tmp_severity_empty_dates_out results
		group by results.date,concat( upper(substring(results.Severity,1,1)),lower(substring(results.Severity,2)) )
		ORDER BY date_format(results.date,'%y%m%d'),case upper(results.severity) when 'INFO' then 1 when 'WARNING' then 2 when 'MAJOR' then 3 else 4 end;

END$$

delimiter ;


/*
*************************************************
**  UserActivityHistory
*************************************************
*/

DROP PROCEDURE IF EXISTS kinton_reports.RPT_User_Activity_History_v1_0;
DELIMITER $$
CREATE PROCEDURE kinton_reports.RPT_User_Activity_History_v1_0(	rls_abiquo_user VARCHAR(128),
                                                        	p_startDate TIMESTAMP,
								p_endDate TIMESTAMP,
                                                        	p_userToAudit int)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    	DECLARE l_iduser int;
  	DECLARE done INT DEFAULT FALSE;

    	DECLARE cur1 CURSOR FOR  select iduser from kinton.user where name= rls_abiquo_user;
 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	set l_iduser=1;
	SET done=false;
	OPEN cur1;
	FETCH cur1 INTO l_iduser;
	CLOSE cur1;

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT EventTime, Severity, Enterprise, User, /*Component,*/ Action, EventMessage
    FROM
        kinton_reporting.RLS_EVENTS_V1_0_VW
    WHERE
        EventTime >= p_startDate AND EventTime <= p_endDate AND
        idUser=p_userToAudit
	AND NOT (idUser= l_iduser and action = 'USER_CREATE')
   	ORDER BY EventTime ASC;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END$$
DELIMITER ;
