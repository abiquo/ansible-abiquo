SELECT "Creating procedures for the Cost Code Usage (all VM states) report..." AS " ";

#
# The actual detail report
#
DROP PROCEDURE IF EXISTS kinton_reports.RPT_CostCodeUsageAllStates_Detail_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_CostCodeUsageAllStates_Detail_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Cost Code Usage
    # Procedure Version : 2.6.2
    #
    # Procedure to return details of ALL Deployed VMs that have an associated Cost Code,
    # grouped by that cost code
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT cc.name AS 'Cost Code',
           vm.label AS 'VM Name', vm.name AS 'Abiquo Name', vm.state AS 'State', vm.ApplianceName AS 'Virtual Appliance',
           ent.name AS 'Enterprise', vdc.name AS 'Virtual Datacenter', dc.name AS 'Datacenter',
           vm.cpu AS 'CPU', vm.ram AS 'Memory (MB)',
           vi.name AS 'OS/Template',
           vm.state AS 'Virtual Machine State'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW dc ON vdc.idDataCenter=dc.idDataCenter

    INNER JOIN kinton.virtualimage vi ON vi.idImage=vm.idImage

    INNER JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code
    WHERE vm.state IN ('ON','OFF','PAUSED','UNKNOWN') # Currently limited to only the VMs which are ON, consider adding OFF, PAUSED, UNKNOWN? too?
    ORDER BY cc.name, ent.name, vdc.name,vm.ApplianceName, vm.label;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END;
|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_CostCodeUsageAllStates_Summary_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_CostCodeUsageAllStates_Summary_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Cost Code Usage - Overall summary level
    # Procedure Version : 2.6.2
    #
    # Procedure to return dsummary details of Cost Code Usage by VM and CPU
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT cc.name AS 'Cost Code',
           COUNT(*) AS 'VMs Using',
           SUM(vm.cpu) AS 'CPUs',
           SUM(vm.ram) AS 'Memory (MB)'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW dc ON vdc.idDataCenter=dc.idDataCenter

    INNER JOIN kinton.virtualimage vi ON vi.idImage=vm.idImage

    INNER JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code
    WHERE vm.state IN ('ON','OFF','PAUSED','UNKNOWN') # Currently limited to only the VMs which are ON, consider adding OFF, PAUSED, UNKNOWN? too?
    GROUP BY cc.name
    ORDER BY cc.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END;
|
DELIMITER ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_CostCodeUsageAllStates_Summary_Enterprise_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_CostCodeUsageAllStates_Summary_Enterprise_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Cost Code Usage - Enterprise summary level
    # Procedure Version : 2.6.2
    #
    # Procedure to return dsummary details of Cost Code Usage at Enterprise Level,
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT cc.name AS 'Cost Code',
           ent.name AS 'Enterprise',
           COUNT(*) AS 'VMs Using',
           SUM(vm.cpu) AS 'CPUs',
           SUM(vm.ram) AS 'Memory (MB)'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW dc ON vdc.idDataCenter=dc.idDataCenter

    INNER JOIN kinton.virtualimage vi ON vi.idImage=vm.idImage

    INNER JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code
    WHERE vm.state IN ('ON','OFF','PAUSED','UNKNOWN') # Currently limited to only the VMs which are ON, consider adding OFF, PAUSED, UNKNOWN? too?
    GROUP BY cc.name, ent.name
    ORDER BY cc.name, ent.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END;
|
DELIMITER ;



DROP PROCEDURE IF EXISTS kinton_reports.RPT_CostCodeUsageAllStates_Summary_VDC_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_CostCodeUsageAllStates_Summary_VDC_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Cost Code Usage - VDC summary level
    # Procedure Version : 2.6.2
    #
    # Procedure to return dsummary details of Cost Code Usage at VDC Level,
    # grouped by that cost code
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT cc.name AS 'Cost Code',
           ent.name AS 'Enterprise', vdc.name AS 'Virtual Datacenter',
           COUNT(*) AS 'VMs Using',
           SUM(vm.cpu) AS 'CPUs',
           SUM(vm.ram) AS 'Memory (MB)'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW dc ON vdc.idDataCenter=dc.idDataCenter

    INNER JOIN kinton.virtualimage vi ON vi.idImage=vm.idImage

    INNER JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code
    WHERE vm.state IN ('ON','OFF','PAUSED','UNKNOWN') # Currently limited to only the VMs which are ON, consider adding OFF, PAUSED, UNKNOWN? too?
    GROUP BY cc.name, ent.name, vdc.name
    ORDER BY cc.name, ent.name, vdc.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END;
|
DELIMITER ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_CostCodeUsageAllStates_Summary_VApp_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_CostCodeUsageAllStates_Summary_VApp_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Cost Code Usage - Virtual Appliance summary level
    # Procedure Version : 2.6.2
    #
    # Procedure to return dsummary details of Cost Code Usage at VApp Level,
    # grouped by that cost code
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT cc.name AS 'Cost Code',
           ent.name AS 'Enterprise', vdc.name AS 'Virtual Datacenter', vm.ApplianceName AS 'Virtual Appliance',
           COUNT(*) AS 'VMs Using',
           SUM(vm.cpu) AS 'CPUs',
           SUM(vm.ram) AS 'Memory (MB)'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_DATACENTER_V1_0_VW dc ON vdc.idDataCenter=dc.idDataCenter

    INNER JOIN kinton.virtualimage vi ON vi.idImage=vm.idImage

    INNER JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code
    WHERE vm.state IN ('ON','OFF','PAUSED','UNKNOWN') # Currently limited to only the VMs which are ON, consider adding OFF, PAUSED, UNKNOWN? too?
    GROUP BY cc.name, ent.name, vdc.name, vm.ApplianceName
    ORDER BY cc.name, ent.name, vdc.name, vm.ApplianceName;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END;
|
DELIMITER ;
