SELECT "Creating procedures for the Enterprise Usage report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_EnterpriseUsage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_EnterpriseUsage_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Enterprise Usage Report SP
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  e.name AS 'Enterprise Name',
            vdcTovmMapping.VMState AS 'VM State',
            COALESCE(SUM(vdcTovmMapping.TotalVMs),0) AS 'Number of VMs',
            COALESCE(SUM(vdcTovmMapping.CPUUsed),0) AS 'Total CPU',
            COALESCE(SUM(vdcTovmMapping.RAMUsed),0) AS 'Total Memory (MB)',
            COALESCE(CAST(SUM(vdcTovmMapping.HDUsed) AS DECIMAL(28,0))/(1048576*1024),0) AS 'Total Local Storage (GB)',

            # The columns below are Only useful at an overall VDC/Enterprise level, rather than at VM level.
            # This is because they can be shared across multiple VM's which may be in different states,
            # which means shared resources such as storage and networks may be incorrectly double-counted...
            COALESCE(CAST(entStorageInfo.extStorageMBAllocated AS DECIMAL(28,0))/1024,0) AS 'External Storage (GB)',
            COALESCE(entVlanInfo.publicIPsUsed,0) AS 'Total Public IPs',
            COALESCE(entVlanInfo.internalNetworksUsed,0) AS 'Total Internal VLANs',
            COALESCE(entVlanInfo.externalNetworksUsed,0) AS 'Total External Networks',
            COALESCE(repositoryUsageGB,0) AS 'Repository Used (GB)',
            e.idEnterprise
    FROM

    kinton_reporting.RLS_ENTERPRISE_V1_0_VW  e

    LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW  AS vdc
        ON (e.idEnterprise=vdc.idEnterprise)

    LEFT JOIN kinton_reporting.RLS_SUM_VM_RESOURCES_BY_STATE_BY_VDC_V1_0_VW AS vdcTovmMapping
        ON (vdc.idVirtualDataCenter=vdcTovmMapping.idVirtualDataCenter)

    LEFT JOIN kinton_reporting.RLS_NETWORK_USED_BY_ENTERPRISE_V1_0_VW entVlanInfo
        ON (e.idEnterprise=entVlanInfo.idEnterprise)

    LEFT JOIN kinton_reporting.RLS_STORAGE_USED_BY_ENTERPRISE_V1_0_VW AS entStorageInfo
        ON (entStorageInfo.idEnterprise=e.idEnterprise)

    LEFT JOIN kinton_reporting.RLS_REPOSITORY_USED_BY_ENTERPRISE_V1_0_VW AS entReposUsage
        ON (entReposUsage.idEnterprise=e.idEnterprise)

    WHERE
        VMState IS NOT NULL

    GROUP BY e.name, VMState

    ORDER BY e.name ASC, VMState ASC;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
