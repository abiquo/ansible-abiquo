SELECT "Creating procedures for the Resource Consumption & Cost report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # first of all we get the basics
    CALL kinton_reports.RPT_ConsumptionCost_Ent_basics(rls_abiquo_user,p_startDate,p_endDate);

    # Second, all the storage tiers stuff
    CALL kinton_reports.RPT_ConsumptionCost_Ent_storage(rls_abiquo_user,p_startDate,p_endDate);

    # Third, all the cost_codes stuff
    CALL kinton_reports.RPT_ConsumptionCost_Ent_cost_code(rls_abiquo_user,p_startDate,p_endDate);

    # Forth, all the cost_codes stuff
    CALL kinton_reports.RPT_ConsumptionCost_Ent_backup(rls_abiquo_user,p_startDate,p_endDate);

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
    
END|
DELIMITER ;

#This SP helps to call the other SP depending of the parameter argument. 
#argument could adquire the next values [basics, storage, cost. backup]
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_interface;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_interface(rls_abiquo_user VARCHAR(128), 
                 p_startDate TIMESTAMP, p_endDate TIMESTAMP, argument varchar(50))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    CASE argument
        when "basics" then 
            # first of all we get the basics
            CALL kinton_reports.RPT_ConsumptionCost_Ent_basics(rls_abiquo_user,p_startDate,p_endDate);
        when "storage" then 
            # Second, all the storage tiers stuff
            CALL kinton_reports.RPT_ConsumptionCost_Ent_storage(rls_abiquo_user,p_startDate,p_endDate);
        when "cost" then
            # Third, all the cost_codes stuff
            CALL kinton_reports.RPT_ConsumptionCost_Ent_cost_code(rls_abiquo_user,p_startDate,p_endDate);
        when "backup" then    
            # Forth, all the cost_codes stuff
            CALL kinton_reports.RPT_ConsumptionCost_Ent_backup(rls_abiquo_user,p_startDate,p_endDate);
    END CASE;
    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




#Basics
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_basics;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_basics(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################
    SELECT  acc.enterpriseName AS 'Enterprise',
            '-' AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
            SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
            SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu_on) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu_off) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', #Actually GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', #Actually GB now!
            (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', #Actually GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB_on)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB_off)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1),0) AS 'IP Address Consumed',
            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1),0) AS 'NAT IP Address Consumed',  
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'NAT IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'FIREWALL Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.firewall) / costs.priceToHourConversion,0) AS 'FIREWALL Cost',

            SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'LB Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.load_balancer) / costs.priceToHourConversion,0) AS 'LB Cost',

            (SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Repository Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.repositoryGB) / costs.priceToHourConversion,0) AS 'Repository Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise

    FROM
        

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (acc.idVirtualDataCenter=vdc.idVirtualDataCenter)
        
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e  ON (acc.idEnterprise=e.idEnterprise)
        LEFT JOIN 
            (SELECT idEnterprise, ip, type
             FROM kinton_accounting.accounting_event_ips
             GROUP by idEnterprise, ip, type) AS ips 
         ON ( acc.resourceName=ips.ip  AND ips.idEnterprise = acc.idEnterprise)
        

    WHERE
         (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL)

    GROUP BY acc.idEnterprise 
    ORDER BY acc.enterpriseName;
    
    
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_storage;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_storage(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            '-' AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            (SUM(CASE idAccountingResourceType WHEN 13 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'datastore Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 13 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'datastore Storage Cost',


            # Helper columns for joins...
            pt.name,
            acc.idStorageTier,
            acc.idEnterprise

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise

    GROUP BY acc.idEnterprise, acc.idStorageTier
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;

#cost_code
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_cost_code;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_cost_code(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            '-' AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'costcode Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'costcode Cost',


            # Helper columns for joins...
            cc.costCodeName,
            acc.costCode,
            acc.idEnterprise

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise

    GROUP BY acc.idEnterprise, acc.costCode
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;

#Backup
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_backup;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_backup(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            '-' AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Backup Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'Backup Cost',


            # Helper columns for joins...
            pt.name,
            acc.resourceName,
            acc.idEnterprise,
            acc.idVirtualDataCenter
            
            

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW pt ON (pt.code=acc.resourceName AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idAccountingResourceType = 14

    GROUP BY acc.idEnterprise, acc.resourceName
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # first of all we get the basics
    CALL kinton_reports.RPT_ConsumptionCost_VDC_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);

    # Second, all the storage tiers stuff
    CALL kinton_reports.RPT_ConsumptionCost_VDC_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);

    # Third, all the cost_code stuff
    CALL kinton_reports.RPT_ConsumptionCost_VDC_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);


    # Forth, all the backup stuff
    CALL kinton_reports.RPT_ConsumptionCost_VDC_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);


    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



#This SP helps to call the other SP depending of the parameter argument. 
#argument could adquire the next values ["basics", "storage", "cost", "backup"]
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_interface;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_interface(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, 
                 p_endDate TIMESTAMP, p_idEnterprise INT(10), argument varchar(50))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);
    CASE argument
        WHEN "basics" THEN
            # first of all we get the basics
            CALL kinton_reports.RPT_ConsumptionCost_VDC_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);
        WHEN "storage" THEN
            # Second, all the storage tiers stuff
            CALL kinton_reports.RPT_ConsumptionCost_VDC_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);
        WHEN "cost" THEN
            # Third, all the cost_code stuff
            CALL kinton_reports.RPT_ConsumptionCost_VDC_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);
        WHEN "backup" THEN
            # Forth, all the backup stuff
            CALL kinton_reports.RPT_ConsumptionCost_VDC_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise);
    END CASE;
    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_basics;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_basics(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VDC level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
            SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
            SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', #GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', #GB now!
            (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', #GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1),0) AS 'IP Address Consumed',
            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1),0) AS 'NAT IP Address Consumed',  
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'NAT IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'FIREWALL Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.firewall) / costs.priceToHourConversion,0) AS 'FIREWALL Cost',

            SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'LB Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.load_balancer) / costs.priceToHourConversion,0) AS 'LB Cost',

            (SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Repository Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.repositoryGB) / costs.priceToHourConversion,0) AS 'Repository Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter

    FROM
        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise and costs.id_datacenter=acc.idDataCenter)
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (acc.idVirtualDataCenter=vdc.idVirtualDataCenter)
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e  ON (acc.idEnterprise=e.idEnterprise)
        LEFT JOIN 
            (SELECT idEnterprise, ip, type
             FROM kinton_accounting.accounting_event_ips
             GROUP by idEnterprise, ip, type) AS ips 
         ON ( acc.resourceName=ips.ip  AND ips.idEnterprise = acc.idEnterprise)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idEnterprise=p_idEnterprise

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter
    ORDER BY acc.virtualDataCenter;

END|
DELIMITER ;


#Storage_tier
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_storage;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_storage(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            (SUM(CASE idAccountingResourceType WHEN 13 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'datastore Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 13 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'datastore Storage Cost',


            # Helper columns for joins...
            pt.name,
            acc.idStorageTier,
            acc.idEnterprise,
            acc.idVirtualDataCenter

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idEnterprise=p_idEnterprise

    GROUP BY acc.idEnterprise, acc.idStorageTier
    ORDER BY acc.enterpriseName;

END|
DELIMITER ;


#cost_code
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_cost_code;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_cost_code(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'costcode Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'costcode Cost',


            # Helper columns for joins...
            cc.costCodeName,
            acc.costCode,
            acc.idEnterprise,
            acc.idVirtualDataCenter
            

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)
        
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idEnterprise=p_idEnterprise

    GROUP BY acc.idEnterprise, acc.costCode
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;


#backup
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_backup;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_backup(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Backup Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'Backup Cost',


            # Helper columns for joins...
            pt.name,
            acc.resourceName,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW pt ON (pt.code=acc.resourceName AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idEnterprise=p_idEnterprise AND
        acc.idAccountingResourceType = 14

    GROUP BY acc.idEnterprise, acc.resourceName, idVirtualDataCenter
    ORDER BY acc.enterpriseName;

END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # first of all we get the basics
    CALL kinton_reports.RPT_ConsumptionCost_Vapp_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);

    # Second, all the storage tiers stuff
    CALL kinton_reports.RPT_ConsumptionCost_Vapp_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);

    # Third, all the cost code stuff
    CALL kinton_reports.RPT_ConsumptionCost_Vapp_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);

    # Forth, all the backup stuff
    CALL kinton_reports.RPT_ConsumptionCost_Vapp_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



#This SP helps to call the other SP depending of the parameter argument. 
#argument could adquire the next values ["basics", "storage", "cost", "backup"]
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp_interface;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp_interface(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP,
                 p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), argument varchar(50))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);
    CASE argument
        WHEN "basics" THEN
            # first of all we get the basics
            CALL kinton_reports.RPT_ConsumptionCost_Vapp_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);
        WHEN "storage" THEN
            # Second, all the storage tiers stuff
            CALL kinton_reports.RPT_ConsumptionCost_Vapp_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);
        WHEN "cost" THEN
            # Third, all the cost code stuff
            CALL kinton_reports.RPT_ConsumptionCost_Vapp_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);
        WHEN "backup" THEN
            # Forth, all the backup stuff
            CALL kinton_reports.RPT_ConsumptionCost_Vapp_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter);
    END CASE;
    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp_basics;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp_basics(rls_abiquo_user VARCHAR(128),
                                                                p_startDate TIMESTAMP, p_endDate TIMESTAMP, 
                                                                p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VApp level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
        SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
        SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', # GB now!
        (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', # GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',


            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1),0) AS 'IP Address Consumed',
            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1),0) AS 'NAT IP Address Consumed',  
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'NAT IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

                        SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'FIREWALL Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.firewall) / costs.priceToHourConversion,0) AS 'FIREWALL Cost',

            SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'LB Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.load_balancer) / costs.priceToHourConversion,0) AS 'LB Cost',

            (SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Repository Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.repositoryGB) / costs.priceToHourConversion,0) AS 'Repository Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise and costs.id_datacenter=acc.idDataCenter)
        LEFT JOIN 
            (SELECT idEnterprise, ip, type
             FROM kinton_accounting.accounting_event_ips
             GROUP by idEnterprise, ip, type) AS ips 
         ON ( acc.resourceName=ips.ip  AND ips.idEnterprise = acc.idEnterprise)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualDataCenter=p_idVirtualDataCenter

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp
    ORDER BY acc.virtualApp;

END|
DELIMITER ;

#Storage_tier
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp_storage;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp_storage(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'datastore Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'datastore Storage Cost',

            # Helper columns for joins...
            pt.name,
            acc.idStorageTier,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualDataCenter=p_idVirtualDataCenter

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.idStorageTier
    ORDER BY acc.virtualApp;

END|
DELIMITER ;


#cost_code
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp_cost_code;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp_cost_code(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'costcode Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'costcode Cost',


            # Helper columns for joins...
            cc.costCodeName,
            acc.costCode,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp
            

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)
        
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualDataCenter=p_idVirtualDataCenter

    GROUP BY acc.idEnterprise, acc.costCode, acc.idVirtualDataCenter,acc.idVirtualApp
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;

#Backup
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Vapp_backup;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Vapp_backup(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Backup Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'Backup Cost',

            # Helper columns for joins...
            pt.name,
            acc.resourceName,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW pt ON (pt.code=acc.resourceName AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualDataCenter=p_idVirtualDataCenter AND
        acc.idAccountingResourceType = 14
        

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.resourceName
    ORDER BY acc.virtualApp;

END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # first of all we get the basics
    CALL kinton_reports.RPT_ConsumptionCost_VM_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);

    # Second, all the storage tiers stuff
    CALL kinton_reports.RPT_ConsumptionCost_VM_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);

    # Third, all the cost code stuff
    CALL kinton_reports.RPT_ConsumptionCost_VM_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);

    # Forth, all the backup stuff
    CALL kinton_reports.RPT_ConsumptionCost_VM_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


#This SP helps to call the other SP depending of the parameter argument. 
#argument could adquire the next values ["basics", "storage", "cost", "backup"]
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_interface;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_interface(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP,
                 p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10), argument varchar(50))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);
    CASE argument
        WHEN "basics" THEN
            # first of all we get the basics
            CALL kinton_reports.RPT_ConsumptionCost_VM_basics(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);
        WHEN "storage" THEN
            # Second, all the storage tiers stuff
            CALL kinton_reports.RPT_ConsumptionCost_VM_storage(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);
        WHEN "cost" THEN 
            # Third, all the cost code stuff
            CALL kinton_reports.RPT_ConsumptionCost_VM_cost_code(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);
        WHEN "backup" THEN
            # Forth, all the backup stuff
            CALL kinton_reports.RPT_ConsumptionCost_VM_backup(rls_abiquo_user,p_startDate,p_endDate, p_idEnterprise, p_idVirtualDataCenter, p_idVirtualApp);
    END CASE;
    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




#basics
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_basics;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_basics(rls_abiquo_user VARCHAR(128),
                                                                p_startDate TIMESTAMP, p_endDate TIMESTAMP, 
                                                                p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VM level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            IF (vm.name IS NULL, acc.virtualMachine, vm.name) AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
            SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
            SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', # GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
           COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1),0) AS 'IP Address Consumed',
            COALESCE(SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1),0) AS 'NAT IP Address Consumed',  
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN 'PUBLIC_IP' THEN resourceunits ELSE 0  END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN CASE ips.type WHEN NOT 'PUBLIC_IP' THEN resourceunits ELSE 0 END END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'NAT IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'FIREWALL Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 19 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.firewall) / costs.priceToHourConversion,0) AS 'FIREWALL Cost',

            SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'LB Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 20 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.load_balancer) / costs.priceToHourConversion,0) AS 'LB Cost',

            (SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Repository Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 11 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.repositoryGB) / costs.priceToHourConversion,0) AS 'Repository Cost',

            # Images Consumed and Cost, if required?
            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                     * IF(cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion,0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine

    FROM
        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc
        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # Ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)
        LEFT JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc ON (acc.idVirtualDataCenter=vdc.idVirtualDataCenter)
        
        LEFT JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e  ON (acc.idEnterprise=e.idEnterprise)

        LEFT JOIN kinton.virtualmachine vm ON (vm.idVM=acc.idVirtualMachine)
        LEFT JOIN 
            (SELECT idEnterprise, ip, type
             FROM kinton_accounting.accounting_event_ips
             GROUP by idEnterprise, ip, type) AS ips 
         ON ( acc.resourceName=ips.ip  AND ips.idEnterprise = acc.idEnterprise)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualApp=p_idVirtualApp

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.idVirtualMachine
    ORDER BY IF (vm.name IS NULL, acc.virtualMachine, vm.name);
END|
DELIMITER ;


#Storage_tier
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_storage;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_storage(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            acc.virtualMachine AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'datastore Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'datastore Storage Cost',

            # Helper columns for joins...
            pt.name,
            acc.idStorageTier,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_DATASTORES_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualApp=p_idVirtualApp

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.idStorageTier
    ORDER BY acc.virtualApp;

END|
DELIMITER ;

#cost_code
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_cost_code;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_cost_code(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################


    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            acc.virtualMachine AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'costcode Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'costcode Cost',


            # Helper columns for joins...
            cc.costCodeName,
            acc.costCode,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine
            

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)
        
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualApp=p_idVirtualApp

    GROUP BY acc.idEnterprise, acc.costCode
    ORDER BY acc.enterpriseName;


END|
DELIMITER ;

#Backup
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_backup;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_backup(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            acc.virtualMachine AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Backup Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 14 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * pt.price) / costs.priceToHourConversion,0) AS 'Backup Cost',

            # Helper columns for joins...
            pt.name,
            acc.resourceName,
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_BACKUP_V1_0_VW pt ON (pt.code=acc.resourceName AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)
        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualApp=p_idVirtualApp AND
        acc.idAccountingResourceType = 14

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.resourceName
    ORDER BY acc.virtualApp;

END|
DELIMITER ;

