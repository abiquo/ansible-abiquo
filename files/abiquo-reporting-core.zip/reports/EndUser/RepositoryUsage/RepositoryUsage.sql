SELECT "Creating procedures for the Repository Usage report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_RepositoryUsage_Ent_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_RepositoryUsage_Ent_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Repository Usage Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

     SELECT  e.name AS Enterprise,
            SUM( IF(vi.idMaster IS NULL, 1, 0) ) AS OwnedImages,
            SUM( IF(vi.idMaster IS NULL, 0, 1) ) AS OwnedInstances,
            COALESCE( SUM(imagesUsedByEnterprise.vmsUsingImage), 0)  AS TotalVMsUsingImages,
            COALESCE( SUM(imagesUsedByEnterprise.vmsInOtherEnterpiseUsingImage), 0)  AS VMsInOtherEnterprises,
            SUM(IF(d.diskFileSize IS NULL,0,d.diskFileSize))/(1048576*1024) AS TOTALRepositoryDiskUsageGB,
            SUM( IF(vi.idMaster IS NOT NULL, d.diskFileSize,0) )/(1048576*1024)  AS TOTALInstanceDiskUsageGB,
            SUM( IF(imagesUsedByEnterprise.vmsUsingImage IS NULL, IF(d.diskFileSize IS NULL, 0, d.diskFileSize),
                    IF (imagesUsedByEnterprise.vmsUsingImage=0, IF(d.diskFileSize IS NULL, 0, d.diskFileSize),0)
                    )
                )/(1048576*1024)  AS TOTALUndeployedDiskUsageGB,
            SUM( IF(vi.idMaster IS NULL, IF(d.diskFileSize IS NULL, 0,d.diskFileSize),0) )/(1048576*1024)  AS TOTALImageDiskUsageGB,
            SUM( IF(vi.shared <> 0, IF(d.diskFileSize IS NULL, 0, d.diskFileSize),0) )/(1048576*1024)  AS TOTALSharedImageDiskUsageGB,
            SUM( IF(imagesUsedByEnterprise.vmsUsingImage IS NULL AND vi.idMaster IS NULL, IF(d.diskFileSize IS NULL, 0,d.diskFileSize),
                    IF (imagesUsedByEnterprise.vmsUsingImage=0 AND vi.idMaster IS NULL, d.diskFileSize,0)
                    )
                )/(1048576*1024)  AS TotalUndeployedIMAGEDiskUsageGB,
            SUM( IF(imagesUsedByEnterprise.vmsUsingImage IS NULL AND vi.idMaster IS NOT NULL, d.diskFileSize,
                    IF (imagesUsedByEnterprise.vmsUsingImage=0 AND vi.idMaster IS NOT NULL, d.diskFileSize,0)
                    )
                )/(1048576*1024)  AS TotalUndeployedINSTANCEDiskUsageGB,
            e.idEnterprise
    FROM
    kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW vi ON (e.idEnterprise=vi.idEnterprise)
    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_USE_BY_ENTERPRISE_V1_0_VW AS imagesUsedByEnterprise
        ON (imagesUsedByEnterprise.idEnterprise=e.idEnterprise AND imagesUsedByEnterprise.idImage=vi.idImage)
    LEFT JOIN kinton.disk d ON (vi.idImage = d.template_id AND d.state='DONE' AND d.stateful=0 )

    GROUP BY e.idEnterprise
    ORDER BY TOTALRepositoryDiskUsageGB DESC, Enterprise;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_RepositoryUsage_EntImg_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_RepositoryUsage_EntImg_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Repository Usage Report SP- Enterprise Images level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  IF(e.name IS NULL, "N/A", e.name) AS OwningEnterprise,
            IF(vi.name IS NULL, "N/A", vi.name) AS ImageName,
        IF (cc.name IS NULL, "N/A", cc.name) AS CostCode,
            COALESCE( SUM(imagesUsedByEnterprise.vmsUsingImage), 0)  AS TotalVMsUsingImage,
            COALESCE( SUM(imagesUsedByEnterprise.vmsInOtherEnterpiseUsingImage), 0)  AS VMsInOtherEnterprises,
            SUM(IF( d.diskFileSize IS NULL, 0, d.diskFileSize))/(1048576*1024)  AS RepositoryDiskUsageGB,
            IF(vi.idImage IS NULL, 3, IF(vi.idMaster IS NULL, 1, 2)) AS ImageType, # 1=Image, 2=Instance
            IF(vi.idImage IS NULL, '-', IF(vi.idMaster IS NULL, 'Image', 'Instance')) AS ImageTypeName, # 1=Image, 2=Instance
            IF(vi.shared <> 0, 1, 0) AS IsShared,
            e.idEnterprise,
            IF (vi.idImage IS NULL, "N/A", vi.idImage) AS idImage
    FROM
    kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e

    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW vi ON (e.idEnterprise=vi.idEnterprise)

    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_USE_BY_ENTERPRISE_V1_0_VW AS imagesUsedByEnterprise
        ON (imagesUsedByEnterprise.idImage=vi.idImage)

    LEFT JOIN kinton.costCode cc ON (cc.idCostCode=vi.cost_code)

    LEFT JOIN kinton.disk d ON (vi.idImage = d.template_id AND d.state='DONE' AND d.stateful=0 )

    WHERE
        (d.stateful IS NULL OR d.stateful=0) # exclude persistent images, as these are on ext storage not the NFS Repository
        AND e.idEnterprise=p_idEnterprise
    GROUP BY e.idEnterprise, vi.idImage
    ORDER BY ImageType ASC, TotalVMsUsingImage DESC, ImageName;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_RepositoryUsage_ImgUsage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_RepositoryUsage_ImgUsage_v1_0(rls_abiquo_user VARCHAR(128), p_idImage INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Repository Usage Report SP- Enterprise Images level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  vi.idImage,
            vi.name AS ImageName,
            e.name AS EnterpriseName,
            vdc.name AS VDCName,
            vappTovmMapping.VAppName,
            vappTovmMapping.VMName,
            vappTovmMapping.VMState
    FROM

    kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW vi

    JOIN
    (
        SELECT va.idEnterprise, va.idVirtualDataCenter, va.idVirtualApp,
            vm.idImage, va.name AS VAppName, vm.name AS VMName,
            vm.state AS VMState
        FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm,/*kinton.virtualmachine vm, kinton.nodevirtualimage nvi, kinton.node n,*/
            kinton.virtualapp va
        WHERE
            vm.idVirtualApp=va.idVirtualApp
    ) AS vappTovmMapping
        ON (vi.idImage=vappTovmMapping.idImage)

    JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
        ON (e.idEnterprise=vappTovmMapping.idEnterprise)

    JOIN kinton_reporting.RLS_VDC_V1_0_VW AS vdc
        ON (e.idEnterprise=vdc.idEnterprise AND vdc.idVirtualDataCenter=vappTovmMapping.idVirtualDataCenter)

    LEFT JOIN kinton.disk d ON (vi.idImage = d.template_id AND d.state='DONE' AND d.stateful=0 )

    WHERE
        d.stateful IS NULL OR d.stateful=0 # exclude persistent images, as these are on tiered storage not the NFS Repository
        AND vi.idImage=p_idImage
    ORDER BY vi.idImage, e.name, vdc.name, vappTovmMapping.VAppName, vappTovmMapping.VMName;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;

drop procedure if exists  kinton_reports.RPT_RepositoryUsage_Summary_Chart_v1_0;
delimiter $$

CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_RepositoryUsage_Summary_Chart_v1_0`(rls_abiquo_user VARCHAR(128))
BEGIN

    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

select ifnull(zz.type,'Overall Total') as Type,ifnull(zz.used,'Overall Usage') as Used ,zz.tot as Total from
(
select type,used,SUM(DiskUsageGB) as tot from (
    SELECT
			IF(imagesUsedByEnterprise.vmsUsingImage IS NULL OR imagesUsedByEnterprise.vmsUsingImage=0,'Unused Template Usage','VMs using Template Usage') as used,
			IF (vi.idMaster IS NULL ,'Image Total','Instance Total') AS type,
			d.diskFileSize/(1048576*1024) AS DiskUsageGB
    FROM
    kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e
    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW vi ON (e.idEnterprise=vi.idEnterprise)
    LEFT JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_USE_BY_ENTERPRISE_V1_0_VW AS imagesUsedByEnterprise
        ON (imagesUsedByEnterprise.idEnterprise=e.idEnterprise AND imagesUsedByEnterprise.idImage=vi.idImage)

    LEFT JOIN kinton.disk d ON (vi.idImage = d.template_id AND d.state='DONE' AND d.stateful=0 )

    WHERE
        d.stateful=0 ) xx
GROUP BY type,used with rollup
) zz order by upper(zz.Used) asc ;


    CALL kinton_reporting.CleanupRLS();
END$$

delimiter ;
