SELECT "Creating reports schema if not already present..." AS " ";
CREATE SCHEMA IF NOT EXISTS kinton_reports;

# This can be used to grant access to the DBMS reports user being used by Jaspersoft to access
# the reports SPs
#GRANT EXECUTE ON kinton_reports.* TO 'jasper_user'@'%';

SELECT "Creating 'template' procedure for custom reports..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_Template_Level_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Template_Level_v1_0(
							rls_abiquo_user VARCHAR(128) # Optional - add filter parameters here...
							)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Template Report Procedure 
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # TODO - Put your report query in here...

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


SELECT "Creating Jaspersoft List helper procedures..." AS " ";

DROP PROCEDURE IF EXISTS kinton_reports.LST_Enterprises_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.LST_Enterprises_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Jaspersoft Helper SP to retrieve list of Enterprises for drop list selection
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT e.idEnterprise as idEnterprise, e.name as enterpriseName
    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
    LEFT JOIN 
	(SELECT * from kinton_reporting.RLS_USER_V1_0_VW WHERE user=rls_abiquo_user) u
    ON (u.idEnterprise=e.idEnterprise)
    ORDER BY ISNULL(u.idEnterprise), e.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;

DROP PROCEDURE IF EXISTS kinton_reports.LST_VDCs_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.LST_VDCs_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise VARCHAR(64))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Jaspersoft Helper SP to retrieve list of VDCs for drop list selection
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT vdc.idVirtualDataCenter as idVirtualDatacenter, e.name as enterpriseName, vdc.name as vdcName
    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e,
         kinton_reporting.RLS_VDC_V1_0_VW vdc
    WHERE
         vdc.idEnterprise=e.idEnterprise AND
         # THE String '~NOTHING~' is sometimes passed in by JasperReports 4.2.1 INSTEAD of NULL!
         (p_idEnterprise IS NULL OR p_idEnterprise=0 OR p_idEnterprise='~NOTHING~' OR p_idEnterprise=e.idEnterprise)
    ORDER BY e.name, vdc.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.LST_VMs_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.LST_VMs_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise VARCHAR(64), p_idVirtualDatacenter VARCHAR(64))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Jaspersoft Helper SP to retrieve list of VMs for drop list selection
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT vm.idVM, vm.name
    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e,
        kinton_reporting.RLS_VDC_V1_0_VW vdc,
        kinton.virtualmachine vm, kinton.virtualapp vapp
    WHERE
        vdc.idEnterprise=e.idEnterprise AND
        vm.virtual_appliance=vapp.idVirtualApp AND
        vapp.idVirtualDatacenter=vdc.idVirtualdatacenter AND
        
        # THE String '~NOTHING~' is sometimes passed in by JasperReports 4.2.1 INSTEAD of NULL!
        (p_idEnterprise IS NULL OR p_idEnterprise=0 OR p_idEnterprise='~NOTHING~' OR p_idEnterprise=e.idEnterprise) AND
        (p_idVirtualDatacenter IS NULL OR p_idVirtualDatacenter=0 OR p_idVirtualDatacenter='~NOTHING~' OR p_idVirtualDatacenter=vdc.idVirtualdatacenter)
    ORDER BY vm.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.LST_Owners_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.LST_Owners_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise VARCHAR(64))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Jaspersoft Helper SP to retrieve list of Owners for drop list selection
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT u.idUser, e.name as enterpriseName, u.user, u.name
    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW e,
         kinton.user u 
    WHERE
        u.idEnterprise = e.idEnterprise AND
         # THE String '~NOTHING~' is sometimes passed in by JasperReports 4.2.1 INSTEAD of NULL!
         (p_idEnterprise IS NULL OR p_idEnterprise=0 OR p_idEnterprise='~NOTHING~' OR p_idEnterprise=e.idEnterprise)
    ORDER BY e.name, u.user, u.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.LST_CostCodes_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.LST_CostCodes_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Jaspersoft Helper SP to retrieve list of Cost Codes for drop list selection
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT idCostCode, name
    FROM
    (
        (SELECT cc.*
        FROM    kinton.costCode cc,
                (SELECT count(*) as hasPrivs
                FROM kinton.user u, kinton.role r, kinton.roles_privileges rp, kinton.privilege p
                WHERE
                    u.user=rls_abiquo_user AND
                    u.idRole=r.idRole AND 
                    rp.idRole=r.idRole AND
                    rp.idPrivilege=p.idPrivilege AND
                    p.name='PHYS_DC_RETRIEVE_DETAILS'
                ) privsCheck
        WHERE privsCheck.hasPrivs > 0)
    ) AS costCode;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_Common_Drop_Temp_Table_v1_0;
DELIMITER $$
CREATE PROCEDURE kinton_reports.RPT_Common_Drop_Temp_Table_v1_0(IN temp_tab_name char(64))
begin
    SET @s = CONCAT('DROP TEMPORARY TABLE IF EXISTS ', temp_tab_name);
    PREPARE stmt FROM @s;
    EXECUTE stmt;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_Common_Temp_Table_Exists_v1_0;
DELIMITER $$
create procedure  kinton_reports.RPT_Common_Temp_Table_Exists_v1_0(tname varchar(255), OUT p_exists int)
begin
	declare EXIT handler for SQLEXCEPTION SET p_exists=0;
    SET p_exists=1;
    SET @l_stmt = CONCAT('select count(*) from ',tname);
    PREPARE stmt FROM @l_stmt;
END$$
DELIMITER ;


DROP PROCEDURE IF EXISTS kinton_reports.LST_Dynamic;
DELIMITER $$
CREATE PROCEDURE kinton_reports.`LST_Dynamic`(IN usr CHAR(64))
BEGIN
    SET @s = CONCAT('SELECT ','''',usr,''' as usr');
    PREPARE stmt FROM @s;
    EXECUTE stmt;
END$$
DELIMITER ;
