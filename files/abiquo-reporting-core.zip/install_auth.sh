#!/bin/bash

#
# Configure the base parameters (these can be customised)
#
JS_BASE_DIR=/opt/jasperreports-server-cp-5.5.0/apache-tomcat/webapps/jasperserver

# These can be hard coded if necessary, and the security risks of doing so are understood...
SQL_USER=
SQL_PWD=
SQL_HOST=


function displayUsage
{
  echo "Installer for Abiquo Reports Authentication components."
  echo "Installs Abiquo Reports authentication components into JasperServer"
  echo "Options:"
  echo "-su=<user> --sqluser=<user>   The database user (requires read access to the kinton schema)"
  echo "-sp=<pwd> --sqlpassword=<pwd> The database user password"
  echo "-sh=<host> --sqlhost=<host>   The host database machine"
  echo "-h --help                     Displays this usage"
  echo
  echo "Example Usage:"
  echo 
  echo "./install_auth.sh -sh=192.168.56.34 -su=authuser -sp=authuserpassword"
  echo 

  exit
}

#echo Number of arguments is $#
if [ "$#" = "0" ]; then
  displayUsage
fi

function check_dependency() {
    if [[ ! -x $(which $1) ]]; then
        echo "'$1' not found."
        exit 1
    fi
}


#
# Parse the input arguments
#
for i in "$@"
do
case $i in
    -su=*|--sqluser=*)
    SQL_USER=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
    ;;

    -sp=*|--sqlpwd=*)
    SQL_PWD=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
    ;;

    -sh=*|--sqlhost=*)
    SQL_HOST=`echo $i | sed 's/[-a-zA-Z0-9]*=//'`
    ;;

    -h|--help|*)
    displayUsage
    ;;
esac
done


#
# Now check/validate the arguments...
#
if [ "${SQL_HOST}" = "" ] || [ "${SQL_USER}" = "" ]; then
  echo ****** MUST define the Database User Credentials!
  displayUsage
fi


function displayVariables
{
  echo SQL USER = ${SQL_USER}
  echo SQL PASSWORD = ${SQL_PWD}
  echo SQL HOST = ${SQL_HOST}
}
#displayVariables


#
# Copy the template authentication XML and change it to include the correct data
#
# Remove old backup copy, and make an existing file the backup
rm -f ./auth/applicationContext-externalAuth-abiquo-db.xml.pop.bak

if [ -e ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ]; then
    mv ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ./auth/applicationContext-externalAuth-abiquo-db.xml.pop.bak
fi

# Copy the template and populate it correctly
cp ./auth/applicationContext-externalAuth-abiquo-db.xml ./auth/applicationContext-externalAuth-abiquo-db.xml.pop

sed -i "s/<DBMS_IP>/${SQL_HOST}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop
sed -i "s/<DBMS_USER>/${SQL_USER}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop
sed -i "s/<DBMS_PASSWORD>/${SQL_PWD}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop


# Now delete any ‘old’ files from JasperServer
rm -f ${JS_BASE_DIR}/WEB-INF/lib/abiquo-jasperserver-auth.jar
rm -f ${JS_BASE_DIR}/WEB-INF/applicationContext-externalAuth-abiquo-db.xml

# Put the new files in place
cp ./auth/abiquo-jasperserver-auth.jar ${JS_BASE_DIR}/WEB-INF/lib/abiquo-jasperserver-auth.jar
cp ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ${JS_BASE_DIR}/WEB-INF/applicationContext-externalAuth-abiquo-db.xml

echo Installation of the Abiquo JasperServer authentication components is complete.
echo If currently running, please restart JasperServer for the changes to take effect
