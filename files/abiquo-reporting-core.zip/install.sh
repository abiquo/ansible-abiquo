#!/bin/bash
set -e
#set -x

JASPERPATH=/opt/jasperreports-server-cp-6.2.0

function usage {
cat << EOT
Install Abiquo Reports 

Database connection options:

-h [DATABASEHOST] - defaults localhost
-u [DATABASEUSER] - defaults root 
-p [DATABASEPASSWORD] - default nil
-P [DATABASEPORT] - default 3306

Installation options
-r [report] - find and installs this particular report
EOT
}

while getopts "h:u:p:P:r:" OPTION
do
  case $OPTION in
  (h) PARAMHOST=$OPTARG ;;
  (u) PARAMUSER=$OPTARG ;;
  (p) PARAMPASS=$OPTARG ;;
  (P) PARAMPORT=$OPTARG ;;
  (r) PARAMREPORT=$OPTARG ;;
  (*) usage;  exit 1 ;;
  esac
done

DBHOST=${PARAMHOST:-localhost}
DBUSER=${PARAMUSER:-root}
DBPASS=${PARAMPASS:-}
DBPORT=${PARAMPORT:-3306}

MYSQLCMD="mysql -u$DBUSER -h$DBHOST -P$DBPORT ${DBPASS:+-p$DBPASS} "

$MYSQLCMD -e '' || {
  echo "Cannot connect to database."
  usage
  exit 1
}

if [ ! -d $JASPERPATH ]; then
  cat << EOT
Cannot find jasperserver installation, please make sure you are using
Jasper Server Community 6.2.0 and it is located under $JASPERPATH
EOT
fi

echo "Importing schema"
$MYSQLCMD < reports/Schema/kinton_reporting.sql || {
  echo "Could not import schema kinton_reporting"; exit 1
}

$MYSQLCMD < reports/Schema/kinton_reports.sql || {
  echo "Could not import schema kinton_reports"; exit 1
}
  
$MYSQLCMD kinton < $(find ./reports/ -iname '*sql'|grep Common) || {
  echo "Could not import Common procs into kinton" ; exit 1
}

for report in $(find ./reports/ -iname '*sql'|grep -v Common|grep -v Schema); 
do
  $MYSQLCMD < $report 
done

: Update database connection values on DataSource.xml
find $PWD -name Abiquo_Database.xml | xargs -I FILE sed -i \
 -e "s;<connectionUrl>.*</connectionUrl>;<connectionUrl>jdbc:mysql://$DBHOST:$DBPORT/kinton_reports</connectionUrl>;" \
 -e "s;<connectionPassword>.*</connectionPassword>;<connectionPassword>$DBPASS</connectionPassword>;" \
 -e "s;<connectionUser>.*</connectionUser>;<connectionUser>$DBUSER</connectionUser>;" \
 FILE

SCRIPTPATH=$(pwd -P)
pushd $JASPERPATH/buildomatic

for report in $(find $SCRIPTPATH -iname 'index.xml' -printf '%h\n'); 
do
  echo "Importing $report"
  ./js-import.sh --input-dir $report
done

popd

echo "Installing authentication"

#
# Copy the template authentication XML and change it to include the correct data
#
# Remove old backup copy, and make an existing file the backup
rm -f ./auth/applicationContext-externalAuth-abiquo-db.xml.pop.bak

if [ -e ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ]; then
    mv ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ./auth/applicationContext-externalAuth-abiquo-db.xml.pop.bak
fi

# Copy the template and populate it correctly
cp ./auth/applicationContext-externalAuth-abiquo-db.xml ./auth/applicationContext-externalAuth-abiquo-db.xml.pop

sed -i "s/<DBMS_HOST>/${DBHOST}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop
sed -i "s/<DBMS_USER>/${DBUSER}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop
sed -i "s/<DBMS_PASS>/${DBPASS}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop
sed -i "s/<DBMS_PORT>/${DBPORT}/g" ./auth/applicationContext-externalAuth-abiquo-db.xml.pop

# Now delete any ‘old’ files from JasperServer
rm -f ${JASPERPATH}/apache-tomcat/webapps/jasperserver/WEB-INF/lib/abiquo-jasperserver-auth.jar
rm -f ${JASPERPATH}/apache-tomcat/webapps/jasperserver/WEB-INF/applicationContext-externalAuth-abiquo-db.xml

# Put the new files in place
cp ./auth/abiquo-jasperserver-auth.jar ${JASPERPATH}/apache-tomcat/webapps/jasperserver/WEB-INF/lib/abiquo-jasperserver-auth.jar
cp ./auth/applicationContext-externalAuth-abiquo-db.xml.pop ${JASPERPATH}/apache-tomcat/webapps/jasperserver/WEB-INF/applicationContext-externalAuth-abiquo-db.xml

echo "Install init script"

cp $SCRIPTPATH/jasperserver.init /etc/init.d/jasperserver
chmod +x /etc/init.d/jasperserver
chkconfig --add jasperserver


echo "Restarting jasperserver"
service jasperserver restart
