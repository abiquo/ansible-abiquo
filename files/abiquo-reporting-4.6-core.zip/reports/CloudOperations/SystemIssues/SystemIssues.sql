SELECT "Creating procedures for the System Issues report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_Remote_Services_Status_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_Remote_Services_Status_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

	select z.*,IF(minservicetypes-cntservicetypes >= 0, minservicetypes-cntservicetypes, 0) as nummissingservices from (
	select x.minservicetypes,x.ispublic,
	x.name,
	count(*) cnt,
	count(distinct rs.remoteservicetype) cntservicetypes,
	sum(case status when 1 then 1 else 0 end) as sum_ok,
	sum(case status when 1 then 0 else 1 end) as sum_notok
	FROM
		(select 
		case when pc.idDataCenter is null then 7 else 3 end minservicetypes,
		case when pc.idDataCenter is null then 0 else 1 end as ispublic,
		d.*
		FROM 
		kinton_reporting.RLS_DATACENTER_V1_0_VW d
		LEFT JOIN
		kinton_reporting.RLS_PUBLIC_CLOUD_REGION_V1_0_VW pc
		ON (d.idDataCenter=pc.idDataCenter)) x
     	INNER JOIN 
		kinton_reporting.RLS_REMOTE_SERVICE_V1_0_VW rs
	ON
		(rs.abstract_datacenter_id = x.idDataCenter)
	GROUP BY x.ispublic,x.name ) z
	ORDER BY ispublic,name;

	CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_Server_Status_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_Server_Status_v1_0(rls_abiquo_user VARCHAR(128),p_detail int)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    if p_detail=0
    then
    	select dc.name as dc_name,r.name as rack_name,pm.StateDescription, count(*) FROM 
		kinton_reporting.RLS_DATACENTER_V1_0_VW dc,
		kinton_reporting.RLS_PHYSICAL_MACHINE_V1_0_VW pm,
		kinton.rack r		
	WHERE dc.idDataCenter=pm.idDataCenter
	AND   pm.idRack=r.idRack
	AND   pm.status_category = 0
	GROUP BY dc.name,r.name,pm.StateDescription
	ORDER BY dc.name,r.name;
    else
	select dc.name as dc_name,r.name as rack_name,pm.* FROM 
		kinton_reporting.RLS_DATACENTER_V1_0_VW dc,
		kinton_reporting.RLS_PHYSICAL_MACHINE_V1_0_VW pm,
		kinton.rack r		
	WHERE dc.idDataCenter=pm.idDataCenter
	AND   pm.idRack=r.idRack
	AND   pm.status_category = 0
	ORDER BY dc.name,r.name;
    end if;
    
    CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_Storage_Status_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_Storage_Status_v1_0(rls_abiquo_user VARCHAR(128),p_pct_free_threshold int)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

select * from 
(
	select dc.name,dc.idDataCenter,device_name,state_description as volume_status,
	count(*) num_volumes,
	round(sum(totalSizeInMb)/1024/1024,2) total_space,
	round(sum(usedSizeInMb)/1024/1024,2) used_space,
	round(sum(availableSizeInMb)/1024/1024,2) available_space ,
	round((sum(availableSizeInMb)/sum(totalSizeInMb))*100,2) as pct_free
	from 
	kinton_reporting.RLS_STORAGE_V1_0_VW st,
	kinton_reporting.RLS_DATACENTER_V1_0_VW dc
	WHERE st.idDataCenter=dc.idDataCenter
	group by dc.idDataCenter,device_name,state_description
) xx
WHERE ((pct_free <= p_pct_free_threshold) OR (volume_status != 'ATTACHED'))
order by pct_free;
    
    CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_VM_Status_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_VM_Status_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

	SELECT dc.name, COALESCE(h.type,'Unknown') as hypervisor,vm.name vm_name,vm.description,vm.ram,vm.cpu,vm.state FROM 
	kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
	INNER JOIN
	kinton_reporting.RLS_DATACENTER_V1_0_VW dc
	ON (vm.idDataCenter=dc.idDataCenter)
	LEFT JOIN 
	kinton.hypervisor h
	ON (vm.idHypervisor=h.id)
	WHERE vm.state IN ('LOCKED','UNKNOWN');
    
    CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_FAILED_CONVERSIONS_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_FAILED_CONVERSIONS_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    	CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

	select  dc.name , cnv.virtualimage_name,cnv.type, cnv.creation_date,cnv.osType,
	COALESCE(cnv.sourceType,'Unknown') sourcetype,
	COALESCE(cnv.targetType,'Unknown') targettype,
	cnv.state
	from 
		kinton_reporting.RLS_VIRTUALIMAGE_CONVERSIONS_V1_0_VW cnv
	INNER JOIN
		kinton_reporting.RLS_DATACENTER_V1_0_VW dc 
	ON (cnv.idDataCenter=dc.idDataCenter)
	WHERE state= 'FAILED'
	order by dc.name,creation_date;

    	CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;

DROP PROCEDURE IF EXISTS kinton_reports.RPT_RECENT_ERRORS_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_RECENT_ERRORS_v1_0(rls_abiquo_user VARCHAR(128),p_num_days int)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT EventTime, Severity, Enterprise, User, /*Component,*/ Action, EventMessage
    FROM
        kinton_reporting.RLS_EVENTS_V1_0_VW
    WHERE EventTime >= DATE_SUB(now(),INTERVAL p_num_days DAY)
    AND   severity in ('MAJOR','CRITICAL','ERROR')
    ORDER BY EventTime ASC;

    CALL kinton_reporting.CleanupRLS;

END$$
delimiter ;


DROP PROCEDURE IF EXISTS kinton_reports.RPT_NETWORK_INTERFACES_v1_0;
DELIMITER $
CREATE PROCEDURE kinton_reports.RPT_NETWORK_INTERFACES_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN

    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

	select 	dc.name,
		ni.physicalmachine_name,
		ni.description,
		ni.ram,
		ni.cpu,
		ni.statedescription,
		ni.ipmiIP,
		ni.ipmiPort,
		ni.networkinterface_name,
		ni.mac
	from 
		kinton_reporting.RLS_NETWORK_INTERFACE_V1_0_VW ni
	INNER JOIN
		kinton_reporting.RLS_DATACENTER_V1_0_VW dc 
	ON (ni.idDataCenter=dc.idDataCenter)	
	where networkservicetype_name is null
	ORDER BY dc.name,
		ni.physicalmachine_name, 
		ni.networkinterface_name;

    CALL kinton_reporting.CleanupRLS;

END$$

delimiter ;





