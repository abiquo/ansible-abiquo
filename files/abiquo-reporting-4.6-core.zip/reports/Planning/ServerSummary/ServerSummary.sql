SELECT "Creating procedure for the Server Summary report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ServerSummary_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ServerSummary_v1_0(rls_abiquo_user VARCHAR(128))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Server Summary Report
    # Procedure Version : 2.6.2
    #
    ##########################################################################################

    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT 
       st.name AS DatacenterName,
       st.situation as Location,
       st.numServers AS NumberOfServers,
       st.numCores AS NumberOfServerCores,
       vt.numVMs AS NumberOfVMs,
       vt.numVMCPUs AS NumberOfVCPUs,
       CAST((vt.numVMCPUs/st.numCores)*100 AS UNSIGNED) AS CPUOverallocatedPct,
       COALESCE(mt.createdHosts,0) AS CreatedServers,
       COALESCE(mt.deletedHosts,0) AS DeletedServers
    FROM
       kinton_reporting.RLS_DATACENTER_V1_0_VW dcrls,
       (SELECT
           dc.idDataCenter,
	   dc.situation,
           dc.name,
           COUNT(*) AS numServers,
           SUM(pm.cpu) AS numCores
       FROM
           kinton.physicalmachine pm,
           kinton_reporting.RLS_DATACENTER_V1_0_VW dc
       WHERE
           pm.idDataCenter=dc.idDataCenter
       GROUP BY dc.idDataCenter) st,

       (SELECT
           dc.idDataCenter,
           dc.name,
           COUNT(*) AS numVMs,
           SUM(vm.cpu) AS numVMCPUs
       FROM
           kinton.virtualmachine vm,
           kinton.hypervisor h,
           kinton.physicalmachine pm,
           kinton_reporting.RLS_DATACENTER_V1_0_VW dc
       WHERE
           pm.idDataCenter=dc.idDataCenter AND
           pm.idPhysicalMachine=h.idPhysicalMachine AND
           h.id=vm.idHypervisor AND
           vm.state <> 'NOT_ALLOCATED'
       GROUP BY dc.idDataCenter) vt

       LEFT JOIN
       (SELECT
           dc.idDataCenter,
           dc.name,
           SUM(IF(m.actionperformed='MACHINE_CREATE',1,0)) AS createdHosts,
           SUM(IF(m.actionperformed='MACHINE_DELETE',1,0)) AS deletedHosts
       FROM
           kinton.metering m,
           kinton_reporting.RLS_DATACENTER_V1_0_VW dc
       WHERE
           m.timestamp >= DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND
           m.actionperformed IN ('MACHINE_CREATE', 'MACHINE_DELETE') AND 
           m.idDataCenter=dc.idDataCenter
       GROUP BY dc.idDataCenter) mt ON mt.idDataCenter=vt.idDataCenter
    WHERE
       dcrls.idDataCenter=st.idDataCenter AND
       vt.idDataCenter=st.idDataCenter
    ORDER BY st.name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
