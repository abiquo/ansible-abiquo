/*
*************************************************
**  SystemActivity
*************************************************
*/

drop procedure if exists  kinton_reports.RPT_System_Activity_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE   kinton_reports.`RPT_System_Activity_v1_0`()
BEGIN
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_24hr_clock');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_24hr_clock_pivot');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_empty_dates');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_count_by_date_hour');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_component_counts');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_enterprise_component_counts');
	call RPT_Common_Drop_Temp_Table_v1_0('tmp_enterprise_activity_counts');
	select 1;
END$$
delimiter ;

/*
*************************************************
**  SystemComponentUsageTotals
*************************************************
*/

drop procedure if exists kinton_reports.RPT_System_Component_Usage_Totals_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_System_Component_Usage_Totals_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP,
IN p_type INT) /* 0 all, 1, user,ent 2, vdc,vapp,vm */
BEGIN

	DECLARE l_temp_tab_exists INT DEFAULT 0;

	call RPT_Common_Temp_Table_Exists_v1_0('tmp_component_counts', l_temp_tab_exists);

	if l_temp_tab_exists = 0
         then
		call RPT_System_Build_Component_Counts_v1_0( rls_usr , p_startDate, p_endDate);
	end if;

	if p_type = 0
	then

		SELECT CASE component WHEN 'USER' THEN 'Users'
		WHEN 'ENTERPRISE'  THEN  'Enterprises'
		WHEN 'VIRTUAL_MACHINE'  THEN 'VMs'
		WHEN 'VIRTUAL_APPLIANCE'  THEN 'VAPPs'
		WHEN 'VIRTUAL_DATACENTER' THEN 'VDCs' END as component,
		greatest(current_total-end_current_delta-start_end_delta,0) as start_total,
		greatest(current_total-end_current_delta,0) as end_total,
		current_total,
		floor((((current_total-end_current_delta)-(current_total-end_current_delta-start_end_delta))
		/greatest((current_total-end_current_delta-start_end_delta),1))*100 ) as pctchange
		from tmp_component_counts
		ORDER BY CASE component WHEN 'USER' THEN 1
		WHEN 'ENTERPRISE'  THEN  0
		WHEN 'VIRTUAL_MACHINE'  THEN 4
		WHEN 'VIRTUAL_APPLIANCE'  THEN 3
		WHEN 'VIRTUAL_DATACENTER' THEN 2 END;

	elseif p_type=1
	then

		SELECT CASE component WHEN 'USER' THEN 'Users'
		WHEN 'ENTERPRISE'  THEN  'Enterprises'
		WHEN 'VIRTUAL_MACHINE'  THEN 'VMs'
		WHEN 'VIRTUAL_APPLIANCE'  THEN 'VAPPs'
		WHEN 'VIRTUAL_DATACENTER' THEN 'VDCs' END as component,
		greatest(current_total-end_current_delta-start_end_delta,0) as start_total,
		greatest(current_total-end_current_delta,0) as end_total,
		current_total,
		floor((((current_total-end_current_delta)-(current_total-end_current_delta-start_end_delta))
		/greatest((current_total-end_current_delta-start_end_delta),1))*100 ) as pctchange
		from tmp_component_counts
		WHERE COMPONENT IN ('USER', 'ENTERPRISE' )
		ORDER BY CASE component WHEN 'USER' THEN 1
		WHEN 'ENTERPRISE'  THEN  0
		WHEN 'VIRTUAL_MACHINE'  THEN 4
		WHEN 'VIRTUAL_APPLIANCE'  THEN 3
		WHEN 'VIRTUAL_DATACENTER' THEN 2 END;
	else
		SELECT CASE component WHEN 'USER' THEN 'Users'
		WHEN 'ENTERPRISE'  THEN  'Enterprises'
		WHEN 'VIRTUAL_MACHINE'  THEN 'VMs'
		WHEN 'VIRTUAL_APPLIANCE'  THEN 'VAPPs'
		WHEN 'VIRTUAL_DATACENTER' THEN 'VDCs' END as component,
		greatest(current_total-end_current_delta-start_end_delta,0) as start_total,
		greatest(current_total-end_current_delta,0) as end_total,
		current_total,
		floor((((current_total-end_current_delta)-(current_total-end_current_delta-start_end_delta))
		/greatest((current_total-end_current_delta-start_end_delta),1))*100 ) as pctchange
		from tmp_component_counts
		WHERE COMPONENT NOT  IN ('USER', 'ENTERPRISE' )
		ORDER BY CASE component WHEN 'USER' THEN 1
		WHEN 'ENTERPRISE'  THEN  0
		WHEN 'VIRTUAL_MACHINE'  THEN 4
		WHEN 'VIRTUAL_APPLIANCE'  THEN 3
		WHEN 'VIRTUAL_DATACENTER' THEN 2 END;

	end if;


END$$
delimiter ;

drop procedure if exists kinton_reports.RPT_System_Build_Component_Counts_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_System_Build_Component_Counts_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP)
BEGIN

    	DECLARE done INT DEFAULT FALSE;
	DECLARE l_comp varchar(255);
	DECLARE l_val int;

    	DECLARE cur1 CURSOR FOR 	select Component,
						sum(add_remove_delta) as add_remove_delta
						from  kinton_reporting.RLS_ADD_REMOVE_EVENTS_V1_0_VW
						WHERE   EventTime >= p_startDate AND EventTime <= p_endDate
						group by Component;

    	DECLARE cur2 CURSOR FOR 	select Component,
						sum(add_remove_delta) as add_remove_delta
						from  kinton_reporting.RLS_ADD_REMOVE_EVENTS_V1_0_VW
						WHERE   EventTime >  p_endDate AND EventTime <= curdate()
						group by Component;

 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;



    	CALL kinton_reporting.InitialiseRLS(rls_usr);

	call RPT_Common_Drop_Temp_Table_v1_0('tmp_component_counts');
	CREATE TEMPORARY TABLE IF NOT EXISTS tmp_component_counts ( component varchar(255),start_end_delta int, end_current_delta int,current_total int);

	insert into tmp_component_counts (component,start_end_delta,end_current_delta,current_total) VALUES ('USER',0,0,0);
	insert into tmp_component_counts (component,start_end_delta,end_current_delta,current_total) VALUES ('ENTERPRISE',0,0,0);
	insert into tmp_component_counts (component,start_end_delta,end_current_delta,current_total) VALUES ('VIRTUAL_MACHINE',0,0,0);
	insert into tmp_component_counts (component,start_end_delta,end_current_delta,current_total) VALUES ('VIRTUAL_APPLIANCE',0,0,0);
	insert into tmp_component_counts (component,start_end_delta,end_current_delta,current_total) VALUES ('VIRTUAL_DATACENTER',0,0,0);

         	OPEN cur1;

       	cur1_loop:  LOOP
		FETCH cur1 INTO l_comp,l_val;
		IF done
		THEN
			LEAVE  cur1_loop;
		ELSE
			UPDATE tmp_component_counts
			SET start_end_delta = l_val
			WHERE component=l_comp;
		END IF;
	END LOOP cur1_loop;

	CLOSE cur1;

	SET done=FALSE;

         	OPEN cur2;

       	cur2_loop:  LOOP
		FETCH cur2 INTO l_comp,l_val;
		IF done
		THEN
			LEAVE  cur2_loop;
		ELSE
			UPDATE tmp_component_counts
			SET end_current_delta = l_val
			WHERE component=l_comp;
		END IF;
	END LOOP cur2_loop;

	CLOSE cur2;

	SET done=FALSE;

	update tmp_component_counts set current_total= (SELECT count(*) from kinton_reporting.RLS_VDC_V1_0_VW)
	WHERE component='VIRTUAL_DATACENTER';

	update tmp_component_counts set current_total= (SELECT count(*) from kinton_reporting.RLS_VAPP_V1_0_VW)
	WHERE component='VIRTUAL_APPLIANCE';

	update tmp_component_counts set current_total= (SELECT count(*) from kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW)
	WHERE component='VIRTUAL_MACHINE';

	update tmp_component_counts set current_total= (SELECT count(*) from kinton_reporting.RLS_USER_V1_0_VW)
	WHERE component='USER';

	update tmp_component_counts set current_total= (SELECT count(*) from kinton_reporting.RLS_ENTERPRISE_V1_0_VW)
	WHERE component='ENTERPRISE';

	call RPT_Common_Drop_Temp_Table_v1_0('tmp_component_counts_flip');
	CREATE TEMPORARY TABLE IF NOT EXISTS tmp_component_counts_flip ( Category varchar(255),Series varchar(20), Value int);

	INSERT INTO tmp_component_counts_flip
	select component as 'Category', date_format(p_startDate,'%Y/%m/%d') as Series,greatest(current_total-end_current_delta-start_end_delta,0) as 'Value'
	FROM tmp_component_counts;

	INSERT INTO tmp_component_counts_flip
	select component as 'Category',date_format(p_endDate,'%Y/%m/%d') as Series,greatest(current_total-end_current_delta,0) as 'Value'
	FROM tmp_component_counts;

	INSERT INTO tmp_component_counts_flip
	select component as 'Category',date_format( curdate(),'%Y/%m/%d') as Series,current_total as 'Value'
	FROM tmp_component_counts;

	CALL kinton_reporting.CleanupRLS();

END$$
delimiter ;

/*
*************************************************
**  SystemComponentUsageChart
*************************************************
*/


drop procedure if exists kinton_reports.RPT_System_Component_Usage_Chart_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_System_Component_Usage_Chart_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP )
BEGIN

	DECLARE l_temp_tab_exists INT DEFAULT 0;

	call RPT_Common_Temp_Table_Exists_v1_0('tmp_component_counts', l_temp_tab_exists);

	if l_temp_tab_exists = 0
         then
		call RPT_System_Build_Component_Counts_v1_0( rls_usr , p_startDate, p_endDate);
	end if;

		SELECT CASE Category WHEN 'USER' THEN 'Users'
		WHEN 'ENTERPRISE'  THEN  'Enterprises'
		WHEN 'VIRTUAL_MACHINE'  THEN 'VMs'
		WHEN 'VIRTUAL_APPLIANCE'  THEN 'VAPPs'
		WHEN 'VIRTUAL_DATACENTER' THEN 'VDCs' END as Category,Series,Value
		FROM  tmp_component_counts_flip
		ORDER BY CASE Category WHEN 'USER' THEN 0
		WHEN 'ENTERPRISE'  THEN  1
		WHEN 'VIRTUAL_MACHINE'  THEN 4
		WHEN 'VIRTUAL_APPLIANCE'  THEN 3
		WHEN 'VIRTUAL_DATACENTER' THEN 2 END,Series;

END$$
delimiter ;

/*
*************************************************
**  SystemActivityDailyChart
*************************************************
*/
drop procedure if exists  kinton_reports.RPT_System_Activity_Daily_Chart_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE  kinton_reports.`RPT_System_Activity_Daily_Chart_v1_0`(
IN rls_usr CHAR(64),
IN p_query_type INT, /* 0 all events, 1 user_login events, 2 errors */
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP
)
BEGIN
	CALL RPT_System_Build_Events_By_Hour_v1_0(rls_usr, p_startDate,p_endDate);

	/* build table containing one row for each day in the date range so that days with no
	   events are reported back as having 0 events rather than simply being omitted
	*/
	call RPT_System_Empty_Dates_v1_0(p_startDate,p_endDate);

	IF p_query_type=0 /*all events*/
	THEN
		SELECT 	cast(date_format(empty.nodatadate,'%Y/%m/%d') as date) as Day,
			CASE when data.cnt is null then 0 else data.cnt end as cnt
		FROM
    			tmp_empty_dates empty
		LEFT JOIN
    			(select date_format(date_hour,'%Y/%m/%d') day,sum(cnt) cnt
			from tmp_count_by_date_hour
			group by  date_format(date_hour,'%Y/%m/%d')) data
		ON (data.day=empty.nodatadate)
		ORDER BY  Day;
	ELSEIF p_query_type=1 /*logins*/
	THEN
		SELECT 	cast(date_format(empty.nodatadate,'%Y/%m/%d') as date) as Day,
			CASE when data.cnt is null then 0 else data.cnt end as cnt
		FROM
    			tmp_empty_dates empty
		LEFT JOIN
    			(select date_format(date_hour,'%Y/%m/%d') day,sum(cnt) cnt
			from tmp_count_by_date_hour
			where login=1
			group by  date_format(date_hour,'%Y/%m/%d')) data
		ON (data.day=empty.nodatadate)
		ORDER BY  Day;
	ELSE /*errors*/
		SELECT 	cast(date_format(empty.nodatadate,'%Y/%m/%d') as date) as Day,
			CASE when data.cnt is null then 0 else data.cnt end as cnt
		FROM
    			tmp_empty_dates empty
		LEFT JOIN
    			(select date_format(date_hour,'%Y/%m/%d') day,sum(cnt) cnt
			from tmp_count_by_date_hour
			where severity in ('MAJOR','CRITICAL','ERROR')
			group by  date_format(date_hour,'%Y/%m/%d')) data
		ON (data.day=empty.nodatadate)
		ORDER BY  Day;
	END IF;
END$$
delimiter ;

drop procedure if exists kinton_reports.RPT_System_Build_Events_By_Hour_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_System_Build_Events_By_Hour_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP)
BEGIN
    	CALL kinton_reporting.InitialiseRLS(rls_usr);

	CREATE TEMPORARY TABLE IF NOT EXISTS tmp_count_by_date_hour
	SELECT 		date_format(eventtime,'%Y/%m/%d %H') date_hour,
			CASE action when 'user_login' then 1 when 'session_login' then 1 else 0 end as login,
			severity,
			count(*) as cnt
	FROM 		kinton_reporting.RLS_EVENTS_V1_0_VW
	WHERE   	EventTime >= p_startDate AND EventTime <= p_endDate
	GROUP BY 	date_format(eventtime,'%Y/%m/%d %H'),login, severity;

	CALL kinton_reporting.CleanupRLS();
END$$
delimiter ;

drop procedure if exists kinton_reports.RPT_System_Empty_Dates_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_System_Empty_Dates_v1_0`(
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP
)
BEGIN
   DECLARE currval INT;
   DECLARE datediff INT;

	DECLARE l_temp_tab_exists INT DEFAULT 0;

   	SET currval = 0;
   	SET datediff = 0;

	call RPT_Common_Temp_Table_Exists_v1_0('tmp_empty_dates', l_temp_tab_exists);

	if l_temp_tab_exists = 0
    	then
	   begin
		   SET datediff=DATEDIFF(p_endDate,p_startDate);
		   CREATE TEMPORARY TABLE IF NOT EXISTS tmp_empty_dates (nodatadate timestamp, nodatavalue int);
		   INSERT INTO tmp_empty_dates (nodatadate, nodatavalue) VALUES (p_startDate,0);

		   dateloop: LOOP
				SET currval=currval+1;

				INSERT INTO tmp_empty_dates (nodatadate, nodatavalue) VALUES (DATE_ADD(p_startDate, INTERVAL  currval DAY),0);

				IF currval<datediff THEN
					ITERATE dateloop;
				END IF;
				LEAVE dateloop;
		   END LOOP dateloop;
	   end;
	end if;
END$$

delimiter ;

/*
*************************************************
**  SystemActivityHourlyMap
*************************************************
*/

drop procedure if exists  kinton_reports.RPT_System_Activity_Hourly_Map_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE  kinton_reports.`RPT_System_Activity_Hourly_Map_v1_0` (
IN rls_usr CHAR(64),
IN p_query_type INT, /* 0 all events, 1 user_login events, 2 errors */
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP
)
BEGIN

	DECLARE done INT DEFAULT FALSE;

	DECLARE	l_hr varchar(255);
	DECLARE	l_val varchar(255);
	DECLARE	l_tot int DEFAULT 0;

	DECLARE cur_all CURSOR FOR
			select date_format(date_hour,'%H') hour,sum(cnt) cnt
			from tmp_count_by_date_hour
			group by  date_format(date_hour,'%H')
			ORDER BY Hour;

	DECLARE cur_login CURSOR FOR
			select date_format(date_hour,'%H') hour,sum(cnt) cnt
			from tmp_count_by_date_hour
			where login=1
			group by  date_format(date_hour,'%H')
			ORDER BY Hour;

	DECLARE cur_error CURSOR FOR
			select date_format(date_hour,'%H') hour,sum(cnt) cnt
			from tmp_count_by_date_hour
			where severity in ('MAJOR','CRITICAL','ERROR')
			group by  date_format(date_hour,'%H')
			ORDER BY Hour;


 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;

	CALL RPT_System_Build_Events_By_Hour_v1_0(rls_usr, p_startDate,p_endDate);

	CALL RPT_System_24hr_Clock_Pivot_v1_0;

	IF p_query_type=0 /*all events*/
	THEN

       		OPEN cur_all;
		cur_all :  LOOP
			FETCH  cur_all  INTO l_hr,l_val;
			IF done
			THEN
				LEAVE   cur_all ;
			ELSE
				call RPT_System_24hr_Clock_Pivot_Update_v1_0( l_hr,l_val);
				SET l_tot=l_tot+l_val;
			END IF;
		END LOOP cur_all;
		CLOSE  cur_all ;
		SET done=FALSE;
	ELSEIF p_query_type=1 /*logins*/
	THEN
		OPEN cur_login;
		cur_login :  LOOP
			FETCH  cur_login  INTO l_hr,l_val;
			IF done
			THEN
				LEAVE   cur_login ;
			ELSE
				call RPT_System_24hr_Clock_Pivot_Update_v1_0( l_hr,l_val);
				SET l_tot=l_tot+l_val;
			END IF;
		END LOOP cur_login;
		CLOSE  cur_login ;
		SET done=FALSE;
	ELSE /*errors*/
		OPEN cur_error;
		cur_error :  LOOP
			FETCH  cur_error  INTO l_hr,l_val;
			IF done
			THEN
				LEAVE   cur_error ;
			ELSE
				call RPT_System_24hr_Clock_Pivot_Update_v1_0( l_hr,l_val);
				SET l_tot=l_tot+l_val;
			END IF;
		END LOOP cur_error;
		CLOSE  cur_error ;
		SET done=FALSE;
	END IF;
	call RPT_System_24hr_Clock_Pivot_Update_v1_0('total',l_tot);
		select
	h00/htotal*100 ,h00,
	h01/htotal*100 ,h01,
	h02/htotal*100 ,h02,
	h03/htotal*100 ,h03,
	h04/htotal*100 ,h04,
	h05/htotal*100 ,h05,
	h06/htotal*100 ,h06,
	h07/htotal*100 ,h07,
	h08/htotal*100 ,h08,
	h09/htotal*100 ,h09,
	h10/htotal*100 ,h10,
	h11/htotal*100 ,h11,
	h12/htotal*100 ,h12,
	h13/htotal*100 ,h13,
	h14/htotal*100 ,h14,
	h15/htotal*100 ,h15,
	h16/htotal*100 ,h16,
	h17/htotal*100 ,h17,
	h18/htotal*100 ,h18,
	h19/htotal*100 ,h19,
	h20/htotal*100 ,h20,
	h21/htotal*100 ,h21,
	h22/htotal*100 ,h22,
	h23/htotal*100 ,h23,
	htotal
	from tmp_24hr_clock_pivot;
END$$
delimiter ;

drop procedure if exists  kinton_reports.RPT_System_24hr_Clock_Pivot_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE  kinton_reports.`RPT_System_24hr_Clock_Pivot_v1_0`()
BEGIN

   call RPT_Common_Drop_Temp_Table_v1_0('tmp_24hr_clock_pivot');


   CREATE TEMPORARY TABLE IF NOT EXISTS tmp_24hr_clock_pivot (
	h00 int,
	h01 int,
	h02 int,
	h03 int,
	h04 int,
	h05 int,
	h06 int,
	h07 int,
	h08 int,
	h09 int,
	h10 int,
	h11 int,
	h12 int,
	h13 int,
	h14 int,
	h15 int,
	h16 int,
	h17 int,
	h18 int,
	h19 int,
	h20 int,
	h21 int,
	h22 int,
	h23 int,
	htotal int);

	insert into tmp_24hr_clock_pivot
	(h00 ,
	h01 ,
	h02 ,
	h03 ,
	h04 ,
	h05 ,
	h06 ,
	h07 ,
	h08 ,
	h09 ,
	h10 ,
	h11 ,
	h12 ,
	h13 ,
	h14 ,
	h15 ,
	h16 ,
	h17 ,
	h18 ,
	h19 ,
	h20 ,
	h21 ,
	h22 ,
	h23 ,
	htotal)
	values
	(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);


END$$
delimiter ;

drop procedure if exists  kinton_reports.RPT_System_24hr_Clock_Pivot_Update_v1_0;
delimiter $$
CREATE PROCEDURE  kinton_reports.RPT_System_24hr_Clock_Pivot_Update_v1_0(IN colno VARCHAR(255),IN colval VARCHAR(255))
BEGIN
    SET @s = CONCAT('UPDATE tmp_24hr_clock_pivot set  h',colno,'=',colval);
    PREPARE stmt FROM @s;
    EXECUTE stmt;
END$$
delimiter ;

/*
*************************************************
**  EnterpriseRankedByComponentChart
*************************************************
*/

drop procedure if exists kinton_reports.RPT_Enterprise_Ranked_By_Component_Chart_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_Enterprise_Ranked_By_Component_Chart_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP,
IN p_component_type CHAR(64),
IN p_metric int,
IN p_limit int)
BEGIN
    DECLARE l_metric_col char(255);

    call RPT_Enterprise_Component_Counts_v1_0(rls_usr, p_startDate, p_endDate);

   if p_metric=0
    then
	    SET @s = CONCAT('SELECT EnterpriseName,SUM(end_total) as tot FROM tmp_enterprise_component_counts WHERE Component =''', p_component_type,'''  AND  end_total > 0 		group by EnterpriseName order by SUM(end_total) DESC LIMIT ',p_limit);
   elseif p_metric=1
   then
	   	    SET @s = CONCAT('SELECT  EnterpriseName,SUM(start_end_delta) as tot FROM tmp_enterprise_component_counts WHERE start_end_delta  > 0 AND Component =''', p_component_type,'''  group by EnterpriseName order by 				SUM(start_end_delta) DESC  LIMIT ',p_limit);
   else
	   	    SET @s = CONCAT('SELECT EnterpriseName,SUM(start_end_delta)*-1 as tot FROM tmp_enterprise_component_counts WHERE start_end_delta  < 0 AND Component =''', p_component_type,'''  group by EnterpriseName order by 				SUM(start_end_delta) ASC LIMIT ',p_limit);

   end if;

    PREPARE stmt FROM @s;
    EXECUTE stmt;

END$$
delimiter ;


drop procedure if exists kinton_reports.RPT_Enterprise_Component_Counts_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_Enterprise_Component_Counts_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP)
BEGIN

    	DECLARE done INT DEFAULT FALSE;
	DECLARE l_comp varchar(255);
	DECLARE l_idEnterprise int;
	DECLARE l_val int;

	DECLARE l_temp_tab_exists int default 0;

    	DECLARE cur1 CURSOR FOR 	select 	case v.dbg when 3 then x.idEnterprise else v.idEnterprise end as idEnterprise,
						Component,
						sum(add_remove_delta) as add_remove_delta
						from
							kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW v
						left join
							kinton_reporting.RLS_ENTERPRISE_V1_0_VW x
						ON (x.name =v.name)
						WHERE   EventTime >= p_startDate AND EventTime <= p_endDate
						AND    Component IN ('VIRTUAL_MACHINE','USER')
						group by  case v.dbg when 3 then x.idEnterprise else v.idEnterprise end ,Component
						having idEnterprise is not null;

    	DECLARE cur2 CURSOR FOR  select 	case v.dbg when 3 then x.idEnterprise else v.idEnterprise end as idEnterprise,
						Component,
						sum(add_remove_delta) as add_remove_delta
						from
							kinton_reporting.RLS_ADD_REMOVE_EVENTS_V2_0_VW v
						left join
							kinton_reporting.RLS_ENTERPRISE_V1_0_VW x
						ON (x.name =v.name)
						WHERE   EventTime >  p_endDate AND EventTime <= now()
						AND    Component IN ('VIRTUAL_MACHINE','USER')
						group by  case v.dbg when 3 then x.idEnterprise else v.idEnterprise end ,Component
						having idEnterprise is not null;

 	DECLARE CONTINUE HANDLER FOR NOT FOUND SET done = TRUE;



    	CALL kinton_reporting.InitialiseRLS(rls_usr);

	call RPT_Common_Temp_Table_Exists_v1_0('tmp_enterprise_component_counts', l_temp_tab_exists);

	if l_temp_tab_exists = 0
         then


		CREATE TEMPORARY TABLE IF NOT EXISTS tmp_enterprise_component_counts ( component varchar(255), EnterpriseName varchar(40), idEnterprise int, current_total int, end_total int, start_end_delta int, end_current_delta int);

		insert into tmp_enterprise_component_counts
		SELECT  		'VIRTUAL_MACHINE' as component,
					e.name as EnterpriseName,
					 vm.idEnterprise as idEnterprise,
					count(*) as current_total,
					0 as end_total,
					0 as start_end_delta,
					0 as end_current_delta
		FROM 		kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW  vm  , kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
		WHERE 		vm.idEnterprise= e.idEnterprise
		GROUP BY 	idEnterprise;

		insert into tmp_enterprise_component_counts
		SELECT  		'USER' as component,
					e.name as EnterpriseName,
					 vm.idEnterprise as idEnterprise,
					count(*) as current_total,
					0 as end_total,
					0 as start_end_delta,
					0 as end_current_delta
		FROM 		kinton_reporting.RLS_USER_V1_0_VW  vm  , kinton_reporting.RLS_ENTERPRISE_V1_0_VW e
		WHERE 		vm.idEnterprise= e.idEnterprise
		GROUP BY 	idEnterprise;

         		OPEN cur1;
	       	cur1_loop:  LOOP
			FETCH cur1 INTO l_idEnterprise,l_comp,l_val;
			IF done
			THEN
				LEAVE  cur1_loop;
			ELSE
				UPDATE tmp_enterprise_component_counts
				SET start_end_delta = l_val
				WHERE component=l_comp and idEnterprise= l_idEnterprise;
			END IF;
		END LOOP cur1_loop;
		CLOSE cur1;

		SET done=FALSE;

 	        	OPEN cur2;
     		cur2_loop:  LOOP
			FETCH cur2 INTO l_idEnterprise,l_comp,l_val;
			IF done
			THEN
				LEAVE  cur2_loop;
			ELSE
				UPDATE tmp_enterprise_component_counts
				SET end_current_delta = l_val
				WHERE component=l_comp and idEnterprise= l_idEnterprise;
			END IF;
		END LOOP cur2_loop;
		CLOSE cur2;

		SET done=FALSE;

		update tmp_enterprise_component_counts set end_total = current_total - end_current_delta;

		CALL kinton_reporting.CleanupRLS();

end if;


END$$
delimiter ;



/*
*************************************************
**  EnterpriseRankedByActivityChart
*************************************************
*/

drop procedure if exists kinton_reports.RPT_Enterprise_Ranked_By_Activity_Chart_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_Enterprise_Ranked_By_Activity_Chart_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP,
IN p_metric int,
IN p_limit int)
BEGIN
    DECLARE l_metric_col char(255);

    call RPT_Enterprise_Activity_Counts_v1_0(rls_usr, p_startDate, p_endDate);

   if p_metric=0
    then
	    SET @s = CONCAT('SELECT EnterpriseName,current_activity as tot FROM tmp_enterprise_activity_counts 	    order by current_activity DESC LIMIT ',p_limit);
   elseif p_metric=1
   then
	   	    SET @s = CONCAT('SELECT EnterpriseName,pct_change as tot FROM tmp_enterprise_activity_counts WHERE  pct_change > 0	    order by pct_change DESC LIMIT ',p_limit);
   else
	   	    SET @s = CONCAT('SELECT EnterpriseName, pct_change*-1 as tot FROM tmp_enterprise_activity_counts WHERE  pct_change < 0 	    order by pct_change ASC LIMIT ',p_limit);

   end if;

    PREPARE stmt FROM @s;
    EXECUTE stmt;

END$$
delimiter ;

drop procedure if exists kinton_reports.RPT_Enterprise_Activity_Counts_v1_0;
delimiter $$
CREATE DEFINER=`root`@`localhost` PROCEDURE kinton_reports.`RPT_Enterprise_Activity_Counts_v1_0`(
IN rls_usr CHAR(64),
IN p_startDate TIMESTAMP,
IN p_endDate TIMESTAMP)
BEGIN

CALL kinton_reporting.InitialiseRLS(rls_usr);

CREATE TEMPORARY TABLE IF NOT EXISTS tmp_enterprise_activity_counts
SELECT
e.idEnterprise as idEnterprise,
e.name as EnterpriseName,
 m.current_activity as current_activity,
round(((m.current_activity-m.previous_activity)/m.previous_activity)*100) pct_change
from (
select m.idEnterprise,
GREATEST(SUM(CASE WHEN timestamp >= p_startDate THEN 1 ELSE 0 END),1) as current_activity,
GREATEST(SUM(CASE WHEN timestamp < p_startDate THEN 1 ELSE 0 END),1) as previous_activity
from  kinton.metering m
WHERE timestamp > date_sub(CAST(p_startDate AS DATE), INTERVAL datediff(p_endDate, p_startDate) DAY)
and timestamp < p_endDate
group by m.idEnterprise
) m , kinton.enterprise e
where e.identerprise=m.identerprise;

CALL kinton_reporting.CleanupRLS();

END$$

delimiter ;
