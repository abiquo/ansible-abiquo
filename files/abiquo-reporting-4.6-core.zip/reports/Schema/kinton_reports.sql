SELECT "Creating reports schema ..." AS " ";
CREATE SCHEMA IF NOT EXISTS kinton_reports;