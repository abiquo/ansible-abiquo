# InventoryReport SQL
SELECT "Creating procedures for the Inventory report..." AS " ";

#
# Main report that returns the VM Details for the enterprise
#
DROP PROCEDURE IF EXISTS kinton_reports.RPT_Inventory_VM_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Inventory_VM_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Inventory Report - Virtual Machines
    # Procedure Version : 2.6.1
    #
    ##########################################################################################

    # Default the Enterprise to the user's own Enterpise if not supplied...
    IF (p_idEnterprise IS NULL) THEN
       SELECT idEnterprise INTO p_idEnterprise FROM kinton.user WHERE user=rls_abiquo_user;
    END IF;

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT ent.name AS 'Enterprise', vdc.name AS 'Virtual Datacenter', vm.ApplianceName AS 'Virtual Appliance', vm.name AS 'Virtual Machine', vm.label as 'VM Friendly Name', vm.description AS 'Description', vm.state AS 'Virtual Machine State',
           vi.name AS 'Image', IF(cc.name IS NOT NULL, cc.name, 'N/A') AS 'Cost Code', vm.cpu AS 'CPU', vm.ram AS 'Memory (MB)', deployTime AS 'Date Deployed',
           COALESCE(ipSummary.NicCount,0) AS 'Nic Count', COALESCE(IPList,'') AS 'IP List', COALESCE(VlanTagList,'') AS 'Vlan Tag List',
           COALESCE(extVolSummary.NumExternalDisks,0) AS 'Num External Disks', COALESCE(extVolSummary.DiskSizeList, '') AS ExtDiskSizeList, COALESCE(extVolSummary.TierList,'') as 'Tier List',
           COALESCE(locVolSummary.NumLocalDisks,0) AS 'Num Local Disks', COALESCE(locVolSummary.DiskSizeList,'') AS 'Local Disk Size List',
           vm.idUser AS idUser, ent.idEnterprise, vm.idVirtualDataCenter, vm.idVirtualApp, vm.idVM AS idVM,
           vm.vdrp_enabled AS 'RDP enabled', vm.vdrpIP AS 'RDP IP', vm.vdrpPort AS 'RDP Port'
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vm.idVirtualDataCenter=vdc.idVirtualDataCenter

    INNER JOIN kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent ON vm.idEnterprise=ent.idEnterprise

    INNER JOIN kinton_reporting.RLS_VIRTUAL_IMAGE_V1_0_VW vi ON vi.idImage=vm.idImage

    LEFT JOIN kinton.costCode cc ON cc.idCostCode=vi.cost_code

    LEFT JOIN
    (
        SELECT idVM,
               COUNT(*) AS NicCount,
               GROUP_CONCAT(ip SEPARATOR '\n') AS IPList,
               GROUP_CONCAT(IF(vlan_tag IS NOT NULL, vlan_tag,'n/a') SEPARATOR '\n') AS VlanTagList
        FROM
            kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW
        WHERE
            p_idEnterprise IS NULL OR idEnterprise=p_idEnterprise
        GROUP BY idVM
    ) ipSummary ON vm.idVM=ipSummary.idVM

    LEFT JOIN
    (
        SELECT idVM, COUNT(*) AS NumExternalDisks,
               SUM(DiskGB) AS ExternalDiskGB,
               GROUP_CONCAT(DiskGB SEPARATOR '\n') AS DiskSizeList,
               GROUP_CONCAT(StorageTier SEPARATOR '\n') AS TierList
        FROM kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW
        WHERE
            p_idEnterprise IS NULL OR idEnterprise=p_idEnterprise
        GROUP BY idVM
    ) extVolSummary ON vm.idVM=extVolSummary.idVM

    LEFT JOIN
    (
        SELECT idVM, COUNT(*) AS NumLocalDisks,
               SUM(DiskGB) AS LocalDiskGB,
               GROUP_CONCAT(DiskGB SEPARATOR '\n') AS DiskSizeList
        FROM kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW
        WHERE
            p_idEnterprise IS NULL OR idEnterprise=p_idEnterprise
        GROUP BY idVM
    ) locVolSummary ON vm.idVM=locVolSummary.idVM

    LEFT JOIN
    (SELECT vm.idVM, MAX(m.timestamp) AS deployTime
        FROM kinton.metering m, kinton.virtualmachine vm
        WHERE
            (m.actionperformed LIKE 'VM_DEPLOY%' OR m.actionperformed LIKE 'VIRTUAL_MACHINE_DEPLOY%' OR m.actionperformed LIKE 'VIRTUAL_MACHINE_CAPTURE%') AND
            (m.stacktrace LIKE CONCAT('%',vm.name,'%'))
            AND (p_idEnterprise IS NULL OR vm.idEnterprise=p_idEnterprise)
        GROUP BY vm.idVM
    ) AS vmDeployInfo
        ON (vm.idVM=vmDeployInfo.idVm)

    WHERE
        p_idEnterprise IS NULL OR vm.idEnterprise=p_idEnterprise

    GROUP BY ent.name, vdc.name, vm.ApplianceName, vm.name; #vm.idEnterprise, idVirtualDatacenter, idVirtualApp, idVM;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;



#
# The remaining SPs are for the subreports
#
DROP PROCEDURE IF EXISTS kinton_reports.RPT_Inventory_VApp_Usage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Inventory_VApp_Usage_v1_0(rls_abiquo_user VARCHAR(128), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Inventory Report - VApp Usage
    # Procedure Version : 2.6.1
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  vapp.idEnterprise, vapp.idVirtualDataCenter, vapp.idVirtualApp, 
            COALESCE(v.NumberOfVMs,0) AS NumberOfVMs, COALESCE(v.NumberOfDeployedVMs,0) AS NumberOfDeployedVMs,
            vdc.cpuHard AS CPUHardLimit, vdc.cpuSoft AS CPUSoftLimit, COALESCE(v.TotalCPU,0) AS TotalCPU, COALESCE(v.TotalDeployedCPU,0) AS TotalDeployedCPU,
            vdc.ramHard AS RAMHardLimit, vdc.ramSoft AS RAMSoftLimit, COALESCE(v.TotalRAM,0) AS TotalRAM, COALESCE(v.TotalDeployedRAM,0) AS TotalDeployedRAM,
            CAST(vdc.hdHard/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskHardLimit, CAST(vdc.hdSoft/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskSoftLimit, 
            COALESCE(l.TotalLocalDisk,0) AS TotalLocalDisk, COALESCE(l.TotalDeployedLocalDisk,0) AS TotalDeployedLocalDisk,
            CAST(vdc.storageHard/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskHardLimit, CAST(vdc.storageSoft/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskSoftLimit, 
            COALESCE(e.TotalExternalDisk,0) AS TotalExternalDisk, COALESCE(e.TotalDeployedExternalDisk,0) AS TotalExternalDeployedDisk,
            vdc.publicIPHard AS PublicIPHardLimit, vdc.publicIPSoft AS PublicIPSoftLimit, COALESCE(i.TotalPublicIP,0) AS TotalPublicIP, COALESCE(i.TotalDeployedPublicIP,0) AS TotalDeployedPublicIP,
            vdc.vlanHard AS VlanHardLimit, vdc.vlanSoft AS VlanSoftLimit, COALESCE(vl.TotalVlan,0) AS TotalVlan, COALESCE(vl.TotalDeployedVlan,0) AS TotalDeployedVlan

    FROM kinton_reporting.RLS_VAPP_V1_0_VW vapp

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vapp.idVirtualDataCenter=vdc.idVirtualDataCenter

    LEFT JOIN 
    (SELECT vm.idEnterprise, vm.idVirtualDataCenter, vm.idVirtualApp,
            COUNT(*) AS NumberOfVMs,
            SUM(IF(vm.state != 'NOT_ALLOCATED',1,0)) AS NumberOfDeployedVMs,
            SUM(vm.cpu) AS TotalCPU, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.cpu,0)) AS TotalDeployedCPU, 
            SUM(vm.ram) AS TotalRAM, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.ram,0)) AS TotalDeployedRAM
     FROM
         kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
     WHERE
         p_idVirtualApp IS NULL OR vm.idVirtualApp=p_idVirtualApp
     GROUP BY vm.idVirtualApp) AS v
    ON vapp.idVirtualApp=v.idVirtualApp

    LEFT JOIN  (SELECT vm.idEnterprise, vm.idVirtualDataCenter, vm.idVirtualApp, SUM(l.DiskGB) AS TotalLocalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',l.DiskGB,0)) AS TotalDeployedLocalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW l ON vm.idVM=l.idVM AND vm.idVirtualApp=l.idVirtualApp
                 WHERE
                      p_idVirtualApp IS NULL OR vm.idVirtualApp=p_idVirtualApp
                 GROUP BY l.idVirtualApp) AS l
    ON l.idVirtualApp=vapp.idVirtualApp

    LEFT JOIN  (SELECT vm.idEnterprise, vm.idVirtualDataCenter, vm.idVirtualApp, SUM(e.DiskGB) AS TotalExternalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',e.DiskGB,0)) AS TotalDeployedExternalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW e ON vm.idVM=e.idVM AND vm.idVirtualApp=e.idVirtualApp
                 WHERE
                      p_idVirtualApp IS NULL OR vm.idVirtualApp=p_idVirtualApp
                 GROUP BY e.idVirtualApp) AS e
    ON e.idVirtualApp=vapp.idVirtualApp

    LEFT JOIN  (SELECT i.idEnterprise, vm.idVirtualDataCenter, vm.idVirtualApp, COUNT(*) AS TotalPublicIP, SUM(IF(i.idVirtualDataCenter IS NOT NULL AND vm.state != 'NOT_ALLOCATED',1,0)) AS TotalDeployedPublicIP
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW i 
                      LEFT JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm ON vm.idVM=i.idVM AND vm.idVirtualApp=i.idVirtualApp
                 WHERE
                      (i.networktype='PUBLIC' OR i.networktype IS NULL) AND
                      (p_idVirtualApp IS NULL OR vm.idVirtualApp=p_idVirtualApp or vm.idVirtualApp IS NULL)
                 GROUP BY i.idVirtualDataCenter) AS i   
    ON i.idVirtualApp=vapp.idVirtualApp

    LEFT JOIN  (SELECT vdc1.idEnterprise, vdc1.idVirtualDataCenter, vapp1.idVirtualApp, COUNT(*) AS TotalVlan, SUM(IF(iu.idVirtualApp IS NOT NULL,1,0)) AS TotalDeployedVlan
                 FROM kinton_reporting.RLS_VDC_V1_0_VW vdc1
                      INNER JOIN kinton_reporting.RLS_VAPP_V1_0_VW vapp1 ON vdc1.idVirtualDataCenter=vapp1.idVirtualDataCenter
                      INNER JOIN kinton.vlan_network_assignment vna ON vdc1.idVirtualDataCenter=vna.idVirtualDataCenter
                      INNER JOIN kinton.vlan_network vn ON vna.vlan_network_id=vn.vlan_network_id AND vn.networktype='INTERNAL'
                      LEFT JOIN (SELECT DISTINCT(idVirtualApp) FROM kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW i) iu ON vapp1.idVirtualApp=iu.idVirtualApp
                 WHERE
                      p_idVirtualApp IS NULL OR vapp1.idVirtualApp=p_idVirtualApp
                 GROUP BY vapp1.idVirtualApp) AS vl
    ON vl.idVirtualApp=vapp.idVirtualApp

    WHERE p_idVirtualApp IS NULL OR vapp.idVirtualApp=p_idVirtualApp;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;





DROP PROCEDURE IF EXISTS kinton_reports.RPT_Inventory_VDC_Usage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Inventory_VDC_Usage_v1_0(rls_abiquo_user VARCHAR(128), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Inventory Report - VDC Usage
    # Procedure Version : 2.6.1
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  vdc.idEnterprise, vdc.idVirtualDataCenter,
            COALESCE(v.NumberOfVMs,0) AS NumberOfVMs, COALESCE(v.NumberOfDeployedVMs,0) AS NumberOfDeployedVMs,
            vdc.cpuHard AS CPUHardLimit, vdc.cpuSoft AS CPUSoftLimit, COALESCE(v.TotalCPU,0) AS TotalCPU, COALESCE(v.TotalDeployedCPU,0) AS TotalDeployedCPU,
            vdc.ramHard AS RAMHardLimit, vdc.ramSoft AS RAMSoftLimit, COALESCE(v.TotalRAM,0) AS TotalRAM, COALESCE(v.TotalDeployedRAM,0) AS TotalDeployedRAM,
            CAST(vdc.hdHard/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskHardLimit, CAST(vdc.hdSoft/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskSoftLimit, 
            COALESCE(l.TotalLocalDisk,0) AS TotalLocalDisk, COALESCE(l.TotalDeployedLocalDisk,0) AS TotalDeployedLocalDisk,
            CAST(vdc.storageHard/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskHardLimit, CAST(vdc.storageSoft/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskSoftLimit, 
            COALESCE(e.TotalExternalDisk,0) AS TotalExternalDisk, COALESCE(e.TotalDeployedExternalDisk,0) AS TotalExternalDeployedDisk,
            vdc.publicIPHard AS PublicIPHardLimit, vdc.publicIPSoft AS PublicIPSoftLimit, COALESCE(i.TotalPublicIP,0) AS TotalPublicIP, COALESCE(i.TotalDeployedPublicIP,0) AS TotalDeployedPublicIP,
            vdc.vlanHard AS VlanHardLimit, vdc.vlanSoft AS VlanSoftLimit, COALESCE(vl.TotalVlan,0) AS TotalVlan, COALESCE(vl.TotalDeployedVlan,0) AS TotalDeployedVlan

    FROM kinton_reporting.RLS_VDC_V1_0_VW vdc

    LEFT JOIN 
    (SELECT vm.idEnterprise, vm.idVirtualDataCenter,
            COUNT(*) AS NumberOfVMs,
            SUM(IF(vm.state != 'NOT_ALLOCATED',1,0)) AS NumberOfDeployedVMs,
            SUM(vm.cpu) AS TotalCPU, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.cpu,0)) AS TotalDeployedCPU, 
            SUM(vm.ram) AS TotalRAM, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.ram,0)) AS TotalDeployedRAM
     FROM
         kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
     GROUP BY vm.idVirtualDataCenter) AS v
    ON vdc.idVirtualDataCenter=v.idVirtualDataCenter

    LEFT JOIN  (SELECT vm.idEnterprise, vm.idVirtualDataCenter, SUM(l.DiskGB) AS TotalLocalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',l.DiskGB,0)) AS TotalDeployedLocalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW l ON vm.idVM=l.idVM AND vm.idVirtualDataCenter=l.idVirtualDataCenter
                 GROUP BY l.idVirtualDataCenter) AS l
    ON l.idVirtualDataCenter=vdc.idVirtualDataCenter

    LEFT JOIN  (SELECT vm.idEnterprise, vm.idVirtualDataCenter, SUM(e.DiskGB) AS TotalExternalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',e.DiskGB,0)) AS TotalDeployedExternalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW e ON vm.idVM=e.idVM AND vm.idVirtualDataCenter=e.idVirtualDataCenter
                 GROUP BY e.idVirtualDataCenter) AS e
    ON e.idVirtualDataCenter=vdc.idVirtualDataCenter

    LEFT JOIN  (SELECT idEnterprise, idVirtualDataCenter,  publicIPsReserved as TotalPublicIP ,publicIPsUsed  as TotalDeployedPublicIP 
				FROM kinton.vdc_enterprise_stats_vw) AS i
    ON  (i.idVirtualDataCenter =vdc.idVirtualDataCenter AND vdc.idEnterprise = i.idEnterprise )

    LEFT JOIN  (SELECT idEnterprise,idVirtualDataCenter,vlanUsed as 'TotalVlan', 
                0 as 'TotalDeployedVlan' 
                FROM kinton.vdc_enterprise_stats_vw) AS vl
    ON (vl.idVirtualDataCenter=vdc.idVirtualDataCenter and vl.idEnterprise= vdc.idEnterprise)
    WHERE p_idVirtualDataCenter IS NULL OR vdc.idVirtualDataCenter=p_idVirtualDataCenter;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_Inventory_Enterprise_Usage_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Inventory_Enterprise_Usage_v1_0(rls_abiquo_user VARCHAR(128), p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Inventory Report - Enterprise Usage
    # Procedure Version : 2.6.1
    #
    ##########################################################################################

    # Default the Enterprise to the user's own Enterpise if not supplied...
    IF (p_idEnterprise IS NULL) THEN
       SELECT idEnterprise INTO p_idEnterprise FROM kinton.user WHERE user=rls_abiquo_user;
    END IF;

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  ent.idEnterprise,
            COALESCE(v.NumberOfVMs,0) AS NumberOfVMs, COALESCE(v.NumberOfDeployedVMs,0) AS NumberOfDeployedVMs,
            ent.cpuHard AS CPUHardLimit, ent.cpuSoft AS CPUSoftLimit, COALESCE(v.TotalCPU,0) AS TotalCPU, COALESCE(v.TotalDeployedCPU,0) AS TotalDeployedCPU,
            ent.ramHard AS RAMHardLimit, ent.ramSoft AS RAMSoftLimit, COALESCE(v.TotalRAM,0) AS TotalRAM, COALESCE(v.TotalDeployedRAM,0) AS TotalDeployedRAM,
            CAST(ent.hdHard/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskHardLimit, CAST(ent.hdSoft/1048576/1024 AS DECIMAL(28,2)) AS LocalDiskSoftLimit, 
            COALESCE(l.TotalLocalDisk,0) AS TotalLocalDisk, COALESCE(l.TotalDeployedLocalDisk,0) AS TotalDeployedLocalDisk,
            CAST(ent.storageHard/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskHardLimit, CAST(ent.storageSoft/1048576/1024 AS DECIMAL(28,2)) AS ExternalDiskSoftLimit, 
            COALESCE(e.TotalExternalDisk,0) AS TotalExternalDisk, COALESCE(e.TotalDeployedExternalDisk,0) AS TotalExternalDeployedDisk,
            ent.publicIPHard AS PublicIPHardLimit, ent.publicIPSoft AS PublicIPSoftLimit, COALESCE(i.TotalPublicIP,0) AS TotalPublicIP, COALESCE(i.TotalDeployedPublicIP,0) AS TotalDeployedPublicIP,
            ent.vlanHard AS VlanHardLimit, ent.vlanSoft AS VlanSoftLimit, COALESCE(vl.TotalVlan,0) AS TotalVlan, COALESCE(vl.TotalDeployedVlan,0) AS TotalDeployedVlan

    FROM kinton_reporting.RLS_ENTERPRISE_V1_0_VW ent

    LEFT JOIN 
    (SELECT vm.idEnterprise,
            COUNT(*) AS NumberOfVMs,
            SUM(IF(vm.state != 'NOT_ALLOCATED',1,0)) AS NumberOfDeployedVMs,
            SUM(vm.cpu) AS TotalCPU, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.cpu,0)) AS TotalDeployedCPU, 
            SUM(vm.ram) AS TotalRAM, SUM(IF(vm.state != 'NOT_ALLOCATED',vm.ram,0)) AS TotalDeployedRAM
     FROM
         kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
     GROUP BY vm.idEnterprise) AS v
    ON ent.idEnterprise=v.idEnterprise

    LEFT JOIN  (SELECT vm.idEnterprise, SUM(l.DiskGB) AS TotalLocalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',l.DiskGB,0)) AS TotalDeployedLocalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_LOCAL_VOLUME_V1_0_VW l ON vm.idVM=l.idVM AND vm.idEnterprise=l.idEnterprise
                 GROUP BY l.idEnterprise) AS l
    ON l.idEnterprise=ent.idEnterprise

    LEFT JOIN  (SELECT vm.idEnterprise, SUM(e.DiskGB) AS TotalExternalDisk, SUM(IF(vm.state != 'NOT_ALLOCATED',e.DiskGB,0)) AS TotalDeployedExternalDisk
                 FROM kinton_reporting.RLS_VIRTUAL_MACHINE_V1_0_VW vm
                      INNER JOIN kinton_reporting.RLS_VIRTUAL_MACHINE_EXTERNAL_VOLUME_V1_0_VW e ON vm.idVM=e.idVM AND vm.idEnterprise=e.idEnterprise
                 GROUP BY e.idEnterprise) AS e
    ON e.idEnterprise=ent.idEnterprise

    LEFT JOIN  (SELECT idEnterprise,  publicIPsReserved as TotalPublicIP ,publicIPsUsed  as TotalDeployedPublicIP 
				FROM kinton.enterprise_resources_stats_vw) AS i
    ON i.idEnterprise=ent.idEnterprise

    LEFT JOIN  (
                SELECT idEnterprise,vlanUsed as 'TotalVlan', 0 as 'TotalDeployedVlan' 
                FROM kinton.enterprise_resources_stats_vw) AS vl
    ON vl.idEnterprise=ent.idEnterprise
    WHERE  p_idEnterprise=ent.idEnterprise;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_Inventory_VDC_Networks_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_Inventory_VDC_Networks_v1_0(rls_abiquo_user VARCHAR(128), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Inventory Report - Virtual Machines
    # Procedure Version : 2.6.1
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    # List of all networks assigned to the VDC, including counts of VMs using each network...
    SELECT vna.idVirtualDataCenter, vna.vlan_network_id, vn.vlan_tag, vn.network_name, vn.networktype, COALESCE(inUse.NumVMsUsing,0) AS NumVMsUsing

    FROM kinton.vlan_network_assignment  vna

    INNER JOIN kinton_reporting.RLS_VDC_V1_0_VW vdc ON vdc.idVirtualDataCenter=vna.idVirtualDataCenter

    INNER JOIN kinton.vlan_network vn ON vna.vlan_network_id=vn.vlan_network_id

    LEFT JOIN
    # List of all 'in use' VLANs within a VDC, with a count of VMs using each VLAN...
    (SELECT idVirtualDataCenter, vlan_network_id, vlan_tag, network_name, networktype, COUNT(DISTINCT(idVM)) AS NumVMsUsing
    FROM kinton_reporting.RLS_VIRTUAL_MACHINE_NICS_V1_0_VW
    WHERE idVirtualDataCenter=p_idVirtualDataCenter GROUP BY vlan_network_id) AS inUse

    ON (vna.idVirtualDataCenter=inUse.idVirtualDataCenter AND vna.vlan_network_id=inUse.vlan_network_id)

    WHERE vna.idVirtualDataCenter=p_idVirtualDataCenter
    ORDER BY networktype, network_name;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;
