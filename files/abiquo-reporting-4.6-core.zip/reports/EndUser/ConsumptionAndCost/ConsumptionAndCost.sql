SELECT "Creating procedures for the Resource Consumption & Cost report..." AS " ";
DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_Ent_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_Ent_v1_0(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP)
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- Enterprise level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  acc.enterpriseName AS 'Enterprise',
            '-' AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
	    SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
	    SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
	    COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu_on) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
	    COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu_off) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', #Actually GB now!
	    (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', #Actually GB now!
	    (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', #Actually GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB_on)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
	    COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB_off)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'IP Address Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise  and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise

    GROUP BY acc.idEnterprise
    ORDER BY acc.enterpriseName;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VDC_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VDC_v1_0(rls_abiquo_user VARCHAR(128), p_startDate TIMESTAMP, p_endDate TIMESTAMP, p_idEnterprise INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VDC level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            '-' AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
	    SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
	    SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
	    COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', #GB now!
	    (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', #GB now!
	    (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', #GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
	    COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'IP Address Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter

    FROM

        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,
 
        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise  AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idEnterprise=p_idEnterprise

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter
    ORDER BY acc.virtualDataCenter;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;




DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VApp_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VApp_v1_0(rls_abiquo_user VARCHAR(128),
                                                                p_startDate TIMESTAMP, p_endDate TIMESTAMP, 
                                                                p_idEnterprise INT(10), p_idVirtualDataCenter INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VApp level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            '-' AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
	    SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
	    SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', # GB now!
	    (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', # GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',


            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'IP Address Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE(SUM((CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                    * IF (cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion, 0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,

        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise and costs.id_datacenter=acc.idDataCenter)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualDataCenter=p_idVirtualDataCenter

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp
    ORDER BY acc.virtualApp;

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;





DROP PROCEDURE IF EXISTS kinton_reports.RPT_ConsumptionCost_VM_v1_0;
DELIMITER |
CREATE PROCEDURE kinton_reports.RPT_ConsumptionCost_VM_v1_0(rls_abiquo_user VARCHAR(128),
                                                                p_startDate TIMESTAMP, p_endDate TIMESTAMP, 
                                                                p_idEnterprise INT(10), p_idVirtualDataCenter INT(10), p_idVirtualApp INT(10))
    NOT DETERMINISTIC
    SQL SECURITY DEFINER
BEGIN
    ##########################################################################################
    #
    # Resource Consumption and Cost Report SP- VM level
    # Procedure Version : 2.2.0
    #
    ##########################################################################################

    # Initialise RLS so that the report user can only see the 'core' objects they have access too...
    CALL kinton_reporting.InitialiseRLS(rls_abiquo_user);

    SELECT  acc.enterpriseName AS 'Enterprise',
            acc.virtualDataCenter AS 'Virtual Datacenter',
            acc.virtualApp AS 'Virtual Appliance',
            IF (vm.name IS NULL, acc.virtualMachine, vm.name) AS 'Virtual Machine',

            IF(costs.currency IS NOT NULL, costs.currency, '') AS 'Currency',

            SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU Consumed',
	    SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU ON',
	    SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'CPU OFF',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 15 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.cpu) / costs.priceToHourConversion,0) AS 'CPU ON Cost',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 16 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0) / costs.priceToHourConversion,0) AS 'CPU OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM Consumed (MB)', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM ON', # GB now!
            (SUM(CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END)/1024) * COALESCE(usageToHourConversion,1) AS 'RAM OFF', # GB now!
            COALESCE((SUM((CASE idAccountingResourceType WHEN 2 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM Cost',
            COALESCE((SUM((CASE idAccountingResourceType WHEN 17 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.memoryGB)/1024) / costs.priceToHourConversion,0) AS 'RAM ON Cost',
           COALESCE((SUM((CASE idAccountingResourceType WHEN 18 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * 0)/1024) / costs.priceToHourConversion,0) AS 'RAM OFF Cost',

            (SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'Local Storage Consumed (GB)',
            COALESCE(((SUM(CASE idAccountingResourceType WHEN 3 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) * costs.hdGB) / costs.priceToHourConversion,0) AS 'Local Storage Cost',

            (SUM(CASE idAccountingResourceType WHEN 4 THEN resourceunits ELSE 0 END)/(1048576*1024)) * COALESCE(usageToHourConversion,1) AS 'External Storage Consumed (GB)',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 4 THEN ((((resourceunits * COALESCE(usageToHourConversion,1) * pt.price)/(1048576*1024))) / costs.priceToHourConversion) ELSE 0 END)),0) AS 'External Storage Cost',

            SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'IP Address Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 5 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.ip) / costs.priceToHourConversion,0) AS 'IP Address Cost',

            SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'VLAN Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 6 THEN resourceunits ELSE 0 END) * COALESCE(usageToHourConversion,1) * costs.vlan) / costs.priceToHourConversion,0) AS 'VLAN Cost',

            # Images Consumed and Cost, if required?
            SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1) AS 'Images Consumed',
            COALESCE((SUM(CASE idAccountingResourceType WHEN 1 THEN IF (acc.costCode > 0, 1, 0) ELSE 0 END) * COALESCE(usageToHourConversion,1)
                     * IF(cc.price IS NULL, 0, cc.price)) / costs.priceToHourConversion,0) AS 'Images Cost',

            # Helper columns for joins...
            acc.idEnterprise,
            acc.idVirtualDataCenter,
            acc.idVirtualApp,
            acc.idVirtualMachine

    FROM
        kinton_reporting.RLS_VDC_V1_0_VW AS vdc,
        kinton_reporting.RLS_ENTERPRISE_V1_0_VW AS e,
        kinton_accounting.ACCOUNT_PERIOD_USAGE_VW acc

        # Also join on the price so we can calculate the storage and costCode cost per row
        # and then SUM it all together...
        LEFT JOIN kinton_reporting.RLS_PRICING_TIERS_V1_0_VW pt ON (pt.idTier=acc.idStorageTier AND pt.idEnterprise=acc.idEnterprise AND acc.idDataCenter = pt.pricing_abstract_datacenter_id)

        # Ensure we only include the cost code once per VM by only adding the cc to CPU resources
        LEFT JOIN kinton_reporting.RLS_PRICING_COST_CODES_V1_0_VW cc ON (acc.costCode=cc.idCostCode AND  acc.idEnterprise=cc.idEnterprise AND acc.idAccountingResourceType=1)

        LEFT JOIN kinton_reporting.RLS_PRICING_PER_HOUR_V1_0_VW AS costs
            ON (costs.idEnterprise=acc.idEnterprise and costs.id_datacenter=acc.idDataCenter)

        LEFT JOIN kinton.virtualmachine vm ON (vm.idVM=acc.idVirtualMachine)

    WHERE
        (acc.startTime >= CAST(p_startDate AS DATETIME) OR p_startDate IS NuLL) AND (acc.startTime < CAST(p_endDate AS DATETIME) OR p_endDate IS NULL) AND
        acc.idVirtualDataCenter=vdc.idVirtualDataCenter AND
        acc.idEnterprise=e.idEnterprise AND
        acc.idVirtualApp=p_idVirtualApp

    GROUP BY acc.idEnterprise, acc.idVirtualDataCenter, acc.idVirtualApp, acc.idVirtualMachine
    ORDER BY IF (vm.name IS NULL, acc.virtualMachine, vm.name);

    # Clean up the RLS table content before we return to the caller
    CALL kinton_reporting.CleanupRLS();
END|
DELIMITER ;

